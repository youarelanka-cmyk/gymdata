/* ═════════════════════════════════════════════════════════════
   [MODULE: page/history] 训练统计中心
   ─────────────────────────────────────────────────────────────
   职责：时间区间筛选 · 9 张核心统计卡片 · 排序面板 · 设置弹窗
   依赖：App.*（core.js 暴露）
   注册：window.Pages.history
   ═════════════════════════════════════════════════════════════ */
(function(){
'use strict';
const $=id=>document.getElementById(id);

/* 卡片清单（排序面板用） */
const ALL_STATS_CARDS=[
  {id:'card-overview',name:'📋 阶段训练摘要',short:'阶段摘要'},
  {id:'card-periodcompare',name:'📊 周期对比',short:'周期对比'},
  {id:'card-loadtrend',name:'📈 训练负荷趋势',short:'负荷趋势'},
  {id:'card-fatigue',name:'🔋 疲劳与平衡',short:'疲劳与平衡'},
  {id:'card-consistency',name:'📅 训练规律',short:'训练规律'},
  {id:'card-musclecoverage',name:'🧩 肌群训练分析',short:'肌群分析'},
  {id:'card-structure',name:'⚡ 训练结构',short:'训练结构'},
  {id:'card-performance',name:'💪 动作表现',short:'动作表现'},
  {id:'card-rmmap',name:'📐 RM图谱',short:'RM图谱'},
  {id:'card-longtermheatmap',name:'🔥 长期训练热力图',short:'热力图'}
];

const FIXED_ACTIONS=[
  {id:'bench',label:'杠铃卧推',re:/杠铃卧推|卧推|barbell\s*bench/i},
  {id:'deadlift',label:'杠铃硬拉',re:/杠铃硬拉|硬拉|barbell\s*deadlift/i},
  {id:'squat',label:'杠铃深蹲',re:/杠铃深蹲|深蹲|barbell\s*squat/i},
  {id:'pullup',label:'引体向上',re:/引体向上|引体|pull.?up|chin.?up/i},
  {id:'row',label:'杠铃划船',re:/杠铃划船|俯身杠铃划船|barbell\s*row/i},
  {id:'ohp',label:'杠铃站姿推举',re:/杠铃站姿推举|站姿推举|杠铃肩推|overhead\s*press|military\s*press/i},
  {id:'rdl',label:'罗马尼亚硬拉',re:/罗马尼亚硬拉|罗马尼亚|RDL|romanian\s*deadlift/i}
];
function fixedActionGroups(groups, action){ return groups.filter(g=>nameFormsOf(g).some(f=>action.re.test(String(f)))); }
function fixedActionKey(groups, action){ const gs=fixedActionGroups(groups,action); return gs.length?AppNameKey(gs[0].action):null; }

const STATS_GROUPS=[
  {id:'state',title:'一、训练状态',desc:'回答：我最近练得怎么样？',ids:['card-overview','card-periodcompare','card-loadtrend','card-fatigue','card-consistency']},
  {id:'quality',title:'二、训练质量与进步',desc:'回答：训练安排合理吗？表现有没有提高？',ids:['card-musclecoverage','card-structure','card-performance']},
  {id:'longterm',title:'三、长期记录与力量图谱',desc:'回答：长期力量水平如何变化？',ids:['card-rmmap','card-longtermheatmap']}
];

/* ─── 主入口 ─────────────────────────────────────── */
function render(){
  ensureSkeleton();
  renderFilterTags();
  renderOverviewSection();
  renderPeriodCompareSection();
  renderLoadTrendSection();
  renderFatigueSection();
  renderMuscleCoverageSection();
  renderStructureSection();
  renderConsistencySection();
  renderPerformanceSection();
  renderRMMapSection();
  renderLongTermHeatmap();
  applyStatsCardOrder();
}

/* ─── 主入口 ─────────────────────────────────────── */
/* ─── 页面骨架（只生成一次） ─────────────────────── */
function ensureSkeleton(){
  const section=$('history'); if(!section) return;
  if(section.dataset.built==='1') return;
  section.dataset.built='1';
  const bodyMap={
    'card-overview':`<div class="row between" style="margin-bottom:10px;align-items:flex-start"><div><h2 style="margin:0">📋 本阶段训练摘要</h2><div class="muted" style="margin-top:2px;font-size:11.5px">先看结论，再进入具体分析 · 当前筛选区间</div></div><span class="badge-pill badge-blue" id="overviewRangeBadge">统计区间</span></div><div id="overviewKpis" class="kpi-grid"></div><div id="overviewCompare" style="margin-top:12px"></div><div id="overviewVerdict" style="margin-top:10px"></div>`,
    'card-periodcompare':`<div class="row between" style="margin-bottom:6px"><div><h2 style="margin:0">📊 周期对比</h2><div class="muted" style="margin-top:2px;font-size:11.5px">月、季度、年度纵向比较；看训练投入、表现与规律如何变化</div></div><span class="badge-pill badge-blue" id="periodCompareBadge">月度</span></div><div id="periodCompareTabs" style="display:flex;gap:6px;overflow:auto;padding:2px 0 8px"></div><div id="periodCompareBox"></div>`,
    'card-loadtrend':`<div class="row between" style="margin-bottom:6px"><div><h2 style="margin:0">📈 训练负荷趋势</h2><div class="muted" style="margin-top:2px;font-size:11.5px">用组数、次数与 RIR 构建训练压力趋势，不等同于生理疲劳测量</div></div><span class="badge-pill badge-blue" id="loadTrendBadge">趋势</span></div><div id="loadTrendBox" class="big-chart-box" style="padding:8px 4px;margin:8px 0"></div><div id="loadTrendNote" class="muted" style="font-size:12px;line-height:1.5"></div>`,
     'card-fatigue':`<div class="row between" style="margin-bottom:6px;align-items:flex-start"><div><h2 style="margin:0">🔋 疲劳与平衡</h2><div class="muted" style="margin-top:2px;font-size:11.5px">近 14 天训练压力估算 · 看肌群恢复与训练分布是否失衡</div></div><div class="row" style="font-size:10px;gap:7px;flex-wrap:wrap;justify-content:flex-end"><span><i style="width:8px;height:8px;border-radius:2px;background:color-mix(in srgb,var(--green) 45%,var(--card));display:inline-block"></i> 已恢复</span><span><i style="width:8px;height:8px;border-radius:2px;background:color-mix(in srgb,var(--orange) 45%,var(--card));display:inline-block"></i> 中负荷</span><span><i style="width:8px;height:8px;border-radius:2px;background:color-mix(in srgb,var(--red) 45%,var(--card));display:inline-block"></i> 高疲劳</span></div></div><div id="fatigueRings" class="fatigue-rings"></div><div id="fatigueBalanceSummary" style="margin-top:10px"></div><div class="muted" style="margin-top:10px;font-size:12px;line-height:1.55" id="fatigueGlobalAdvise"></div>`,
    'card-consistency':`<div class="row between" style="margin-bottom:6px"><div><h2 style="margin:0">📅 训练规律</h2><div class="muted" style="margin-top:2px;font-size:11.5px">训练频率、间隔、中断与年度出勤分布</div></div></div><div id="consistencyBox" style="margin-top:8px"></div><div class="compact-heat-wrap" style="margin-top:12px"><div id="compactHeatGrid" class="compact-heat-grid"></div></div><div class="row between" style="font-size:11px;color:var(--muted);margin-top:8px"><span>点击方块查看当天</span><div class="row" style="gap:4px"><span>少</span><i style="width:10px;height:10px;border-radius:2px;background:var(--heat0);display:inline-block"></i><i style="width:10px;height:10px;border-radius:2px;background:var(--heat1);display:inline-block"></i><i style="width:10px;height:10px;border-radius:2px;background:var(--heat2);display:inline-block"></i><i style="width:10px;height:10px;border-radius:2px;background:var(--heat3);display:inline-block"></i><i style="width:10px;height:10px;border-radius:2px;background:var(--heat4);display:inline-block"></i><span>多</span></div></div><div id="compactHeatDetail" class="compact-heat-detail" style="display:none"></div>`,
    'card-musclecoverage':`<div class="row between" style="margin-bottom:6px"><div><h2 style="margin:0">🧩 肌群训练分析</h2><div class="muted" style="margin-top:2px;font-size:11.5px">训练覆盖、周均有效组、频率、直接/间接刺激与最近训练时间</div></div><span class="badge-pill badge-blue" id="coverageBadge">覆盖</span></div><div id="muscleCoverageBox" style="margin-top:8px"></div>`,
    'card-structure':`<div class="row between" style="margin-bottom:6px"><div><h2 style="margin:0">⚡ 训练结构</h2><div class="muted" style="margin-top:2px;font-size:11.5px">推 / 拉 / 蹲、次数区间与 RIR 放在同一张结构报告里</div></div></div><div id="structureBox" style="margin-top:8px"></div>`,
    'card-performance':`<div class="row between" style="margin-bottom:6px"><div><h2 style="margin:0">💪 动作表现</h2><div class="muted" style="margin-top:2px;font-size:11.5px">按当前筛选区间查看固定动作的表现趋势</div></div></div><div id="performanceTrendBox" style="margin-top:10px"></div>`,
    'card-rmmap':`<div class="row between" style="margin-bottom:6px"><div><h2 style="margin:0">📐 RM图谱</h2><div class="muted" style="margin-top:2px;font-size:11.5px">把主要动作的估算 1RM～12RM 放在同一张图里，看力量水平与训练容量的关系</div></div><span class="badge-pill badge-blue" id="rmMapBadge">RM</span></div><div id="rmMapBox" style="margin-top:8px"></div>`,
    'card-longtermheatmap':`<div class="row between" style="margin-bottom:8px;align-items:flex-end;gap:8px"><div><h2 style="margin:0">🔥 长期训练热力图</h2><div class="muted" style="margin-top:2px;font-size:11.5px">完全跟随上方时间滚动条 · 纯色块训练图谱</div></div><span class="badge-pill badge-blue" id="longHeatRangeBadge">热力图</span></div><div id="longTermHeatmapBox"></div>`
  };
  const cardsHtml=ALL_STATS_CARDS.map(c=>`<div class="card" id="${c.id}">${bodyMap[c.id]||''}</div>`).join('');
  section.innerHTML=`
    <div class="card tight stats-head-sticky">
      <div class="stats-head-actions"><button id="settingsBtn" class="stats-head-btn">⚙️ 设置</button><button id="statsSortBtn" class="stats-head-btn">🔀 排序</button></div>
      <div class="stats-head-title"><h2 style="margin:0;font-size:18px;font-weight:900">📊 训练统计</h2><div class="muted" style="font-size:11.5px;margin-top:2px">进步 · 容量 · 结构 · 长期变化</div></div>
      <div class="range-dual" id="rangeDual"><div class="range-ticks" id="rangeTicks"></div><input type="range" id="rangeStart" class="range-thumb range-thumb-s" min="0" max="365" value="365" aria-label="区间开始"><input type="range" id="rangeEnd" class="range-thumb range-thumb-e" min="0" max="365" value="0" aria-label="区间结束"></div>
      <div class="range-info"><span id="rangeDaysLabel">全部历史</span><span class="muted" id="rangeNodeHint" style="font-size:10.5px"></span></div>
      <div class="stats-filter-tags" id="statsFilterTags" style="display:flex;flex-wrap:wrap;gap:5px"></div>
    </div>
    <div id="statsCardsContainer" class="stats-cards-container" style="display:flex;flex-direction:column;gap:12px;margin-top:12px">${cardsHtml}</div>`;
  const cards=$('statsCardsContainer');
  if(cards){ STATS_GROUPS.forEach((g,idx)=>{ const wrap=document.createElement('section'); wrap.className='stats-group'; wrap.dataset.group=g.id; wrap.innerHTML=`<button type="button" class="stats-group-toggle" aria-expanded="true"><span class="stats-group-copy"><b>${g.title}</b><small>${g.desc}</small></span><span class="stats-group-count">${g.ids.length} 项　⌄</span></button><div class="stats-group-body"></div>`; const body=wrap.querySelector('.stats-group-body'); g.ids.forEach(id=>{const el=$(id);if(el)body.appendChild(el);}); wrap.querySelector('.stats-group-toggle').onclick=()=>{const open=wrap.classList.toggle('collapsed')===false;wrap.querySelector('.stats-group-toggle').setAttribute('aria-expanded',String(open));}; cards.appendChild(wrap); }); }
  $('settingsBtn').onclick=openSettings; $('statsSortBtn').onclick=openStatsSortModal;
}

/* ─── 分组数据提取 ─────────────────────────────── */
function allGroupsRaw(){
  const App=window.App;
  const out=[];
  App.db.sessions.forEach(s=>s.exercises.forEach(e=>e.sets.forEach(x=>out.push({
    date:s.date,plan:s.planName,action:e.name,
    part:e.part||App.db.exercises.find(z=>z.id===e.exerciseId)?.part||'其他',
    exerciseId:e.exerciseId,weight:x.weight,reps:Number(x.reps)||0,
    rir:x.rir,type:x.type||'正式',done:!!x.done
  }))));
  return out;
}
function allGroups(){
  const App=window.App;
  return allGroupsRaw().map(g=>{
    const p=App.profileFor(g.action,g.part);
    return {...g,part:p.part,movement:p.movement,isCompound:p.isCompound,muscles:p.muscles};
  });
}
function selectedGroups(){
  const App=window.App, state=App.state;
  const r=state.historyRange;
  if(r==='7'||r==='28'||r==='30'||r==='84'||r==='90'||r==='365'){
    const since=new Date(Date.now()-Number(r)*86400000);
    return allGroups().filter(g=>new Date(g.date+'T23:59:59')>=since);
  }
  if(r.startsWith('year-')) return allGroups().filter(g=>g.date.startsWith(r.split('-')[1]));
  if(r.startsWith('range-')){
    const [a,b]=r.slice(6).split('_');
    return allGroups().filter(g=>g.date>=a&&g.date<=b);
  }
  return allGroups();
}
function formalGroupsInRange(){
  return selectedGroups().filter(g=>g.type!=='热身'&&(g.done||g.reps>0));
}
function todayStr(){ return window.App.state.today; }
function rangeLabel(){
  const r=window.App.state.historyRange;
  if(r==='7') return '近7天';
  if(r==='28') return '近4周';
  if(r==='30') return '近30天';
  if(r==='84') return '近12周';
  if(r==='90') return '近90天';
  if(r==='365') return '近365天';
  if(r==='all') return '全部历史';
  if(String(r).startsWith('year-')) return r.split('-')[1]+'年';
  if(String(r).startsWith('range-')){ const [a,b]=String(r).slice(6).split('_'); return a.slice(5)+' ~ '+b.slice(5); }
  return '当前区间';
}
function rangeDateSpan(){
  const App=window.App;
  const r=App.state.historyRange;
  const today=todayStr();
  if(r&&String(r).startsWith('range-')){
    const [a,b]=String(r).slice(6).split('_');
    return {start:a,end:b};
  }
  if(r==='all'){
    let min=today;
    (App.db.sessions||[]).forEach(s=>{ if(s.date&&s.date<min) min=s.date; });
    return {start:min,end:today};
  }
  if(r&&String(r).startsWith('year-')){ const y=r.slice(5); return {start:y+'-01-01',end:y+'-12-31'}; }
  const n=Number(r);
  if(isFinite(n)&&n>0){
    const end=new Date(today+'T12:00:00'); const st=new Date(end); st.setDate(st.getDate()-(n-1));
    return {start:st.toISOString().slice(0,10),end:today};
  }
  return {start:today,end:today};
}
function daysSinceEarliest(){
  const App=window.App;
  const today=Date.parse(todayStr()+'T00:00:00');
  let min=Infinity;
  (App.db.sessions||[]).forEach(s=>{ const t=Date.parse(String(s.date||'').slice(0,10)+'T00:00:00'); if(isFinite(t)&&t<min) min=t; });
  if(!isFinite(min)) return 365;
  return Math.max(365,Math.round((today-min)/86400000));
}
function sumVolume(gs){ return gs.reduce((a,g)=>a+(isFinite(Number(g.weight))?Number(g.weight)*g.reps:0),0); }

/* ─── 时间筛选 + 年份标签（★ 只读导入数据的年份） ───── */
function renderFilterTags(){
  const App=window.App, state=App.state;
  const box=$('statsFilterTags'); if(!box) return;

  const years=new Set();
  (App.db.sessions||[]).forEach(s=>{
    const y=String(s.date||'').slice(0,4);
    if(/^\d{4}$/.test(y)) years.add(y);
  });
  const yearList=[...years].sort((a,b)=>Number(b)-Number(a));

  const validRanges=new Set([...yearList.map(y=>'year-'+y),'all']);
  const curR=String(state.historyRange);
  const okRange=validRanges.has(curR)||/^\d+$/.test(curR)||curR.startsWith('range-');
  if(!okRange) state.historyRange='all';

  const sEl=$('rangeStart'), eEl=$('rangeEnd'), tics=$('rangeTicks');
  const lab=$('rangeDaysLabel'), hint=$('rangeNodeHint');
  if(sEl&&eEl){
    const max=daysSinceEarliest();
    sEl.max=max; eEl.max=max;
    const today=todayStr();
    const off=d=>Math.max(0,Math.min(max,Math.round((Date.parse(today+'T00:00:00')-Date.parse(d+'T00:00:00'))/86400000)));
    const span=rangeDateSpan();
    sEl.value=off(span.start); eEl.value=off(span.end);
    const nodes=[0,30,90,180,365].filter(n=>n<=max); if(!nodes.includes(max)) nodes.push(max);
    nodes.sort((a,b)=>a-b);
    const snap=v=>{ for(const n of nodes){ if(Math.abs(v-n)<=5) return n; } return v; };
    const refreshLabel=()=>{
      const cur=String(state.historyRange);
      if(cur.startsWith('year-')||cur==='all'){ lab.textContent=rangeLabel(); hint.textContent='年份/全部模式：拖动滑块切换区间'; return; }
      let s=Number(sEl.value),e=Number(eEl.value);
      if(s<=e){ sEl.value=Math.min(max,e+1); s=Number(sEl.value); }
      if(e>=s){ eEl.value=Math.max(0,s-1); e=Number(eEl.value); }
      const dS=new Date(today+'T12:00:00'); dS.setDate(dS.getDate()-s);
      const dE=new Date(today+'T12:00:00'); dE.setDate(dE.getDate()-e);
      lab.textContent=`${dS.toISOString().slice(0,10)} ~ ${dE.toISOString().slice(0,10)} · ${Math.max(1,s-e+1)}天`;
      const snapNode=n=>nodes.find(x=>x===Math.abs(n));
      const h=snapNode(s)||snapNode(e);
      hint.textContent=h!==undefined?`已吸附 ${h===0?'今天':h===30?'1月':h===90?'1季':h===180?'半年':h===365?'1年':h+'天前'}`:'拖动两端可看任意区间';
    };
    const apply=()=>{
      let s=snap(Number(sEl.value)),e=snap(Number(eEl.value));
      if(s<=e){ if(e+1<=max){ s=e+1; sEl.value=s; } else { e=Math.max(0,s-1); eEl.value=e; } }
      const dS=new Date(today+'T12:00:00'); dS.setDate(dS.getDate()-s);
      const dE=new Date(today+'T12:00:00'); dE.setDate(dE.getDate()-e);
      state.historyRange='range-'+dS.toISOString().slice(0,10)+'_'+dE.toISOString().slice(0,10);
    };
    const onInput=()=>{
      let s=Number(sEl.value),e=Number(eEl.value);
      if(s<=e) sEl.value=Math.min(max,e+1); s=Number(sEl.value);
      if(e>=s) eEl.value=Math.max(0,s-1);
      refreshLabel();
      clearTimeout(renderFilterTags._t);
      renderFilterTags._t=setTimeout(()=>{ apply(); render(); },260);
    };
    const onChange=()=>{ apply(); render(); };
    if(!sEl.dataset.bound){
      sEl.addEventListener('input',onInput);
      eEl.addEventListener('input',onInput);
      sEl.addEventListener('change',onChange);
      eEl.addEventListener('change',onChange);
      sEl.dataset.bound='1'; eEl.dataset.bound='1';
    }
    const inYearAll=curR.startsWith('year-')||curR==='all';
    sEl.style.opacity=inYearAll?'.45':'1';
    eEl.style.opacity=inYearAll?'.45':'1';
    refreshLabel();
    if(tics){
      const labels={0:'今',30:'1月',90:'1季',180:'半年',365:'1年'};
      tics.innerHTML=nodes.map(n=>{
        const pct=(n/max*100).toFixed(1);
        const label=labels[n]||(n===max?'最早':'');
        return `<span class="rt ${label?'strong':''}" style="left:${pct}%"><span class="rl">${label}</span></span>`;
      }).join('');
    }
  }

  const quick=$('statsQuickRanges'); if(quick) quick.remove();
  // 时间范围统一由顶部双滑块控制，不再额外显示快捷年份/区间标签。
  box.innerHTML='';
  box.style.display='none';
}

/* ─── 1. 训练总览 ─────────────────────────────── */
function renderOverviewSection(){
  const App=window.App;
  const badge=$('overviewRangeBadge'); if(badge) badge.textContent=rangeLabel();
  const gs=formalGroupsInRange();
  const days=new Set(gs.map(g=>g.date));
  const sets=gs.length;
  const reps=gs.reduce((a,g)=>a+g.reps,0);
  const vol=sumVolume(gs);
  const gsSorted=gs.slice().sort((a,b)=>a.date.localeCompare(b.date));
  const dates=[...new Set(gsSorted.map(g=>g.date))].sort();
  const midIdx=Math.floor(dates.length/2);
  const midDate=dates[midIdx];
  const prev=midDate?gsSorted.filter(g=>g.date<midDate):[];
  const recent=midDate?gsSorted.filter(g=>g.date>=midDate):gsSorted;
  const volR=sumVolume(recent), volP=sumVolume(prev);
  const daysR=new Set(recent.map(g=>g.date)).size, daysP=new Set(prev.map(g=>g.date)).size;
  const volDelta=volP>0?((volR-volP)/volP*100):(volR>0?100:0);
  const dayDelta=daysP>0?((daysR-daysP)/daysP*100):(daysR>0?100:0);

  let streak=0;
  const trained=new Set(allGroups().filter(g=>g.done||g.reps>0).map(g=>g.date));
  for(let i=0;i<400;i++){
    const d=new Date(App.state.today+'T12:00:00'); d.setDate(d.getDate()-i);
    const ds=d.toISOString().slice(0,10);
    if(trained.has(ds)) streak++; else if(i>0) break;
  }

  function rangeWindowDays(){
    const r=App.state.historyRange;
    if(r==='7'||r==='30'||r==='90'||r==='365') return Number(r);
    if(String(r).startsWith('year-')){
      const y=Number(String(r).split('-')[1]); if(!Number.isFinite(y)) return 365;
      const isLeap=(y%4===0&&y%100!==0)||(y%400===0); return isLeap?366:365;
    }
    const allDates=[...new Set(allGroups().map(g=>g.date).filter(d=>/^\d{4}-\d{2}-\d{2}$/.test(String(d||''))))].sort();
    if(allDates.length<2) return 7;
    const t0=new Date(allDates[0]+'T12:00:00').getTime();
    const t1=new Date(allDates[allDates.length-1]+'T12:00:00').getTime();
    if(!Number.isFinite(t0)||!Number.isFinite(t1)||t1<t0) return 7;
    return Math.max(7,Math.round((t1-t0)/86400000)+1);
  }
  const windowDays=rangeWindowDays();
  let weeks=windowDays/7; if(!Number.isFinite(weeks)||weeks<=0) weeks=1;
  const freq=days.size/weeks;
  const freqDisp=Number.isFinite(freq)?freq.toFixed(1):'0.0';
  const setsPerSession=days.size?(sets/days.size):0;
  const volPerSession=days.size?(vol/days.size):0;

  const box=$('overviewKpis'); if(!box) return;
  box.innerHTML=`
    <div class="kpi-box"><b>${days.size}</b><span>训练次数</span><small>有效训练日</small></div>
    <div class="kpi-box"><b>${freqDisp}</b><span>周均频率</span><small>次/周 · 按${windowDays}天折算</small></div>
    <div class="kpi-box"><b>${sets}</b><span>正式组数</span><small>Working Sets</small></div>
    <div class="kpi-box"><b>${App.fmtVolume(vol)}</b><span>总容量</span><small>重量×次数</small></div>
    <div class="kpi-box"><b>${setsPerSession.toFixed(1)}</b><span>场均组数</span><small>组 / 次</small></div>
    <div class="kpi-box"><b>${App.fmtVolume(volPerSession)}</b><span>场均容量</span><small>kg / 次</small></div>`;

  const cmp=$('overviewCompare');
  if(cmp){
    const arrow=v=>v>5?'↑':(v<-5?'↓':'→');
    const col=v=>v>5?'var(--green)':(v<-5?'var(--red)':'var(--muted)');
    cmp.innerHTML=`<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
      <div style="padding:10px 12px;background:var(--panel);border:1px solid var(--line);border-radius:12px">
        <div style="font-size:11px;color:var(--muted);font-weight:750">区间后半 vs 前半 · 容量</div>
        <div style="font-size:20px;font-weight:900;color:${col(volDelta)};margin-top:2px">${arrow(volDelta)} ${volDelta>0?'+':''}${volDelta.toFixed(0)}%</div>
        <div style="font-size:11px;color:var(--muted);margin-top:2px">${App.fmtVolume(volP)} → ${App.fmtVolume(volR)} kg</div>
      </div>
      <div style="padding:10px 12px;background:var(--panel);border:1px solid var(--line);border-radius:12px">
        <div style="font-size:11px;color:var(--muted);font-weight:750">区间后半 vs 前半 · 出勤</div>
        <div style="font-size:20px;font-weight:900;color:${col(dayDelta)};margin-top:2px">${arrow(dayDelta)} ${dayDelta>0?'+':''}${dayDelta.toFixed(0)}%</div>
        <div style="font-size:11px;color:var(--muted);margin-top:2px">${daysP} 天 → ${daysR} 天</div>
      </div>
    </div>`;
  }

  const ver=$('overviewVerdict');
  if(ver){
    let text='数据积累中，多完成几次正式训练后会有更清晰的趋势判断。';
    if(days.size>=4){
      if(volDelta>10&&dayDelta>=0) text='容量与出勤同步上升，渐进超负荷节奏健康，继续保持当前频率。';
      else if(volDelta>10&&dayDelta<0) text='单次容量在升高，但出勤有所下降；注意恢复，避免用大重量硬撑次数。';
      else if(volDelta<-10) text='近段容量低于对照段，可能进入疲劳或松懈期；可检查睡眠与计划完成度。';
      else if(streak>=5) text='连续出勤稳定，重点看下方部位平衡与动作是否还在进步。';
      else text='出勤与容量大致平稳。结合疲劳与动作诊断，决定下一阶段是加量还是维持。';
    }
    ver.innerHTML=`<div style="padding:10px 12px;background:var(--soft);border-radius:12px;border-left:4px solid var(--blue);font-size:12.5px;line-height:1.55;color:var(--text)"><b>总评：</b>${text}</div>`;
  }
}

/* ─── 2. 容量趋势与峰值 ─────────────────────────── */
function renderVolumePeakSection(){
  const App=window.App;
  const gs=formalGroupsInRange();
  const byMonth={};
  gs.forEach(g=>{
    const ym=g.date.slice(0,7);
    if(!byMonth[ym]) byMonth[ym]={vol:0,sets:0,days:new Set()};
    if(isFinite(Number(g.weight))) byMonth[ym].vol+=Number(g.weight)*g.reps;
    byMonth[ym].sets++; byMonth[ym].days.add(g.date);
  });
  const months=Object.keys(byMonth).sort();
  const box=$('volumeTrendChart'), note=$('volumePeakNote'), badge=$('volumePeakBadge');
  if(!months.length){
    if(box) box.innerHTML='<div class="empty">暂无容量数据</div>';
    if(note) note.textContent=''; if(badge) badge.textContent='暂无';
    return;
  }
  const show=months.slice(-8);
  const maxV=Math.max(...show.map(m=>byMonth[m].vol),1);
  let peakM=show[0], peakV=byMonth[peakM].vol;
  show.forEach(m=>{ if(byMonth[m].vol>peakV){ peakV=byMonth[m].vol; peakM=m; } });
  if(badge) badge.textContent=`峰值 ${peakM.slice(5)}月`;

  const breakMonths=[]; let runMax=0;
  months.forEach(m=>{ if(byMonth[m].vol>runMax*1.05&&runMax>0) breakMonths.push(m); if(byMonth[m].vol>runMax) runMax=byMonth[m].vol; });

  const w=350,h=170,p={l:24,r:24,t:28,b:28};
  const step=(w-p.l-p.r)/show.length;
  const bw=Math.max(18,Math.min(28,Math.floor(step*0.55)));
  let bars='';
  show.forEach((m,i)=>{
    const v=byMonth[m].vol;
    const xx=p.l+(i+0.5)*step-bw/2;
    const bh=(v/maxV)*(h-p.t-p.b);
    const yy=h-p.b-bh;
    const isPeak=m===peakM;
    bars+=`<g><rect x="${xx.toFixed(1)}" y="${yy.toFixed(1)}" width="${bw}" height="${Math.max(3,bh).toFixed(1)}" rx="5" fill="color-mix(in srgb,var(--blue) 34%,var(--card))"><title>${m}：${App.fmtVolume(v)} kg · ${byMonth[m].sets}组 · ${byMonth[m].days.size}天${isPeak?' · 峰值':''}</title></rect><text x="${(xx+bw/2).toFixed(1)}" y="${(yy-6).toFixed(1)}" text-anchor="middle" font-size="10" font-weight="900" fill="${isPeak?'var(--blue)':'var(--text)'}">${isPeak?'▲ ':''}${(v/1000).toFixed(1)}</text><text x="${(xx+bw/2).toFixed(1)}" y="${h-8}" text-anchor="middle" font-size="10" font-weight="${isPeak?'900':'750'}" fill="${isPeak?'var(--blue)':'var(--muted)'}">${m.slice(5)}月</text></g>`;
  });
  if(box){
    box.innerHTML=`<div class="svg-chart-container"><svg viewBox="0 0 ${w} ${h}" style="width:100%;height:auto;display:block"><line x1="${p.l}" y1="${h-p.b}" x2="${w-p.r}" y2="${h-p.b}" stroke="var(--line)" stroke-width="1.2"/>${bars}</svg></div>
      <div style="display:flex;gap:14px;justify-content:center;font-size:11px;color:var(--muted);margin-top:4px"><span><i style="width:16px;height:8px;border-radius:2px;background:color-mix(in srgb,var(--blue) 34%,var(--card));display:inline-block;vertical-align:middle;margin-right:4px"></i>月度容量</span><span><b style="color:var(--blue)">▲</b> 峰值月</span><span>单位：吨</span></div>`;
  }
  if(note){
    let t=`峰值月份 <b>${peakM}</b>，容量 <b>${App.fmtVolume(peakV)} kg</b>，共 ${byMonth[peakM].days.size} 个训练日。`;
    if(breakMonths.length) t+=` 历史中突破前高的月份：<b>${breakMonths.slice(-4).join('、')}</b>。`;
    else t+=' 当前区间内尚未明显突破历史峰值，可关注是否进入平台期。';
    note.innerHTML=t;
  }
}

/* ─── 3. 近12周容量 ─────────────────────────────── */
function renderWeekVolumeSection(){
  const App=window.App;
  const box=$('weekVolChart'), note=$('weekVolNote'); if(!box) return;
  const span=rangeDateSpan();
  const blockDays=Math.round((Date.parse(span.end+'T00:00:00')-Date.parse(span.start+'T00:00:00'))/86400000)+1<=90?7:14;
  const start=new Date(span.start+'T12:00:00'), end=new Date(span.end+'T12:00:00');
  const blocks=[];
  for(let s=new Date(start);s<=end;){
    const e=new Date(s); e.setDate(e.getDate()+blockDays-1);
    if(e>end) e.setTime(end.getTime());
    blocks.push({s:s.toISOString().slice(0,10),e:e.toISOString().slice(0,10),label:String(+s.toISOString().slice(5,7))+'.'+String(+s.toISOString().slice(8,10)),vol:0,sets:0,days:new Set()});
    s.setDate(s.getDate()+blockDays);
  }
  allGroups().forEach(g=>{
    if((g.type||'正式')==='热身') return;
    if(!(g.done||Number(g.reps)>0)) return;
    const d=g.date;
    for(const w of blocks){ if(d>=w.s&&d<=w.e){ const weight=Number(g.weight); if(isFinite(weight)) w.vol+=weight*(Number(g.reps)||0); w.sets++; w.days.add(d); break; } }
  });
  const vols=blocks.map(w=>w.vol);
  const maxV=Math.max(...vols,1);
  const wSvg=360,h=150,p={l:22,r:22,t:20,b:44};
  const step=(wSvg-p.l-p.r)/blocks.length;
  const bw=Math.max(12,Math.min(22,step*0.55));
  let bars='';
  blocks.forEach((w,i)=>{
    const bh=(w.vol/maxV)*(h-p.t-p.b);
    const xx=p.l+(i+0.5)*step-bw/2;
    const yy=h-p.b-bh;
    const cx=xx+bw/2, ly=h-p.b+13;
    bars+=`<g><rect x="${xx.toFixed(1)}" y="${yy.toFixed(1)}" width="${bw}" height="${Math.max(2,bh).toFixed(1)}" rx="4" fill="color-mix(in srgb,var(--blue) 34%,var(--card))"><title>${w.s}~${w.e}: ${App.fmtVolume(w.vol)}kg · ${w.sets}组 · ${w.days.size}天</title></rect><text x="${cx.toFixed(1)}" y="${ly.toFixed(1)}" text-anchor="end" transform="rotate(-45 ${cx.toFixed(1)} ${ly.toFixed(1)})" font-size="8.5" fill="var(--muted)">${w.label}</text></g>`;
  });
  box.innerHTML=`<div class="svg-chart-container"><svg viewBox="0 0 ${wSvg} ${h}" style="width:100%;height:auto;display:block"><line x1="${p.l}" y1="${h-p.b}" x2="${wSvg-p.r}" y2="${h-p.b}" stroke="var(--line)" stroke-width="1"/>${bars}</svg></div>`;
  const half=Math.max(1,Math.floor(blocks.length/2));
  const lastHalf=blocks.slice(-half).reduce((a,w)=>a+w.vol,0);
  const prevHalf=blocks.slice(0,half).reduce((a,w)=>a+w.vol,0);
  let msg='';
  if(prevHalf>0){
    const d=(lastHalf-prevHalf)/prevHalf*100;
    msg=`区间后半段容量较前半段 <b style="color:${d>=0?'var(--green)':'var(--red)'}">${d>=0?'+':''}${d.toFixed(0)}%</b>。`;
    if(d>=8) msg+=' 负荷在爬升，注意恢复是否跟得上。';
    else if(d<=-8) msg+=' 负荷回落，若非主动减载可检查出勤与重量。';
    else msg+=' 负荷大致平稳。';
  }else msg='继续积累训练数据后，可对比区间前后段容量变化。';
  if(note) note.innerHTML=msg;
}

/* ─── 4. 训练出勤热力图 ─────────────────────────── */

/* ─── 新增分析：阶段负荷 / 肌群覆盖 / 规律 / 进步 / 效率 / 里程碑 ─── */
function analysisGroupsInWindow(days){
  const App=window.App, all=allGroups().filter(g=>g.type!=='热身'&&(g.done||g.reps>0)), r=App.state.historyRange;
  if(r!=='all'&&!String(r).startsWith('year-')&&!String(r).startsWith('range-')) return selectedGroups().filter(g=>g.type!=='热身'&&(g.done||g.reps>0));
  const end=new Date(todayStr()+'T12:00:00'), start=new Date(end); start.setDate(start.getDate()-(days-1));
  return all.filter(g=>g.date>=start.toISOString().slice(0,10)&&g.date<=todayStr());
}
function dayDiff(a,b){
  const x=Date.parse(String(a).slice(0,10)+'T12:00:00'),y=Date.parse(String(b).slice(0,10)+'T12:00:00');
  return isFinite(x)&&isFinite(y)?Math.round((y-x)/86400000):0;
}
function setLoadValue(g){
  const r=Number(g.reps)||0, rir=(g.rir!==''&&g.rir!=null&&isFinite(Number(g.rir)))?Number(g.rir):2.5;
  const rf=r<=5?1.15:r<=12?1:r<=20?.9:.75, ef=rir<=0?1.35:rir<=1?1.25:rir<=2?1.12:rir<=3?1:rir<=4?.88:.72;
  return rf*ef;
}
function dayLoadMap(gs){const m={};gs.forEach(g=>m[g.date]=(m[g.date]||0)+setLoadValue(g));return m;}
function getSessionDays(){
  return [...new Set(formalGroupsInRange().map(g=>g.date))].sort();
}
function periodKey(d,mode){
  const y=String(d).slice(0,4),m=Number(String(d).slice(5,7)||1);
  if(mode==='month') return y+'-'+String(m).padStart(2,'0');
  if(mode==='quarter') return y+' Q'+Math.floor((m-1)/3+1);
  return y;
}
function periodRange(key,mode){
  if(mode==='year') return {start:key+'-01-01',end:key+'-12-31'};
  if(mode==='month'){const [y,m]=key.split('-').map(Number),d=new Date(y,m,0).getDate();return {start:key+'-01',end:key+'-'+String(d).padStart(2,'0')};}
  const [y,q]=key.split(' Q').map(Number),sm=(q-1)*3+1,ed=new Date(y,sm+2,0).getDate();return {start:y+'-'+String(sm).padStart(2,'0')+'-01',end:y+'-'+String(sm+2).padStart(2,'0')+'-'+String(ed).padStart(2,'0')};
}
function periodRows(mode){
  const all=allGroups().filter(g=>g.type!=='热身'&&(g.done||g.reps>0));
  const keys=[...new Set(all.map(g=>periodKey(g.date,mode)))].sort();
  const last=keys.slice(-6);
  return last.map(k=>{const r=periodRange(k,mode),gs=all.filter(g=>g.date>=r.start&&g.date<=r.end),days=new Set(gs.map(g=>g.date));const vol=sumVolume(gs),sets=gs.length,rir=gs.filter(g=>isFinite(Number(g.rir))).map(g=>Number(g.rir));return{key:k,range:r,days:days.size,sets,vol,avgRir:rir.length?rir.reduce((a,b)=>a+b,0)/rir.length:null};});
}
function periodDisplay(key,mode){
  if(mode==='year') return `<span class="period-label"><b>${key}年</b></span>`;
  if(mode==='quarter'){const [y,q]=key.split(' Q');return `<span class="period-label"><b>${y}年</b><small>第${q}季度</small></span>`;}
  const [y,m]=key.split('-'); return `<span class="period-label"><b>${y}年</b><small>${Number(m)}月</small></span>`;
}
function renderPeriodCompareSection(){
  const tabs=$('periodCompareTabs'),box=$('periodCompareBox'),badge=$('periodCompareBadge'); if(!tabs||!box)return;
  const App=window.App,state=App.state; const mode=state.periodCompareMode||'month';
  const modes=[['month','月'],['quarter','季度'],['year','年度']];
  tabs.innerHTML=modes.map(([v,l])=>`<button type="button" class="filter-tag-pill${mode===v?' active':''}" data-period-mode="${v}">${l}</button>`).join('');
  tabs.querySelectorAll('[data-period-mode]').forEach(b=>b.onclick=()=>{state.periodCompareMode=b.dataset.periodMode;renderPeriodCompareSection();});
  const rows=periodRows(mode); badge.textContent=modes.find(x=>x[0]===mode)[1];
  if(!rows.length){box.innerHTML='<div class="empty">暂无足够的历史训练数据。</div>';return;}
  const cells=rows.map((r,i)=>{const p=rows[i-1];const pct=(a,b)=>b&&b!==0?(a/b-1)*100:null;return {...r,setsD:p?pct(r.sets,p.sets):null,volD:p?pct(r.vol,p.vol):null,daysD:p?pct(r.days,p.days):null,rirD:p&&r.avgRir!=null&&p.avgRir!=null?r.avgRir-p.avgRir:null};});
  const delta=v=>v==null?'—':`${v>=0?'+':''}${v.toFixed(0)}%`;
  box.innerHTML=`<div class="period-compact-wrap"><table class="pr-table period-compact-table"><thead><tr><th>周期</th><th>训练量</th><th>容量</th><th>变化</th></tr></thead><tbody>${cells.map((r,i)=>`<tr><td class="period-compact-period">${periodDisplay(r.key,mode)}</td><td><b>${r.days}</b> 天 <span class="muted">· ${r.sets}组</span><small>${r.avgRir==null?'RIR —':'RIR '+r.avgRir.toFixed(1)}</small></td><td><b>${App.fmtVolume(r.vol)}</b><small>kg</small></td><td>${i===0?'<span class="muted">基准</span>':`<b>${delta(r.volD)}</b><small>容量 · 组数 ${delta(r.setsD)}</small>`}</td></tr>`).join('')}</tbody></table></div><div class="muted" style="font-size:10.5px;line-height:1.5;margin-top:7px">仅保留最关键的 4 个维度，避免在手机上横向拖动；容量 = 重量 × 次数。</div>`;
}
function renderStructureSection(){
  const box=$('structureBox'); if(!box)return;
  const gs=formalGroupsInRange(); if(!gs.length){box.innerHTML='<div class="empty">暂无训练结构数据。</div>';return;}
  const cnt={推:0,拉:0,蹲:0}, bands={'力量 1–5':0,'肌肥大 6–15':0,'耐力 16+':0};
  let rirSum=0,rirN=0;
  gs.forEach(g=>{
    if(cnt[g.movement]!=null)cnt[g.movement]++;
    const r=Number(g.reps)||0;
    if(r<=5)bands['力量 1–5']++; else if(r<=15)bands['肌肥大 6–15']++; else bands['耐力 16+']++;
    if(isFinite(Number(g.rir))){rirSum+=Number(g.rir);rirN++;}
  });
  const total=gs.length||1;
  const movementLabels=['推','拉','蹲'].map(x=>`<div class="structure-ratio-item"><div class="structure-ratio-top"><b>${(cnt[x]/total*100).toFixed(0)}%</b></div><div class="structure-ratio-track"><i style="width:${Math.max(2,cnt[x]/total*100)}%"></i></div><div class="structure-ratio-name">${x}</div></div>`).join('');
  const bandLabels=Object.entries(bands).map(([k,v])=>{const [type,range]=k.split(' ');const pct=v/total*100;return `<div class="structure-band-item"><div class="structure-ratio-top"><b>${pct.toFixed(0)}%</b></div><div class="structure-ratio-track"><i style="width:${Math.max(2,pct)}%"></i></div><div class="structure-ratio-name">${type}</div></div>`;}).join('');
  box.innerHTML=`<div class="structure-block"><div class="structure-section-title">动作模式比例 <span>推 / 拉 / 蹲</span></div><div class="structure-ratio-grid">${movementLabels}</div></div>
    <div class="structure-block" style="margin-top:10px"><div class="structure-section-title">次数区间比例 <span>力量 / 肌肥大 / 耐力</span></div><div class="structure-band-grid">${bandLabels}</div></div>
    <div class="structure-foot"><span class="metric-chip">正式组 <b>${gs.length}</b></span><span class="metric-chip">平均 RIR <b>${rirN?(rirSum/rirN).toFixed(1):'—'}</b></span><span class="metric-chip">推 / 拉 <b>${cnt.拉?(cnt.推/cnt.拉).toFixed(2):'—'}</b></span></div>`;
}
function performanceModeFor(g){
  const App=window.App;
  if(g.isCompound || (App.constants.CORE_LIFTS_ALL||[]).some(x=>x.test(String(g.action||'')))) return 'strength';
  return 'hypertrophy';
}
function performanceMetric(g){
  const w=Number(g.weight)||0,r=Number(g.reps)||0,mode=performanceModeFor(g);
  if(w<=0||r<1||r>30)return null;
  if(mode==='strength') return {score:w*(1+r/30),mode,weight:w,reps:r};
  /* 孤立动作只在同一目标次数区间内比较，不用 e1RM 外推。以 8–12 次为主区间，区间外降低权重。 */
  const dist=r>=8&&r<=12?1:(r>=6&&r<=15?.88:.68);
  return {score:w*dist,mode,weight:w,reps:r,band:r>=8&&r<=12?'8–12次':(r<8?'低次数':'高次数')};
}
function renderPerformanceSection(){
  const target=$('performanceTrendBox');
  if(target){
    target.innerHTML='';
    const pick=document.createElement('div'); pick.id='weightTrendPick'; pick.className='wt-pick'; target.appendChild(pick);
    const chart=document.createElement('div'); chart.id='weightTrendBox'; chart.style.marginTop='8px'; target.appendChild(chart);
    renderWeightTrendSection();
  }
  const pr=$('performancePrBox'); if(pr) pr.remove();
}

function renderRMMapSection(){
  const box=$('rmMapBox'); if(!box)return;
  const App=window.App, gs=formalGroupsInRange().filter(g=>g.done!==false);
  const rows=FIXED_ACTIONS.map(a=>{
    const ag=fixedActionGroups(gs,a);
    let best=null;
    ag.forEach(g=>{const w=Number(g.weight),r=Number(g.reps);if(!isFinite(w)||w<=0||!isFinite(r)||r<1||r>12)return;const e1=w*(1+r/30);if(!best||e1>best.e1)best={action:a,e1,weight:w,reps:r,date:g.date,capacity:ag.reduce((sum,x)=>{const ww=Number(x.weight),rr=Number(x.reps)||0;return sum+(isFinite(ww)&&ww>0&&rr>0?ww*rr:0)},0)};});
    return {action:a,best};
  });
  const available=rows.filter(r=>r.best);
  if(!available.length){box.innerHTML='<div class="empty">暂无这 7 个固定动作的足够负重记录生成 RM 图谱。</div>';return;}
  const tags=rows.map((r,i)=>`<button type="button" class="rm-action${r.best&&r.action.id===available[0].best.action.id?' active':''}${r.best?'':' disabled'}" data-rm-key="${r.action.id}"><small>${r.best?r.best.e1.toFixed(0)+'kg':'—'}</small><span>${r.action.label}</span></button>`).join('');
  box.innerHTML=`<div class="rm-action-list fixed-action-grid">${tags}</div><div class="muted" style="font-size:10px;line-height:1.45;margin-top:7px">7 个固定动作按三大项 / 四个主要辅助动作分两行展示。RM 为同一动作内部的估算值，用于观察自身力量变化。</div>`;
  box.querySelectorAll('[data-rm-key]').forEach(btn=>btn.onclick=()=>{if(btn.classList.contains('disabled'))return;box.querySelectorAll('.rm-action').forEach(x=>x.classList.remove('active'));btn.classList.add('active');});
}


/* ─── 长期趋势热力图：与顶部时间滚动条筛选区间联动 ───── */
function renderLongTermHeatmap(){
  const box=$('longTermHeatmapBox');
  if(!box) return;
  const span=rangeDateSpan();
  const start=new Date(span.start+'T12:00:00');
  const end=new Date(span.end+'T12:00:00');
  if(!isFinite(start)||!isFinite(end)||start>end){
    box.innerHTML='';
    return;
  }

  // 只做“整体训练图谱”：31 个正方形一行，时间变长只向下增加行。
  // 不显示日期、星期、月份，不绑定点击事件，不弹出任何明细。
  const byDate={};
  formalGroupsInRange().forEach(g=>{
    if(!(g.done||Number(g.reps)>0)) return;
    const d=String(g.date||'').slice(0,10);
    if(!/^\d{4}-\d{2}-\d{2}$/.test(d)) return;
    const x=byDate[d]||(byDate[d]={sets:0,volume:0});
    x.sets++;
    const w=Number(g.weight),r=Number(g.reps)||0;
    if(isFinite(w)&&w>0&&r>0) x.volume+=w*r;
  });

  const dates=[];
  for(let d=new Date(start);d<=end;d.setDate(d.getDate()+1)){
    dates.push(d.toISOString().slice(0,10));
  }

  const values=dates.map(d=>byDate[d]?.sets||0).filter(v=>v>0).sort((a,b)=>a-b);
  const quantile=p=>{
    if(!values.length) return 0;
    if(values.length===1) return values[0];
    const i=(values.length-1)*p,lo=Math.floor(i),hi=Math.ceil(i);
    return values[lo]+(values[hi]-values[lo])*(i-lo);
  };
  const q25=quantile(.25),q50=quantile(.5),q75=quantile(.75);
  const level=n=>{
    if(!n) return 0;
    if(n<=q25) return 1;
    if(n<=q50) return 2;
    if(n<=q75) return 3;
    return 4;
  };

  let html='<div class="heat31-calendar"><div class="heat31-body">';
  for(let i=0;i<dates.length;i+=31){
    html+='<div class="heat31-row-wrap"><div class="heat31-grid">';
    for(let j=0;j<31;j++){
      const idx=i+j;
      if(idx>=dates.length){
        html+='<span class="heat31-cell empty" aria-hidden="true"></span>';
      }else{
        const d=dates[idx],lv=level(byDate[d]?.sets||0);
        html+=`<span class="heat31-cell" data-level="${lv}" aria-hidden="true"></span>`;
      }
    }
    html+='</div></div>';
  }
  html+='</div></div>';
  box.innerHTML=html;
  const badge=$('longHeatRangeBadge');
  if(badge) badge.style.display='none';
}

function renderLoadTrendSection(){
  const box=$('loadTrendBox'),note=$('loadTrendNote'),badge=$('loadTrendBadge');if(!box)return;
  const span=rangeDateSpan();let days=Math.max(1,dayDiff(span.start,span.end)+1);if(days>84)days=84;
  const endDate=span.end||todayStr(),end=new Date(endDate+'T12:00:00'),dates=[];for(let i=days-1;i>=0;i--){const d=new Date(end);d.setDate(d.getDate()-i);dates.push(d.toISOString().slice(0,10));}
  const gs=allGroups().filter(g=>g.type!=='热身'&&(g.done||g.reps>0)&&g.date>=dates[0]&&g.date<=dates.at(-1)),m=dayLoadMap(gs),vals=dates.map(d=>m[d]||0),active=vals.filter(v=>v>0),mid=Math.max(1,Math.floor(days/2)),a=vals.slice(0,mid),b=vals.slice(mid),avgA=a.reduce((x,y)=>x+y,0)/Math.max(a.length,1),avgB=b.reduce((x,y)=>x+y,0)/Math.max(b.length,1),delta=avgA?((avgB/avgA)-1)*100:0,max=Math.max(...vals,1);
  const w=360,h=150,p={l:28,r:10,t:14,b:25},X=i=>p.l+i*(w-p.l-p.r)/(Math.max(1,dates.length-1)),Y=v=>h-p.b-(v/max)*(h-p.t-p.b),pts=vals.map((v,i)=>`${X(i).toFixed(1)},${Y(v).toFixed(1)}`).join(' '),step=Math.max(1,Math.ceil(dates.length/6));
  box.innerHTML=`<svg viewBox="0 0 ${w} ${h}" style="width:100%;height:auto;display:block"><polyline points="${pts}" fill="none" stroke="var(--blue)" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"/>${vals.map((v,i)=>v&& (i%step===0||i===vals.length-1)?`<circle cx="${X(i).toFixed(1)}" cy="${Y(v).toFixed(1)}" r="2.6" fill="var(--blue)"><title>${dates[i]}：${v.toFixed(1)}</title></circle>`:'').join('')}<text x="${p.l}" y="${h-8}" font-size="9" fill="var(--muted)">${dates[0].slice(5)}</text><text x="${w-p.r}" y="${h-8}" text-anchor="end" font-size="9" fill="var(--muted)">${dates.at(-1).slice(5)}</text></svg><div style="display:grid;grid-template-columns:repeat(3,1fr);gap:7px;margin-top:6px"><div class="mini-stat"><b>${avgB.toFixed(1)}</b><span>后半段均负荷</span></div><div class="mini-stat"><b>${active.length}</b><span>训练日</span></div><div class="mini-stat"><b>${delta>=0?'+':''}${delta.toFixed(0)}%</b><span>较前半段</span></div></div>`;
  if(badge)badge.textContent=`${days}天 · ${active.length}个训练日`;
  if(note)note.textContent=active.length?`训练负荷指数由组数、次数带与 RIR 简化估算，仅用于观察训练压力的时间变化。当前区间后半段较前半段 ${delta>=0?'上升':'下降'} ${Math.abs(delta).toFixed(0)}%；它不等同于生理疲劳。`:'当前区间暂无足够正式训练记录。';
}
function renderMuscleCoverageSection(){
  const box=$('muscleCoverageBox'),badge=$('coverageBadge'),App=window.App;if(!box)return;
  const gs=selectedGroups().filter(g=>g.type!=='热身'&&(g.done||g.reps>0));
  const span=rangeDateSpan(),days=Math.max(1,dayDiff(span.start,span.end)+1),weeks=days/7;
  const parts=App.activePackParts().filter(p=>!/(有氧|心肺|拉伸|放松)/.test(p)),map={};
  parts.forEach(p=>map[p]={direct:0,indirect:0,days:new Set(),last:null});
  gs.forEach(g=>{const prof=App.profileFor(g.action,g.part),entries=Object.entries(prof.muscles||{});entries.forEach(([mus,w])=>{const p=muscleToPart(mus,prof.part||g.part);if(!map[p])return;const v=Number(w)||0;if(v>=.8)map[p].direct++;else map[p].indirect+=v;map[p].days.add(g.date);if(!map[p].last||g.date>map[p].last)map[p].last=g.date;});});
  const rows=parts.map(p=>{const x=map[p],total=x.direct+x.indirect*.5;return{p,...x,total,weekly:total/weeks};}),active=rows.filter(x=>x.total>0),avg=active.length?active.reduce((a,b)=>a+b.weekly,0)/active.length:0;
  box.innerHTML=`<div style="display:grid;grid-template-columns:1fr auto auto auto;gap:7px;padding:0 3px 6px;font-size:10px;color:var(--muted)"><span>肌群</span><span>周均组</span><span>频率</span><span>状态</span></div>${rows.map(r=>{const daysSince=r.last?dayDiff(r.last,todayStr()):null;let status='未覆盖',col='var(--orange)';if(r.total){if(r.weekly<Math.max(.5,avg*.55))status='偏少';else if(daysSince!=null&&daysSince>14)status='间隔长';else status='已覆盖';col=status==='已覆盖'?'var(--green)':'var(--orange)';}return `<div style="display:grid;grid-template-columns:1fr auto auto auto;gap:7px;align-items:center;padding:7px 3px;border-bottom:1px dashed var(--line);font-size:11.5px"><b>${r.p}</b><span><b>${r.weekly.toFixed(1)}</b></span><span>${r.days.size}天</span><span style="font-size:10px;font-weight:850;color:${col};white-space:nowrap">${status}</span></div><div style="display:grid;grid-template-columns:38px 1fr auto;gap:7px;align-items:center;padding:0 3px 6px"><span></span><div style="height:7px;background:var(--panel);border:1px solid var(--line);border-radius:99px;overflow:hidden"><div style="width:${Math.min(100,r.weekly/(Math.max(avg,1)*1.8)*100)}%;height:100%;background:color-mix(in srgb,var(--blue) 34%,var(--card))"></div></div><span style="font-size:9.5px;color:var(--muted)">${r.direct.toFixed(1)}直 / ${r.indirect.toFixed(1)}间</span></div>`;}).join('')||'<div class="empty">暂无肌群覆盖数据</div>'}<div class="muted" style="font-size:10.5px;line-height:1.5;margin-top:7px">周均组数按当前筛选区间折算。直接刺激按完整有效组计，间接刺激按肌群参与权重折算；它用于发现长期偏少或间隔过长，不等于精确的生理刺激量。</div>`;
  if(badge)badge.textContent=rangeLabel()+' · 直接/间接分开';
}
function metricForGroup(g){const w=Number(g.weight)||0,r=Number(g.reps)||0;if(w<=0||r<1||r>30)return null;return r<=10?w*(1+r/30):w;}
function AppNameKey(name){const App=window.App,s=App.normalizeExerciseName(name);return s||String(name||'').trim();}
function actionDailyMetrics(gs){const by={};gs.forEach(g=>{const k=AppNameKey(g.action),m=performanceMetric(g);if(!k||!m)return;(by[k]||(by[k]={}))[g.date]=Math.max(by[k][g.date]||0,m.score);});return by;}
function renderProgressSection(){
  const box=$('progressBox'),badge=$('progressBadge');if(!box)return;const gs=selectedGroups().filter(g=>g.type!=='热身'&&(g.done||g.reps>0)),dates=[...new Set(gs.map(g=>g.date))].sort();
  if(dates.length<4){box.innerHTML='<div class="empty">至少需要约 4 个训练日，才能判断阶段性进步趋势。</div>';if(badge)badge.textContent='数据不足';return;}
  const cut=dates[Math.floor(dates.length/2)],a=gs.filter(g=>g.date<=cut),b=gs.filter(g=>g.date>cut),byA=actionDailyMetrics(a),byB=actionDailyMetrics(b),keys=[...new Set([...Object.keys(byA),...Object.keys(byB)])];
  const capacity={}; gs.forEach(g=>{const w=Number(g.weight),r=Number(g.reps)||0,k=AppNameKey(g.action);if(k&&isFinite(w)&&w>0&&r>0)capacity[k]=(capacity[k]||0)+w*r;});
  const rows=keys.map(k=>{const va=Object.values(byA[k]||{}),vb=Object.values(byB[k]||{});if(va.length<2||vb.length<2)return null;const x=va.reduce((p,q)=>p+q,0)/va.length,y=vb.reduce((p,q)=>p+q,0)/vb.length;return{k,delta:(y/x-1)*100,n:va.length+vb.length,capacity:capacity[k]||0};}).filter(Boolean).sort((x,y)=>y.capacity-x.capacity||y.delta-x.delta);
  if(!rows.length){box.innerHTML='<div class="empty">当前区间没有足够的重复动作记录可比较。</div>';return;}
  const gsForFixedKey=a=>{const ag=fixedActionGroups(gs,a);return ag.length?AppNameKey(ag[0].action):null};
  const fixedRows=FIXED_ACTIONS.map(a=>{const key=gsForFixedKey(a);const r=rows.find(x=>x.k===key);return r||{k:a.label,delta:null,n:0,capacity:0,missing:true};});
  const up=fixedRows.filter(r=>r.delta!=null&&r.delta>2),down=fixedRows.filter(r=>r.delta!=null&&r.delta<-2),flat=fixedRows.filter(r=>r.delta!=null&&Math.abs(r.delta)<=2);
  box.innerHTML=`<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:7px;margin-bottom:10px"><div class="mini-stat"><b>${up.length}</b><span>表现提升</span></div><div class="mini-stat"><b>${flat.length}</b><span>基本持平</span></div><div class="mini-stat"><b>${down.length}</b><span>表现回落</span></div></div><div class="performance-action-rows"><div class="performance-action-row performance-main-actions">${fixedRows.slice(0,3).map((r,i)=>{const a=FIXED_ACTIONS[i];const has=r.delta!=null;return `<div class="fixed-action-tile"><b>${a.label}</b><span>${has?(r.delta>0?'+':'')+r.delta.toFixed(1)+'%':'—'}</span></div>`}).join('')}</div><div class="performance-action-row performance-assist-actions">${fixedRows.slice(3).map((r,i)=>{const a=FIXED_ACTIONS[i+3];const has=r.delta!=null;return `<div class="fixed-action-tile"><b>${a.label}</b><span>${has?(r.delta>0?'+':'')+r.delta.toFixed(1)+'%':'—'}</span></div>`}).join('')}</div></div><div class="muted" style="font-size:10.5px;margin-top:8px">固定跟踪三大项及四个主要辅助动作；表现比较仍只在同一动作内部进行，不比较不同动作的绝对力量。</div>`;
  if(badge)badge.textContent=rangeLabel()+' · '+rows.length+'个动作';
}
function renderConsistencySection(){
  const box=$('consistencyBox');if(!box)return;const gs=selectedGroups().filter(g=>g.type!=='热身'&&(g.done||g.reps>0)),dates=[...new Set(gs.map(g=>g.date))].sort();if(!dates.length){box.innerHTML='<div class="empty">暂无训练记录。</div>';return;}
  const span=Math.max(1,dayDiff(dates[0],dates.at(-1))+1),weeks=span/7,avg=dates.length/weeks,gaps=dates.slice(1).map((d,i)=>dayDiff(dates[i],d)),maxGap=gaps.length?Math.max(...gaps):0,activeWeeks=new Set(dates.map(d=>d.slice(0,7))).size;
  box.innerHTML=`<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px"><div class="mini-stat"><b>${dates.length}</b><span>训练日</span></div><div class="mini-stat"><b>${avg.toFixed(1)}</b><span>次/周</span></div><div class="mini-stat"><b>${maxGap}</b><span>最长间隔天</span></div><div class="mini-stat"><b>${activeWeeks}</b><span>活跃月份</span></div></div><div class="muted" style="font-size:11.5px;line-height:1.5;margin-top:9px">训练节奏按实际训练日期计算。最长间隔明显高于平时，通常意味着周期中存在中断；稳定性本身不等于训练效果，还要和动作表现一起看。</div>`;
}
function renderEfficiencySection(){
  const box=$('efficiencyBox');if(!box)return;const gs=analysisGroupsInWindow(84),dates=[...new Set(gs.map(g=>g.date))].sort();if(dates.length<6){box.innerHTML='<div class="empty">至少需要约 6 个训练日，才能观察训练投入与表现的关系。</div>';return;}
  const cut=dates[Math.floor(dates.length/2)],a=gs.filter(g=>g.date<=cut),b=gs.filter(g=>g.date>cut),loadA=a.reduce((s,g)=>s+setLoadValue(g),0),loadB=b.reduce((s,g)=>s+setLoadValue(g),0),perf=arr=>{const ms=arr.map(metricForGroup).filter(x=>x!=null);return ms.length?ms.reduce((x,y)=>x+y,0)/ms.length:0},pA=perf(a),pB=perf(b),ld=loadA?((loadB/loadA)-1)*100:0,pd=pA?((pB/pA)-1)*100:0,relation=Math.abs(pd)<2?'表现基本稳定':pd>0?'表现同步改善':'表现没有同步改善';
  box.innerHTML=`<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:8px"><div class="mini-stat"><b>${ld>=0?'+':''}${ld.toFixed(0)}%</b><span>训练投入变化</span></div><div class="mini-stat"><b>${pd>=0?'+':''}${pd.toFixed(1)}%</b><span>整体表现变化</span></div></div><div style="margin-top:10px;padding:10px 12px;background:var(--panel);border:1px solid var(--line);border-radius:11px;font-size:12px;line-height:1.55"><b>${relation}</b>。这里比较两个阶段的训练压力指数与可比较动作表现均值，不构成“每组训练产生多少力量”的因果效率评分。</div><div class="muted" style="font-size:10.5px;margin-top:7px">若训练投入持续增加而表现长期没有同步改善，可以进一步结合 RIR、训练频率、动作替换和恢复情况检查。</div>`;
}
function renderMilestonesSection(){
  const box=$('milestonesBox');if(!box)return;const gs=selectedGroups().filter(g=>g.type!=='热身'&&(g.done||g.reps>0)),prs={};
  gs.forEach(g=>{const w=Number(g.weight)||0,r=Number(g.reps)||0,k=AppNameKey(g.action);if(!k||w<=0||r<=0)return;const e1=r<=10?w*(1+r/30):0,cur=prs[k]||{maxW:0,maxReps:0,e1:0,wDate:'',rDate:'',eDate:''};if(w>cur.maxW){cur.maxW=w;cur.wDate=g.date;}if(r>cur.maxReps){cur.maxReps=r;cur.rDate=g.date;}if(e1>cur.e1){cur.e1=e1;cur.eDate=g.date;}prs[k]=cur;});
  const rows=Object.entries(prs).sort((a,b)=>b[1].e1-a[1].e1).slice(0,8),totalVolume=sumVolume(gs);
  box.innerHTML=`<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:7px;margin-bottom:10px"><div class="mini-stat"><b>${gs.length}</b><span>区间正式组</span></div><div class="mini-stat"><b>${Math.round(totalVolume).toLocaleString()}</b><span>区间训练量(kg)</span></div></div>${rows.map(([k,r])=>`<div style="display:grid;grid-template-columns:1fr auto;gap:8px;padding:6px 3px;border-bottom:1px dashed var(--line);font-size:11.5px"><span><b>${window.App.esc(k)}</b><small style="display:block;color:var(--muted);margin-top:2px">${r.maxW}kg · ${r.maxReps}次${r.e1?' · '+r.e1.toFixed(1)+'kg e1RM':''}</small></span><span style="text-align:right;color:var(--muted)">${r.wDate||r.rDate}</span></div>`).join('')||'<div class="empty">暂无可识别的重量/次数纪录。</div>'}<div class="muted" style="font-size:10.5px;margin-top:8px">纪录用于回顾训练历程；估算1RM仅用于同一动作内部追踪，不把不同动作的绝对力量放在一起比较。</div>`;
}
function renderCompactHeatmap(){
  const App=window.App;
  const byDate={};
  allGroups().forEach(g=>{
    if(g.done||g.reps>0){
      if(!byDate[g.date]) byDate[g.date]={sets:0,actions:new Set(),vol:0};
      byDate[g.date].sets++; byDate[g.date].actions.add(g.action);
      if(isFinite(Number(g.weight))) byDate[g.date].vol+=Number(g.weight)*g.reps;
    }
  });
  const span=rangeDateSpan();
  const start=new Date(span.start+'T00:00:00'), end=new Date(span.end+'T23:59:59');
  const daysTotal=Math.max(1,Math.round((Date.parse(span.end+'T00:00:00')-Date.parse(span.start+'T00:00:00'))/86400000)+1);
  const dates=[];
  for(let d=new Date(start);d<=end;d.setDate(d.getDate()+1)) dates.push(d.toISOString().slice(0,10));
  const trainedDays=dates.filter(d=>byDate[d]).length;
  $('heatStreakBadge').textContent=`区间出勤 ${trainedDays}天 / ${daysTotal}天 (${((trainedDays/daysTotal)*100).toFixed(1)}%)`;
  const trainedSets=dates.map(d=>byDate[d]?byDate[d].sets:0).filter(n=>n>0).sort((a,b)=>a-b);
  function heatLevel(n){
    if(!n) return '';
    if(!trainedSets.length) return 'l1';
    const q=p=>{ if(trainedSets.length===1) return trainedSets[0]; const i=(trainedSets.length-1)*p; const lo=Math.floor(i),hi=Math.ceil(i); return lo===hi?trainedSets[lo]:trainedSets[lo]+(trainedSets[hi]-trainedSets[lo])*(i-lo); };
    const t25=q(0.25),t50=q(0.5),t75=q(0.75);
    if(n<=t25) return 'l1'; if(n<=t50) return 'l2'; if(n<=t75) return 'l3'; return 'l4';
  }
  let gridHtml='';
  dates.forEach(ds=>{ const item=byDate[ds]; const n=item?item.sets:0; gridHtml+=`<div class="compact-heat-cell ${heatLevel(n)}" data-date="${ds}" title="${ds}${n?(' · '+n+'组'):' · 休息'}"></div>`; });
  $('compactHeatGrid').innerHTML=gridHtml;
  const heatGrid=$('compactHeatGrid');
  if(heatGrid){
    heatGrid.style.gridTemplateColumns='repeat(31,minmax(0,1fr))';
  }
  const heatDetail=$('compactHeatDetail');
  if(heatDetail) { heatDetail.style.display='none'; heatDetail.innerHTML=''; }
  document.querySelectorAll('.compact-heat-cell').forEach(cell=>{
    cell.onclick=null;
    cell.removeAttribute('title');
    cell.removeAttribute('data-date');
  });
}

/* ─── 5. 部位周均组数 ──────────────────────────── */
function rangeWeekCount(){
  const App=window.App;
  const r=App.state.historyRange;
  if(r==='7'||r==='30'||r==='90'||r==='365') return Math.max(1,Number(r)/7);
  if(String(r).startsWith('year-')){
    const y=Number(String(r).split('-')[1]);
    const isLeap=(y%4===0&&y%100!==0)||(y%400===0);
    return (isLeap?366:365)/7;
  }
  const allDates=[...new Set(formalGroupsInRange().map(g=>g.date).filter(d=>/^\d{4}-\d{2}-\d{2}$/.test(String(d||''))))].sort();
  if(allDates.length<2) return 1;
  const t0=new Date(allDates[0]+'T12:00:00').getTime();
  const t1=new Date(allDates[allDates.length-1]+'T12:00:00').getTime();
  if(!Number.isFinite(t0)||!Number.isFinite(t1)||t1<t0) return 1;
  return Math.max(1,((t1-t0)/86400000+1)/7);
}
function renderWeeklySetsSection(){
  const App=window.App;
  const box=$('weeklySetsBox'); if(!box) return;
  const gs=formalGroupsInRange();
  if(!gs.length){ box.innerHTML='<div class="empty">暂无数据</div>'; return; }
  const weeks=rangeWeekCount();
  const parts=App.activePackParts();
  const counts={}; parts.forEach(p=>counts[p]=0);
  gs.forEach(g=>{ const p=g.part||'其他'; if(counts[p]!=null) counts[p]++; });
  const LO=8,HI=20;
  const rows=parts.map(p=>{
    const total=counts[p]||0; const perW=total/weeks;
    let status='适中',col='var(--green)';
    if(perW<LO*0.5){ status='明显偏低'; col='var(--red)'; }
    else if(perW<LO){ status='偏低'; col='var(--orange)'; }
    else if(perW>HI){ status='偏高'; col='var(--orange)'; }
    else { status='合理'; col='var(--green)'; }
    return {p,total,perW,status,col};
  });
  rows.sort((a,b)=>b.perW-a.perW);
  const maxW=Math.max(...rows.map(r=>r.perW),HI,1);
  const loPct=LO/maxW*100, hiPct=HI/maxW*100;
  box.innerHTML=`
    <div style="font-size:11px;color:var(--muted);margin-bottom:6px">区间约 <b>${weeks.toFixed(1)}</b> 周 · 参考带 ${LO}–${HI} 组/周（灰带）</div>
    <div style="padding:2px 2px 4px">${rows.map(r=>{
      const pct=Math.min(100,r.perW/maxW*100);
      return `<div style="display:flex;align-items:center;gap:8px;padding:6px 4px;border-bottom:1px dashed var(--line)"><b style="flex:none;width:34px;font-size:12px;color:var(--text)">${r.p}</b><div style="flex:1;min-width:0;position:relative;height:11px;background:var(--panel);border:1px solid var(--line);border-radius:999px;overflow:hidden"><div style="position:absolute;left:${loPct}%;width:${Math.max(0,hiPct-loPct)}%;top:0;bottom:0;background:color-mix(in srgb,var(--green) 14%,transparent)"></div><div style="position:absolute;left:0;top:0;bottom:0;width:${pct}%;border-radius:999px;background:color-mix(in srgb,var(--blue) 34%,var(--card))"></div></div><div style="flex:none;text-align:right;white-space:nowrap;font-size:11.5px"><b style="color:var(--text)">${r.perW.toFixed(1)}</b> 组/周 <span style="font-size:10px;font-weight:800;color:${r.col};margin-left:4px">${r.status}</span></div></div>`;
    }).join('')}</div>`;
}

/* ─── 6. 部位组数占比 ──────────────────────────── */
function renderPartBalanceSection(){
  const App=window.App;
  const gs=formalGroupsInRange();
  const parts=App.activePackParts();
  const counts={}; parts.forEach(p=>counts[p]=0);
  gs.forEach(g=>{ const p=g.part||'其他'; if(counts[p]!=null) counts[p]++; else counts['其他']=(counts['其他']||0)+1; });
  const total=Object.values(counts).reduce((a,b)=>a+b,0)||1;
  const entries=parts.map(p=>({part:p,n:counts[p]||0,pct:(counts[p]||0)/total*100}));
  entries.sort((a,b)=>b.pct-a.pct);
  const maxPct=Math.max(...entries.map(e=>e.pct),1);
  const avg=100/(entries.filter(e=>e.n>0).length||1);
  const box=$('partBalanceBox'); if(!box) return;
  if(!gs.length){ box.innerHTML='<div class="empty">暂无部位数据</div>'; return; }
  const active=entries.filter(e=>e.n>0);
  const low=active.filter(e=>e.pct<avg*0.55).map(e=>e.part);
  const high=active.filter(e=>e.pct>avg*1.45).map(e=>e.part);
  const zero=entries.filter(e=>e.n===0).map(e=>e.part);
  box.innerHTML=`
    <div style="padding:2px 2px 4px">${entries.map(e=>{
      const bar=Math.max(2,(e.pct/maxPct)*100);
      let tag='',tagCol='var(--muted)';
      if(e.n===0){ tag='未练'; tagCol='var(--muted)'; }
      else if(high.includes(e.part)){ tag='偏多'; tagCol='var(--orange)'; }
      else if(low.includes(e.part)){ tag='偏少'; tagCol='var(--red)'; }
      else { tag='均衡'; tagCol='var(--green)'; }
      return `<div style="display:flex;align-items:center;gap:8px;padding:6px 4px;border-bottom:1px dashed var(--line)"><b style="flex:none;width:34px;font-size:12px;color:var(--text)">${e.part}</b><div style="flex:1;min-width:0;height:9px;background:var(--panel);border:1px solid var(--line);border-radius:999px;overflow:hidden"><div style="width:${bar}%;height:100%;border-radius:999px;background:color-mix(in srgb,var(--blue) 34%,var(--card))"></div></div><div style="flex:none;text-align:right;white-space:nowrap;font-size:11.5px"><b style="color:var(--text)">${e.pct.toFixed(0)}%</b><span style="font-size:10px;font-weight:800;color:${tagCol};margin-left:4px">${tag}</span></div></div>`;
    }).join('')}</div>
    <div style="margin-top:8px;padding:8px 12px;background:var(--panel);border-radius:10px;font-size:11.5px;line-height:1.5;color:var(--text)">
      ${high.length?`偏多：<b>${high.join('、')}</b>。`:''}
      ${low.length?`偏少：<b>${low.join('、')}</b>，可适当加组。`:''}
      ${zero.length?`长期未练：<b>${zero.join('、')}</b>。`:''}
      ${!high.length&&!low.length&&!zero.length?'各部位比例相对均衡，维持即可。':''}
    </div>`;
}

/* ─── 7. 推/拉/腿 ──────────────────────────────── */
function partToPpl(part){
  if(['胸','肩','三头','前臂'].includes(part)) return '推';
  if(['背','二头'].includes(part)) return '拉';
  if(['腿','臀','腹','小腿'].includes(part)) return '腿';
  return '其他';
}
function pplOfGroup(g){
  const App=window.App;
  let meta=null;
  if(g.exerciseId && App.db && App.db.exercises){
    const ex=App.db.exercises.find(z=>z.id===g.exerciseId);
    if(ex && ex.mkey && App.exerciseMeta[ex.mkey]) meta=App.exerciseMeta[ex.mkey];
  }
  if(!meta) meta=App.metaFor(g.action);
  if(meta && meta.动作模式 && App.constants.PACK_MODE_TO_PPL[meta.动作模式]) return App.constants.PACK_MODE_TO_PPL[meta.动作模式];
  return partToPpl(g.part||'其他');
}
function renderPplStructureSection(){
  const box=$('pplBalanceBox'); if(!box) return;
  const gs=formalGroupsInRange();
  if(!gs.length){ box.innerHTML='<div class="empty">暂无数据</div>'; return; }
  const cnt={推:0,拉:0,腿:0,其他:0};
  gs.forEach(g=>{ cnt[pplOfGroup(g)]++; });
  const total=cnt.推+cnt.拉+cnt.腿||1;
  const items=[{k:'推',n:cnt.推,tip:'胸 · 肩 · 三头'},{k:'拉',n:cnt.拉,tip:'背 · 二头'},{k:'腿',n:cnt.腿,tip:'腿 · 臀 · 腹'}];
  const maxN=Math.max(...items.map(x=>x.n),1);
  box.innerHTML=`
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:10px">${items.map(x=>{
      const pct=(x.n/total*100);
      return `<div style="text-align:center;padding:12px 8px;background:var(--panel);border:1px solid var(--line);border-radius:14px"><div style="font-size:11px;color:var(--muted);font-weight:750">${x.k}</div><div style="font-size:22px;font-weight:900;color:var(--text);margin:4px 0">${pct.toFixed(0)}%</div><div style="font-size:11px;color:var(--muted)">${x.n} 组</div><div style="font-size:10px;color:var(--muted);margin-top:2px">${x.tip}</div></div>`;
    }).join('')}</div>
    <div style="display:grid;gap:6px">${items.map(x=>{
      const bar=x.n/maxN*100;
      return `<div style="display:grid;grid-template-columns:28px 1fr 40px;gap:8px;align-items:center;font-size:12px"><b>${x.k}</b><div style="height:10px;background:var(--panel);border-radius:999px;overflow:hidden;border:1px solid var(--line)"><div style="width:${bar}%;height:100%;background:color-mix(in srgb,var(--blue) 34%,var(--card))"></div></div><span style="text-align:right;color:var(--muted)">${x.n}</span></div>`;
    }).join('')}</div>
    <div style="margin-top:10px;font-size:12px;color:var(--muted);line-height:1.5">推拉比约 <b>${cnt.拉?(cnt.推/cnt.拉).toFixed(2):'—'}</b>（推÷拉）。拉类长期明显少于推类时，肩部不适风险会上升。</div>`;
}

/* ─── 8. 训练刺激结构 ───────────────────────────── */
function renderIntensityStructureSection(){
  const box=$('intensityBox'); if(!box) return;
  const gs=formalGroupsInRange();
  if(!gs.length){ box.innerHTML='<div class="empty">暂无数据</div>'; return; }
  let s=0,h=0,e=0;
  gs.forEach(g=>{ const r=Number(g.reps)||0; if(r<=0) return; if(r<=5) s++; else if(r<=12) h++; else e++; });
  const t=s+h+e||1;
  const items=[
    {name:'力量区',range:'1–5 次',n:s,tip:'神经适应 / 最大力量'},
    {name:'肌肥大区',range:'6–12 次',n:h,tip:'增肌最常用次数带'},
    {name:'耐力区',range:'13+ 次',n:e,tip:'肌耐力 / 代谢刺激'}
  ];
  const maxN=Math.max(...items.map(x=>x.n),1);
  const dominant=items.slice().sort((a,b)=>b.n-a.n)[0];
  box.innerHTML=`
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:10px">${items.map(x=>`
      <div style="padding:10px 8px;background:var(--panel);border:1px solid var(--line);border-radius:12px;text-align:center"><div style="font-size:11px;color:var(--muted)">${x.name}</div><div style="font-size:20px;font-weight:900;margin:3px 0">${(x.n/t*100).toFixed(0)}%</div><div style="font-size:10px;color:var(--muted)">${x.range} · ${x.n}组</div></div>`).join('')}</div>
    <div style="display:grid;gap:6px">${items.map(x=>`
      <div style="display:grid;grid-template-columns:64px 1fr 36px;gap:8px;align-items:center;font-size:12px"><span>${x.name}</span><div style="height:10px;background:var(--panel);border-radius:999px;overflow:hidden;border:1px solid var(--line)"><div style="width:${x.n/maxN*100}%;height:100%;background:color-mix(in srgb,var(--blue) 34%,var(--card))"></div></div><span style="text-align:right;color:var(--muted)">${x.n}</span></div>`).join('')}</div>
    <div style="margin-top:10px;font-size:12px;color:var(--muted);line-height:1.5">当前以 <b style="color:var(--text)">${dominant.name}</b> 为主（${dominant.tip}）。次数带应与目标一致：练力量可提高 1–5 次组占比，练围度则保持 6–12 为主。</div>`;
}

/* ─── 9. 主项力量 ─────────────────────────────── */
function nameFormsOf(g){
  const App=window.App;
  const forms=[String(g.action||'')];
  if(g.exerciseId && App.db && App.db.exercises){
    const ex=App.db.exercises.find(z=>z.id===g.exerciseId);
    if(ex){
      if(ex.orig) forms.push(String(ex.orig));
      const m=ex.mkey && App.exerciseMeta[ex.mkey];
      if(m){ forms.push(String(m.中文名||''),String(m.英文名||'')); }
    }
  }
  return forms.filter(Boolean);
}
function groupsForCoreLift(groups,lift){ return groups.filter(g=>nameFormsOf(g).some(f=>lift.test(f))); }
function coreLiftDisplayName(lift,groups){
  const App=window.App;
  for(const g of groups||[]){
    if(g.exerciseId && App.db && App.db.exercises){
      const ex=App.db.exercises.find(z=>z.id===g.exerciseId);
      if(ex){
        if(ex.mkey && App.exerciseMeta[ex.mkey]) return App.exerciseMeta[ex.mkey].中文名||ex.name;
        if(ex.orig){ const ok=App.normalizeExerciseName(ex.orig), m=ok&&App.exerciseMeta[ok]; if(m) return m.中文名||ex.name; }
      }
    }
    const m=App.metaFor(g.action);
    if(m && lift.test(m.中文名||'')) return m.中文名;
  }
  return lift.label;
}
function maxWeightInGroups(list){ let m=0; list.forEach(g=>{const w=Number(g.weight);if(isFinite(w)&&w>m) m=w;}); return m; }
function bestE1rmInGroups(list){
  let best=0,bestSet=null;
  list.forEach(g=>{
    const w=Number(g.weight); if(!isFinite(w)||w<=0) return;
    const r=Number(g.reps)||0; if(r<=0) return;
    const e=w*(1+r/30); if(e>best){ best=e; bestSet={w,r}; }
  });
  return {e1rm:best,set:bestSet};
}
function prevRangeGroups(){
  const App=window.App;
  const r=App.state.historyRange;
  if(r==='7'||r==='30'||r==='90'||r==='365'){
    const n=Number(r), now=Date.now();
    const curSince=now-n*86400000, prevSince=curSince-n*86400000;
    return allGroups().filter(g=>{const t=new Date(g.date+'T23:59:59').getTime();return t>=prevSince&&t<curSince;});
  }
  if(r.startsWith('year-')){ const py=Number(r.split('-')[1])-1; return allGroups().filter(g=>g.date.startsWith(String(py))); }
  if(r.startsWith('range-')){
    const [a,b]=r.slice(6).split('_');
    const len=Math.round((Date.parse(b+'T00:00:00')-Date.parse(a+'T00:00:00'))/86400000)+1;
    const pe=new Date(a+'T12:00:00'); pe.setDate(pe.getDate()-1);
    const ps=new Date(pe); ps.setDate(ps.getDate()-(len-1));
    const psStr=ps.toISOString().slice(0,10), peStr=pe.toISOString().slice(0,10);
    return allGroups().filter(g=>g.date>=psStr&&g.date<=peStr);
  }
  return [];
}
function renderStrengthTrendSection(){
  const App=window.App;
  const box=$('strengthTrendBox'); if(!box) return;
  const inRange=formalGroupsInRange();
  const prev=prevRangeGroups();
  const LIFTS=App.constants.CORE_LIFTS_ALL;
  function rowFor(lift){
    const gRange=groupsForCoreLift(inRange,lift);
    const gPrev=groupsForCoreLift(prev,lift);
    const curMax=maxWeightInGroups(gRange);
    const prevMax=maxWeightInGroups(gPrev);
    const e1rm=bestE1rmInGroups(gRange).e1rm;
    let delta=null,status='—';
    if(curMax>0&&prevMax>0){ delta=(curMax-prevMax)/prevMax*100; status=delta>=3?'↑':(delta<=-3?'↓':'→'); }
    else if(curMax>0) status='新';
    return {lift,disp:coreLiftDisplayName(lift,gRange),curMax,prevMax,e1rm,delta,status};
  }
  function barRow(r){
    const col=r.status==='↑'?'var(--green)':(r.status==='↓'?'var(--red)':(r.status==='新'?'var(--teal)':'var(--blue2)'));
    const badge=r.status==='新'?'新纪录':(r.delta==null?'—':`${r.status}${r.delta>0?'+':''}${r.delta.toFixed(1)}%`);
    if(r.curMax<=0) return `<div style="display:flex;align-items:center;gap:10px;padding:9px 4px;border-bottom:1px dashed var(--line)"><b style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12.5px;color:var(--text)">${App.esc(r.disp)}</b><span class="muted" style="flex:none;font-size:11px">本区间暂无记录</span></div>`;
    return `<div style="display:flex;align-items:center;gap:10px;padding:9px 4px;border-bottom:1px dashed var(--line)"><b style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12.5px;color:var(--text)" title="${App.esc(r.disp)}">${App.esc(r.disp)}</b><div style="flex:none;text-align:right;font-weight:900;font-size:13.5px;color:var(--text)">${r.curMax}<span style="font-size:10px;font-weight:600;color:var(--muted)">kg</span><div style="font-size:9.5px;font-weight:600;color:var(--muted)">1RM≈${Math.round(r.e1rm||0)}kg</div></div><div style="flex:none;min-width:60px;text-align:right;font-size:11px;font-weight:850;color:${col}">${badge}</div></div>`;
  }
  box.innerHTML=`<div style="padding:2px 2px 4px">${LIFTS.map(l=>barRow(rowFor(l))).join('')}</div>
    <div class="muted" style="font-size:10.5px;margin-top:8px;line-height:1.45">区间最大 = 该区间内举起的最大重量；预估 1RM = 重量×(1+次数/30)（Epley）；涨跌幅 = 与上一个同长区间最大重量的变化。主项按资源包规范名自动归类，导入前的老名称同样识别；深蹲/卧推/硬拉不含变式。</div>`;
}

/* ─── 10. PR 汇总 ────────────────────────────── */
function renderPrsSection(){
  const App=window.App;
  const box=$('prsBox'); if(!box) return;
  const inRange=formalGroupsInRange();
  const all=allGroups().filter(g=>(g.type||'正式')!=='热身'&&(g.done||Number(g.reps)>0));
  if(!inRange.length){ box.innerHTML='<div class="empty">暂无数据</div>'; return; }
  function maxWeightOn(list,name){ let m=0; list.filter(g=>g.action===name).forEach(g=>{const w=Number(g.weight);if(isFinite(w)&&w>m) m=w;}); return m; }
  const cnt={};
  inRange.forEach(g=>{ cnt[g.action]=(cnt[g.action]||0)+1; });
  const names=Object.keys(cnt).sort((a,b)=>cnt[b]-cnt[a]);
  const rows=names.map(name=>{
    const cur=maxWeightOn(inRange,name), life=maxWeightOn(all,name);
    return {name,cur,life,isBest:cur>0&&cur===life,sets:cnt[name]};
  }).filter(r=>r.cur>0).sort((a,b)=>b.cur-a.cur).slice(0,15);
  if(!rows.length){ box.innerHTML='<div class="empty">本区间暂无带重量的正式组</div>'; return; }
  box.innerHTML=`<div style="font-size:11.5px;color:var(--muted);margin-bottom:8px;line-height:1.45">本筛选期内各动作的最大重量；「历史最佳」表示同时也是全部历史中的最高。</div>
    <div class="pr-table-wrap"><table class="pr-table"><thead><tr><th style="text-align:left">动作</th><th>区间最大</th><th>备注</th></tr></thead><tbody>
      ${rows.map(r=>`<tr><td><span class="pr-name" title="${App.esc(r.name)}">${App.esc(r.name)}</span></td><td><b>${r.cur}</b> <span style="font-size:11px;color:var(--muted)">kg</span></td><td>${r.isBest?'<span class="pr-best">历史最佳</span>':`<span style="font-size:11px;color:var(--muted)">历史 ${r.life} kg</span>`}</td></tr>`).join('')}
    </tbody></table></div>`;
}

/* ─── 11. 高频动作 Top ──────────────────────────── */
function renderTopExercisesSection(){
  const App=window.App;
  const box=$('topExBox'); if(!box) return;
  const gs=formalGroupsInRange();
  if(!gs.length){ box.innerHTML='<div class="empty">暂无数据</div>'; return; }
  const by={};
  gs.forEach(g=>{
    if(!by[g.action]) by[g.action]={sets:0,vol:0,part:g.part||''};
    by[g.action].sets++;
    const w=Number(g.weight); if(isFinite(w)) by[g.action].vol+=w*(Number(g.reps)||0);
  });
  const rows=Object.entries(by).map(([name,v])=>({name,...v})).sort((a,b)=>b.sets-a.sets).slice(0,8);
  const maxS=rows[0]?.sets||1;
  const medal=i=>i===0?'#f3b61f':i===1?'#9aa5b1':i===2?'#c9895b':'var(--muted)';
  box.innerHTML=`<div style="padding:2px 2px 4px">${rows.map((r,i)=>`
    <div style="display:flex;align-items:center;gap:8px;padding:8px 4px;border-bottom:1px dashed var(--line)"><span style="flex:none;width:20px;text-align:center;font-size:12px;font-weight:900;color:${medal(i)}">${i+1}</span><b style="flex:none;min-width:0;max-width:130px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:13px;color:var(--text)">${App.esc(r.name)}</b><div style="flex:1;min-width:0;height:9px;background:var(--panel);border:1px solid var(--line);border-radius:999px;overflow:hidden"><div style="width:${Math.max(3,r.sets/maxS*100)}%;height:100%;border-radius:999px;background:color-mix(in srgb,var(--blue) 34%,var(--card))"></div></div><div style="flex:none;text-align:right;white-space:nowrap;font-size:11px;color:var(--muted)"><b style="color:var(--text);font-size:13px">${r.sets}</b> 组 · ${App.fmtVolume(r.vol)}</div></div>`).join('')}</div>`;
}

/* ─── 12. 单动作重量趋势 ───────────────────────── */
function renderWeightTrendSection(){
  const App=window.App, state=App.state;
  const pick=$('weightTrendPick'), box=$('weightTrendBox'); if(!pick||!box) return;
  const inRange=formalGroupsInRange().filter(g=>g.done!==false);
  const byAction={};
  FIXED_ACTIONS.forEach(a=>{
    const gs=fixedActionGroups(inRange,a);
    const byDay={};
    gs.forEach(g=>{const w=Number(g.weight),r=Number(g.reps)||0;if(!isFinite(w)||w<=0||r<1||r>30)return;const pm=performanceMetric(g);if(!pm)return;const day=byDay[g.date]||(byDay[g.date]={metric:-1,weight:0,reps:0});if(pm.score>day.metric){day.metric=pm.score;day.weight=w;day.reps=r;}});
    byAction[a.id]={action:a,gs,byDay,capacity:gs.reduce((sum,g)=>{const w=Number(g.weight),r=Number(g.reps)||0;return sum+(isFinite(w)&&w>0&&r>0?w*r:0)},0)};
  });
  const available=FIXED_ACTIONS.filter(a=>Object.keys(byAction[a.id].byDay).length);
  if(!available.length){pick.style.display='none';box.innerHTML='<div class="empty">当前区间暂无这 7 个固定动作的可比较负重记录。</div>';return;}
  if(!state.weightTrendFixedId||!byAction[state.weightTrendFixedId]||!Object.keys(byAction[state.weightTrendFixedId].byDay).length) state.weightTrendFixedId=available[0].id;
  pick.style.display='grid';
  pick.innerHTML=FIXED_ACTIONS.map(a=>{const ok=Object.keys(byAction[a.id].byDay).length;return `<button type="button" class="fixed-action-tab${a.id===state.weightTrendFixedId?' active':''}${ok?'':' disabled'}" data-fixed-action="${a.id}">${a.label}</button>`}).join('');
  pick.querySelectorAll('[data-fixed-action]').forEach(b=>b.onclick=()=>{if(b.classList.contains('disabled'))return;state.weightTrendFixedId=b.dataset.fixedAction;renderWeightTrendSection();});
  const cur=byAction[state.weightTrendFixedId], pts=Object.keys(cur.byDay).sort().map(d=>({d,...cur.byDay[d]}));
  const base=pts[0].metric||1,indexed=pts.map(p=>({...p,index:100*p.metric/base}));
  const last=indexed[indexed.length-1],best=indexed.reduce((a,b)=>b.index>a.index?b:a,indexed[0]);
  const vals=indexed.map(p=>p.index),minV=Math.min(...vals,95),maxV=Math.max(...vals,105),span=Math.max(10,maxV-minV);
  const w=350,h=175,p={l:34,r:18,t:22,b:30},n=indexed.length;
  const X=i=>n===1?(p.l+(w-p.l-p.r)/2):p.l+i*(w-p.l-p.r)/(n-1),Y=v=>h-p.b-((v-(minV-span*.08))/(span*1.16))*(h-p.t-p.b);
  const line=indexed.map((pt,i)=>`${X(i).toFixed(1)},${Y(pt.index).toFixed(1)}`).join(' ');
  const dots=indexed.map((pt,i)=>`<circle cx="${X(i).toFixed(1)}" cy="${Y(pt.index).toFixed(1)}" r="${i===n-1||pt===best?4:3}" fill="${pt===best?'var(--green)':'var(--blue)'}"><title>${pt.d}：指数 ${pt.index.toFixed(1)}，${pt.weight}kg × ${pt.reps}次</title></circle>`).join('');
  const step=Math.max(1,Math.ceil(n/5));let labels='';indexed.forEach((pt,i)=>{if(i%step===0||i===n-1)labels+=`<text x="${X(i).toFixed(1)}" y="${h-10}" text-anchor="middle" font-size="9.5" fill="var(--muted)">${pt.d.slice(5)}</text>`;});
  let grid='';[0,0.5,1].forEach(f=>{const v=minV+span*f,yy=Y(v);grid+=`<line x1="${p.l}" y1="${yy.toFixed(1)}" x2="${w-p.r}" y2="${yy.toFixed(1)}" stroke="var(--line)" stroke-dasharray="3 3"/><text x="5" y="${(yy+3).toFixed(1)}" font-size="9" fill="var(--muted)">${Math.round(v)}</text>`;});
  const delta=last.index-100,sign=delta>0?'+':'';
  box.innerHTML=`<div class="svg-chart-container"><svg viewBox="0 0 ${w} ${h}" style="width:100%;height:auto;display:block"><line x1="${p.l}" y1="${Y(100)}" x2="${w-p.r}" y2="${Y(100)}" stroke="var(--muted)" stroke-dasharray="4 4" opacity=".7"/>${grid}<polyline points="${line}" fill="none" stroke="var(--blue)" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round"/>${dots}${labels}</svg></div><div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:8px;padding:10px 4px 2px;border-top:1px dashed var(--line)"><div style="font-size:12px;color:var(--muted)">最新表现 <b style="color:var(--text);font-size:14px">${last.index.toFixed(1)}</b></div><div style="font-size:12px;color:var(--muted)">基准变化 <b style="color:${delta>=0?'var(--green)':'var(--orange)'};font-size:14px">${sign}${delta.toFixed(1)}%</b></div><div style="font-size:12px;color:var(--muted)">区间容量 <b style="color:var(--text);font-size:14px">${App.fmtVolume(cur.capacity)}</b></div></div><div class="muted" style="font-size:11px;line-height:1.5;margin-top:7px">动作固定为三大项及四个主要辅助动作；每个动作的趋势按自身可比较表现计算，动作选择不再由次数或出现频率决定。</div>`;
}

/* ─── 13. RIR 强度分析 ──────────────────────────── */
function renderRirAnalysisSection(){
  const box=$('rirStatsBox'); if(!box) return;
  const gs=formalGroupsInRange().filter(g=>{ const r=g.rir; return r!==''&&r!=null&&isFinite(Number(r)); });
  if(!gs.length){ box.innerHTML='<div class="empty">本区间几乎没有填写 RIR。在训练页打开动作的 RIR 并记录后，这里会分析强度分布。</div>'; return; }
  const buckets=[0,0,0,0,0];
  let sum=0;
  gs.forEach(g=>{
    let v=Number(g.rir); if(v<0) v=0; sum+=v;
    if(v<=0) buckets[0]++; else if(v<=1) buckets[1]++; else if(v<=2) buckets[2]++; else if(v<=3) buckets[3]++; else buckets[4]++;
  });
  const n=gs.length;
  const avg=sum/n;
  const nearFail=(buckets[0]+buckets[1])/n*100;
  const easy=buckets[4]/n*100;
  const maxB=Math.max(...buckets,1);
  const labels=['0 力竭','1','2','3','4+ 较轻松'];
  const tips=avg<=1.2?'平均 RIR 偏低，多数组接近力竭。力量期可以，但长期全部力竭不利于恢复与技术。':avg<=2.5?'平均 RIR 在 1～3，属于常见的有效刺激区间（尤其肌肥大）。':'平均 RIR 偏高，组内还有较多余力。若目标是进步，可在安全前提下略增重量或次数。';
  box.innerHTML=`
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px">
      <div style="padding:10px;background:var(--panel);border:1px solid var(--line);border-radius:12px;text-align:center"><div style="font-size:11px;color:var(--muted)">平均 RIR</div><div style="font-size:22px;font-weight:900;margin-top:2px">${avg.toFixed(1)}</div></div>
      <div style="padding:10px;background:var(--panel);border:1px solid var(--line);border-radius:12px;text-align:center"><div style="font-size:11px;color:var(--muted)">接近力竭</div><div style="font-size:22px;font-weight:900;margin-top:2px">${nearFail.toFixed(0)}%</div><div style="font-size:10px;color:var(--muted)">RIR ≤ 1</div></div>
      <div style="padding:10px;background:var(--panel);border:1px solid var(--line);border-radius:12px;text-align:center"><div style="font-size:11px;color:var(--muted)">较轻松组</div><div style="font-size:22px;font-weight:900;margin-top:2px">${easy.toFixed(0)}%</div><div style="font-size:10px;color:var(--muted)">RIR ≥ 4</div></div>
    </div>
    <div style="font-size:12px;font-weight:800;margin-bottom:6px">RIR 分布（${n} 组有记录）</div>
    <div style="display:grid;gap:6px">${buckets.map((b,i)=>{
      const pct=b/n*100; const w=b/maxB*100;
      return `<div style="display:grid;grid-template-columns:64px 1fr 52px;gap:8px;align-items:center;font-size:12px"><span style="color:var(--muted)">${labels[i]}</span><div style="height:10px;background:var(--panel);border-radius:999px;overflow:hidden;border:1px solid var(--line)"><div style="width:${w}%;height:100%;background:color-mix(in srgb,var(--blue) 34%,var(--card))"></div></div><span style="text-align:right"><b>${b}</b> <span style="color:var(--muted)">${pct.toFixed(0)}%</span></span></div>`;
    }).join('')}</div>
    <div style="margin-top:10px;padding:9px 12px;background:var(--soft);border-radius:10px;font-size:12px;line-height:1.5">${tips}</div>`;
}

/* ─── 14. 疲劳与恢复 ───────────────────────────── */
function muscleToPart(muscleName,fallbackPart){
  const App=window.App;
  const m=String(muscleName||'');
  if(/胸/.test(m)) return '胸';
  if(/背|斜方|背阔|下背/.test(m)) return '背';
  if(/三角|肩/.test(m)) return '肩';
  if(/二头|肱二/.test(m)) return '二头';
  if(/三头|肱三/.test(m)) return '三头';
  if(/前臂/.test(m)) return '前臂';
  if(/小腿/.test(m)) return '小腿';
  if(/股四|腘绳|腿/.test(m)) return '腿';
  if(/臀/.test(m)) return '臀';
  if(/核心|腹/.test(m)) return '腹';
  const fp=String(fallbackPart||'');
  if(App.constants.PARTS.includes(fp)&&fp!=='全部') return fp;
  return '背';
}
function fatigueScoreByPart(){
  const App=window.App;
  // 有氧/心肺不是局部肌群，不进入肌群恢复环；拉伸类也不计入力量疲劳。
  const parts=App.activePackParts().filter(p=>!/(有氧|心肺|拉伸|放松)/.test(p));
  const raw={}; parts.forEach(p=>raw[p]=0);
  const now=Date.now();
  allGroupsRaw().forEach(g=>{
    if((g.type||'正式')==='热身') return;
    if(!g.done) return;
    const reps=Number(g.reps)||0;
    const rir=(g.rir!==''&&g.rir!=null&&isFinite(Number(g.rir)))?Number(g.rir):null;
    const dt=new Date(String(g.date).slice(0,10)+'T23:59:59').getTime();
    if(!isFinite(dt)) return;
    const ageH=(now-dt)/3600000;
    if(ageH<0||ageH>24*14) return;
    const decay=Math.pow(0.5,ageH/36); // 简化的 36 小时疲劳半衰期，作为趋势估算
    const prof=App.profileFor(g.action,g.part);
    const sourcePart=App.packPart(prof.part||g.part||'');
    // 有氧训练不伪装成肌群训练；其全身/心肺负荷不在本卡片估算。
    if(/有氧|心肺/.test(String(sourcePart)) || /心肺/.test(Object.keys(prof.muscles||{}).join(' '))) return;
    const repFactor=reps>0?(reps<=5?1.1:(reps<=15?1:0.85)):1;
    const effortFactor=rir===null?1:(rir<=1?1.35:(rir<=2?1.15:(rir<=3?1:(rir<=5?0.8:0.6))));
    const base=20*repFactor*effortFactor;
    const muscles=prof.muscles&&Object.keys(prof.muscles).length?prof.muscles:{[prof.part||g.part||'背']:1};
    const sumW=Object.values(muscles).reduce((a,b)=>a+Number(b||0),0)||1;
    Object.entries(muscles).forEach(([mName,w])=>{
      let part=muscleToPart(mName,prof.part||g.part);
      if(raw[part]==null && raw[sourcePart]!=null) part=sourcePart;
      if(raw[part]==null) return;
      raw[part]+=base*(Number(w)||0)/sumW*decay;
    });
  });
  const scores={};
  parts.forEach(p=>{ scores[p]=Math.min(99,Math.round(100*(1-Math.exp(-(raw[p]||0)/55)))); });
  return scores;
}
function fatigueColor(v){ return v>=60?'color-mix(in srgb,var(--red) 45%,var(--card))':v>=25?'color-mix(in srgb,var(--orange) 45%,var(--card))':'color-mix(in srgb,var(--green) 45%,var(--card))'; }
function fatigueText(v){ return v>=60?'高疲劳':v>=25?'中负荷':'已恢复'; }
function renderFatigueSection(){
  const App=window.App;
  const box=$('fatigueRings'); if(!box) return;
  const scores=fatigueScoreByPart();
  const parts=App.activePackParts().filter(p=>!/(有氧|心肺|拉伸|放松)/.test(p)).sort((a,b)=>App.partSizeRank(a)-App.partSizeRank(b));
  const R=28,ST=6,C=2*Math.PI*R;
  box.innerHTML=parts.map(name=>{
    const sc=Math.max(0,Math.min(100,scores[name]||0));
    const col=fatigueColor(sc);
    const off=C*(1-sc/100);
    return `<div class="fatigue-ring-item" title="${App.esc(name)} ${sc}% · ${fatigueText(sc)}">
      <svg class="fatigue-ring-svg" viewBox="0 0 72 72" aria-hidden="true">
        <circle cx="36" cy="36" r="${R}" fill="none" stroke="var(--line)" stroke-width="${ST}"/>
        <circle cx="36" cy="36" r="${R}" fill="none" stroke="${col}" stroke-width="${ST}" stroke-linecap="round" stroke-dasharray="${C.toFixed(2)}" stroke-dashoffset="${off.toFixed(2)}" transform="rotate(-90 36 36)"/>
        <text x="36" y="33" text-anchor="middle" dominant-baseline="central" font-size="17" font-weight="900" fill="var(--text)">${App.esc(name)}</text>
        <text x="36" y="50" text-anchor="middle" dominant-baseline="central" font-size="12" font-weight="800" fill="${col}">${sc}%</text>
      </svg></div>`;
  }).join('');
  const ranked=parts.map(p=>({p,s:scores[p]||0})).sort((a,b)=>b.s-a.s);
  const high=ranked.filter(x=>x.s>=60).map(x=>x.p);
  const fresh=ranked.filter(x=>x.s<25).map(x=>x.p);
  let daysSince=null;
  allGroupsRaw().forEach(g=>{
    if((g.type||'正式')==='热身'||!g.done) return;
    const t=new Date(String(g.date).slice(0,10)+'T23:59:59').getTime();
    if(!isFinite(t)) return;
    const d=Math.floor((Date.now()-t)/86400000);
    if(d>=0&&(daysSince===null||d<daysSince)) daysSince=d;
  });
  let advise='肌群疲劳为训练组数、次数与 RIR 的简化趋势估算；不使用绝对重量，实际恢复还受睡眠、营养和个人差异影响。 ';
  advise+=daysSince===null?'近 14 天暂无训练记录。':(daysSince===0?'今天已训练 · 估算疲劳随时间下降':'距上次正式训练 '+daysSince+' 天 · 估算疲劳随休息下降');
  if(high.length&&fresh.length) advise+=' 偏高：'+high.join('、')+'。相对轻松：'+fresh.slice(0,3).join('、')+'。';
  else if(high.length) advise+=' '+high.join('、')+' 疲劳偏高，注意安排恢复。';
  else if(ranked.every(x=>x.s===0)) advise+=' 近 14 天暂无已完成的正式组，完成打卡后这里会显示各部位疲劳。';
  if(!advise) advise='近 14 天负荷分散，整体恢复良好。';
  const bal=$('fatigueBalanceSummary');
  if(bal){
    const active=ranked.filter(x=>x.s>0);
    const hi=active[0],lo=active.length?active[active.length-1]:null;
    bal.innerHTML=`<div style="display:flex;flex-wrap:wrap;gap:6px"><span class="metric-chip">当前最高疲劳 <b>${hi?App.esc(hi.p):'—'}</b>${hi?` ${hi.s}%`:''}</span><span class="metric-chip">当前最低负荷 <b>${lo?App.esc(lo.p):'—'}</b>${lo?` ${lo.s}%`:''}</span><span class="metric-chip">需关注 <b>${high.length}</b> 个部位</span></div>`;
  }
  const adv=$('fatigueGlobalAdvise'); if(adv) adv.innerHTML=advise;
}

/* ─── 15. 卡片排序 ─────────────────────────────── */
function normalizeStatsOrder(order){
  const App=window.App;
  const valid=new Set(App.constants.STATS_CARD_DEFAULTS); const src=Array.isArray(order)?order:[];
  const clean=src.filter(id=>valid.has(id)); const out=[];
  STATS_GROUPS.forEach(g=>{g.ids.forEach(id=>{if(clean.includes(id))out.push(id);});});
  STATS_GROUPS.forEach(g=>{g.ids.forEach(id=>{if(!out.includes(id))out.push(id);});});
  return out;
}
function applyStatsCardOrder(){
  const App=window.App,container=$('statsCardsContainer'); if(!container)return;
  const order=normalizeStatsOrder(App.state.statsCardOrder); App.state.statsCardOrder=order;
  STATS_GROUPS.forEach(g=>{const wrap=container.querySelector(`.stats-group[data-group="${g.id}"]`),body=wrap&&wrap.querySelector('.stats-group-body');if(!body)return;g.ids.forEach(id=>{const el=$(id);if(el)body.appendChild(el);});const sorted=g.ids.slice().sort((a,b)=>order.indexOf(a)-order.indexOf(b));sorted.forEach(id=>{const el=$(id);if(el)body.appendChild(el);});});
}
function openStatsSortModal(){
  const App=window.App; let currentOrder=normalizeStatsOrder(App.state.statsCardOrder); let listRoot=null;
  function groupItems(g){return currentOrder.filter(id=>g.ids.includes(id));}
  function save(){App.state.statsCardOrder=[...currentOrder];App.save();applyStatsCardOrder();App.closeModal();App.toast('统计板块排序已保存');}
  $('sheet').className='sheet';
  $('sheet').innerHTML=`<div class="row between"><h2 style="margin:0;font-size:18px;font-weight:900">🔀 排序统计板块</h2><button id="sortClose" class="link-btn">关闭</button></div><div class="sort-hint">现在按分组分别排序。<b>只能在同一组内拖动</b>，不会把卡片拖到其他组。</div><div id="statsSortGroups"></div><div class="sort-footer"><button id="resetSortBtn" class="btn small" style="flex:1">恢复默认</button><button id="saveSortBtn" class="btn small primary" style="flex:2">保存并应用</button></div>`;
  $('modal').classList.add('show'); listRoot=$('statsSortGroups');
  function renderLists(){listRoot.innerHTML=STATS_GROUPS.map((g,gi)=>`<div class="sort-group-block" data-sort-group="${g.id}"><div class="sort-group-title"><b>${g.title}</b><span>${g.ids.length} 项</span></div><div class="stats-sort-list" data-sort-list="${g.id}">${groupItems(g).map((cid,i)=>{const info=ALL_STATS_CARDS.find(c=>c.id===cid);return `<div class="stats-sort-item" data-id="${cid}"><span class="stats-sort-idx">${i+1}</span><span class="stats-sort-name">${App.esc(info.short)}</span></div>`;}).join('')}</div></div>`).join('');bindDrag();}
  function bindDrag(){listRoot.querySelectorAll('.stats-sort-list').forEach(list=>{let src=null,sx=0,sy=0,active=false;const move=e=>{if(!src)return;e.preventDefault();const dx=e.clientX-sx,dy=e.clientY-sy;if(!active){if(Math.hypot(dx,dy)<6)return;active=true;src.classList.add('dragging');}src.style.transform=`translate(${dx}px,${dy}px) scale(1.04)`;const others=[...list.querySelectorAll('.stats-sort-item')].filter(x=>x!==src);let target=null;for(const el of others){const r=el.getBoundingClientRect();if(e.clientY<r.top+r.height/2){target=el;break;}}if(target)list.insertBefore(src,target);else list.appendChild(src);};const up=()=>{if(src){src.classList.remove('dragging');src.style.transform='';}src=null;active=false;syncOrder();list.removeEventListener('pointermove',move);list.removeEventListener('pointerup',up);list.removeEventListener('pointercancel',up);};const down=e=>{const item=e.target.closest('.stats-sort-item');if(!item)return;e.preventDefault();src=item;sx=e.clientX;sy=e.clientY;try{item.setPointerCapture(e.pointerId);}catch(_){ }list.addEventListener('pointermove',move);list.addEventListener('pointerup',up);list.addEventListener('pointercancel',up);};list.addEventListener('pointerdown',down);});}
  function syncOrder(){currentOrder=[];STATS_GROUPS.forEach(g=>{const list=listRoot.querySelector(`[data-sort-list="${g.id}"]`);if(list)[...list.children].forEach(x=>currentOrder.push(x.dataset.id));});listRoot.querySelectorAll('.stats-sort-list').forEach(list=>[...list.children].forEach((x,i)=>{const n=x.querySelector('.stats-sort-idx');if(n)n.textContent=i+1;}));}
  $('sortClose').onclick=()=>App.closeModal();$('resetSortBtn').onclick=()=>{currentOrder=STATS_GROUPS.flatMap(g=>g.ids);renderLists();App.toast('已恢复默认分组顺序');};$('saveSortBtn').onclick=save;renderLists();
}

/* ─── 16. 设置弹窗（主题 + CSV 导入导出 + 清空） ─── */
function openSettings(){
  const App=window.App;
  const cur=App.currentTheme();
  const THEMES=App.constants.THEMES;
  $('sheet').innerHTML=`
    <div class="row between"><h2 style="margin:0">🎨 现代化浅色主题</h2><button id="setClose" class="link-btn">关闭</button></div>
    <div class="muted" style="margin-top:4px">纯净浅色系调色板，温和护眼、充满呼吸感</div>
    <div class="theme-palette">${Object.entries(THEMES).map(([k,t])=>`
      <div class="theme-btn-card ${cur===k?'active':''}" data-theme-choice="${k}"><div class="theme-preview" style="background:${t.color}"></div><b>${t.name}</b><div class="muted" style="font-size:10px">${t.desc}</div></div>`).join('')}</div>
    <div class="setting-row" style="margin-top:16px">
      <div><b>📤 导出全部 CSV 训练数据</b><div class="muted">标准格式（日期/动作/组数重量次数等，含时长与超级组）。</div></div>
      <button id="exportBtn" class="btn small">导出 CSV</button>
    </div>
    <div class="setting-row">
      <div><b>📥 导入 CSV 训练数据</b><div class="muted">兼容新旧表头，识别时长/超级组字段。</div></div>
      <button id="importBtn" class="btn small">导入 CSV</button>
    </div>
    <div class="setting-row" style="margin-top:12px;padding:12px;border-radius:12px;border:1px dashed #ef4444;background:color-mix(in srgb,#ef4444 6%,var(--card))">
      <div><b style="color:#ef4444">⚠️ 一键清空所有数据 (初始化)</b><div class="muted">清空所有历史训练记录、恢复初始状态，此操作不可撤销。</div></div>
      <button id="resetAllDataBtn" class="btn small" style="background:#ef4444;color:#fff;border-color:#ef4444;border-radius:9px;font-weight:850;padding:6px 14px">一键清空</button>
    </div>
    <input id="csvFile" type="file" accept=".csv,text/csv,text/comma-separated-values,text/x-csv,application/csv,application/vnd.ms-excel,text/plain,application/octet-stream" hidden>`;
  $('modal').classList.add('show');
  $('setClose').onclick=App.closeModal;
  document.querySelectorAll('[data-theme-choice]').forEach(card=>{
    card.onclick=()=>{ App.applyTheme(card.dataset.themeChoice); openSettings(); if(App.state.page==='history') render(); };
  });
  $('exportBtn').onclick=exportCSV;
  $('importBtn').onclick=()=>$('csvFile').click();
  $('resetAllDataBtn').onclick=()=>{
    App.appConfirm('⚠️ 高危操作','确定要清空全部训练历史记录并恢复初始化吗？所有打卡日志将被永久删除。','继续',()=>{
      App.appConfirm('⚠️ 请再次确认','真的要彻底清除所有训练数据吗？此操作无法撤销。','彻底清除',()=>{
        App.db.sessions=[];
        App.state.timerSeconds=0;
        if(App.state.timerInterval) clearInterval(App.state.timerInterval);
        App.state.timerRunning=false;
        App.save(); App.closeModal(); render();
        if(window.Pages.home&&window.Pages.home.render) window.Pages.home.render();
        if(window.Pages.calendar&&window.Pages.calendar.render) window.Pages.calendar.render();
        App.toast('系统已成功清空并完成初始化！');
      });
    });
  };
  $('csvFile').onchange=()=>importCSV($('csvFile').files[0]);
}

/* ─── CSV 导出 ──────────────────────────────────── */
function alignedExportName(e){
  const App=window.App;
  if(!Object.keys(App.exerciseMeta).length) return e.name;
  const lib=e.exerciseId?App.db.exercises.find(z=>z.id===e.exerciseId):null;
  if(lib){
    const m=lib.mkey&&App.exerciseMeta[lib.mkey];
    if(m) return m.中文名||lib.name;
    if(lib.orig){ const ok=App.normalizeExerciseName(lib.orig), om=ok&&App.exerciseMeta[ok]; if(om) return om.中文名||lib.name; }
  }
  if(String(e.exerciseId||'').startsWith('pack:')){
    const pm=App.exerciseMeta[String(e.exerciseId).slice(5)];
    if(pm) return pm.中文名||e.name;
  }
  const em=App.exerciseMeta[App.normalizeExerciseName(e.name)];
  if(em) return em.中文名||e.name;
  return e.name;
}
function csvEscape(v){ return `"${String(v??'').replace(/"/g,'""')}"`; }
function exportCSV(){
  const App=window.App;
  const rows=[['日期','动作','组序','组类型','重量','次数','RIR','完成','备注','时长(分钟)','超级组']];
  [...App.db.sessions].sort((a,b)=>a.date.localeCompare(b.date)).forEach(s=>{
    const dur=s.duration?s.duration:'';
    s.exercises.forEach(e=>{
      const superTag=e.superset?(e.superset.startsWith('超级组')?e.superset:'超级组 '+e.superset):'';
      e.sets.forEach(x=>rows.push([s.date,alignedExportName(e),x.set,x.type||'正式',x.weight??'',x.reps??'',x.rir??'',x.done?'是':'否',e.note||'',dur,superTag]));
    });
  });
  const csv='\ufeff'+rows.map(r=>r.map(csvEscape).join(',')).join('\r\n');
  const filename='全部训练记录_完整数据_含超级组.csv';
  if(window.AndroidBridge && typeof window.AndroidBridge.saveCsv==='function'){
    try{ window.AndroidBridge.saveCsv(filename,csv); App.toast('CSV 已导出到手机「下载」文件夹'); return; }catch(e){}
  }
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(()=>URL.revokeObjectURL(a.href),500);
  App.toast('全部训练数据已成功导出 CSV（含超级组）！');
}

/* ─── CSV 导入 ─────────────────────────────────── */
function parseCSVLine(line){
  const out=[]; let cur='', q=false;
  for(let i=0;i<line.length;i++){
    const c=line[i];
    if(c==='"'){ if(q&&line[i+1]==='"'){cur+='"';i++;} else q=!q; }
    else if(c===','&&!q){ out.push(cur); cur=''; }
    else cur+=c;
  }
  out.push(cur); return out;
}
async function importCSV(file){
  const App=window.App;
  try{
    const text=(await App.readFileAs(file,'text')).replace(/^\ufeff/,'');
    const lines=text.split(/\r?\n/).filter(x=>x.trim()!=='');
    if(lines.length<2) throw new Error('CSV 文件中没有数据');
    let head=parseCSVLine(lines[0]).map(x=>x.trim().replace(/^\ufeff/,''));
    let offset=0;
    if(['index','序号','idx'].includes(head[0].toLowerCase())){ offset=1; head=head.slice(1); }
    const cDate=head.indexOf('日期'), cPlan=head.indexOf('训练计划'), cName=head.indexOf('动作');
    const cSet=head.indexOf('组序'), cType=head.indexOf('组类型'), cWeight=head.indexOf('重量');
    const cReps=head.indexOf('次数'), cRir=head.indexOf('RIR'), cDone=head.indexOf('完成');
    const cNote=head.indexOf('备注');
    const cDur=head.findIndex(h=>/时长|耗时|时间|duration/i.test(h));
    const hasPlanCol=cPlan!==-1;
    const legacyPositional=cName===-1&&cDate===-1;

    let n=0;
    for(let i=1;i<lines.length;i++){
      let row=parseCSVLine(lines[i]);
      if(offset) row=row.slice(offset);
      if(row.length<3) continue;
      let date,planName,name,set,type,weight,reps,rir,done,note,durationVal;
      if(legacyPositional){
        date=row[0]||'';
        if(hasPlanCol||(row.length>=10)){
          planName=row[1]||'训练'; name=row[2]||''; set=row[3]||1; type=row[4]||'正式';
          weight=row[5]; reps=row[6]; rir=row[7]; done=row[8]; note=row[9]||''; durationVal=row[10]||'';
        }else{
          planName='训练'; name=row[1]||''; set=row[2]||1; type=row[3]||'正式';
          weight=row[4]; reps=row[5]; rir=row[6]; done=row[7]; note=row[8]||''; durationVal=row[9]||'';
        }
      }else{
        date=(cDate!==-1?row[cDate]:row[0])||'';
        planName=(cPlan!==-1?row[cPlan]:'')||'训练';
        name=(cName!==-1?row[cName]:'')||'';
        set=(cSet!==-1?row[cSet]:'')||1;
        type=cType!==-1?row[cType]:'正式';
        weight=cWeight!==-1?row[cWeight]:'';
        reps=cReps!==-1?row[cReps]:'';
        rir=cRir!==-1?row[cRir]:'';
        done=cDone!==-1?row[cDone]:'';
        note=cNote!==-1?row[cNote]:'';
        durationVal=cDur!==-1?row[cDur]:'';
      }
      date=String(date||'').trim();
      planName=String(planName||'历史数据').trim()||'历史数据';
      const rawName=String(name||'').trim();
      name=App.normalizeExerciseName(rawName);
      if(!date||!name) continue;

      let s=App.db.sessions.find(x=>x.date===date&&x.planName===planName);
      if(!s){ s={id:App.uid(),date,planId:'imported-'+App.uid(),planName,duration:0,exercises:[]}; App.db.sessions.push(s); }
      if(durationVal){
        const pd=parseInt(String(durationVal).replace(/[^0-9]/g,''));
        if(pd>0&&!s.duration) s.duration=pd;
      }
      let e=s.exercises.find(x=>x.name===name);
      if(!e){
        let known=App.db.exercises.find(x=>x.name===name);
        if(!known&&rawName) known=App.db.exercises.find(x=>x.orig&&App.normalizeExerciseName(x.orig)===App.normalizeExerciseName(rawName));
        if(!known){
          const p=App.profileFor(name,'其他');
          known={id:App.uid(),name,part:p.part,type:App.normalizeEquipType('',name),movement:p.movement,muscles:p.muscles,orig:rawName};
          App.db.exercises.push(known);
        }else if(!known.orig&&rawName){ known.orig=rawName; }
        const byId=s.exercises.find(x=>x.exerciseId===known.id);
        if(byId) e=byId;
        else{
          const p=App.profileFor(name,known.part);
          e={name:known.name,exerciseId:known.id,part:p.part,sets:[],note:note||'',rirOn:false,movement:p.movement,muscles:p.muscles};
          s.exercises.push(e);
        }
      }else if(note&&!e.note){ e.note=note; }
      const idx=Math.max(1,Number(set)||e.sets.length+1)-1;
      while(e.sets.length<=idx) e.sets.push({set:e.sets.length+1,weight:'',reps:'',rir:'',type:'正式',done:false});
      e.sets[idx]={set:idx+1,weight:String(weight??'').trim(),reps:String(reps??'').trim(),rir:String(rir??'').trim(),type:String(type||'正式').trim()==='热身'?'热身':'正式',done:String(done||'').trim()==='是'||String(done||'').trim().toLowerCase()==='yes'};
      n++;
    }
    App.ensureExerciseProfiles();
    App.save(); App.closeModal();
    if(window.Pages.calendar&&window.Pages.calendar.render) window.Pages.calendar.render();
    if(window.Pages.home&&window.Pages.home.render) window.Pages.home.render();
    render();
    App.toast(`已成功导入 ${n} 组训练数据！`);
  }catch(e){ App.toast(e.message||'CSV 导入失败'); }
}

/* ─── 注册 ──────────────────────────────────────── */
window.Pages.history = { render };
})();