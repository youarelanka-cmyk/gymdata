/* ═════════════════════════════════════════════════════════════
   [MODULE: page/calendar] 训练日历
   ─────────────────────────────────────────────────────────────
   职责：月历渲染 · 年月切换 · 日期详情 · 复制到当天 ·
         存为新计划 · 编辑训练记录（含增补动作）
   依赖：App.*（core.js 暴露）
   注册：window.Pages.calendar
   ═════════════════════════════════════════════════════════════ */
(function(){
'use strict';
const $=id=>document.getElementById(id);

/* ─── 主渲染 ─────────────────────────────────────── */
function render(){
  const App=window.App, state=App.state, db=App.db, esc=App.esc;
  let y=state.calYear, m=state.calMonth;

  /* 1. 年份上下限 */
  const allCompleted = db.sessions.filter(App.isSessionCompleted);
  const yearSet=new Set(allCompleted.map(s=>Number(String(s.date).slice(0,4))).filter(n=>n>1900&&n<2100));
  const thisY=new Date().getFullYear();
  yearSet.add(thisY); yearSet.add(Number(y)||thisY);
  const allYears=[...yearSet].sort((a,b)=>a-b);
  const minY=allYears[0], maxY=allYears[allYears.length-1];
  if(state.calYear<minY) state.calYear=minY;
  if(state.calYear>maxY) state.calYear=maxY;
  const yNow=state.calYear;

  /* 2. 页面结构（只在这里生成一次） */
  const section=$('calendar');
  if(!section) return;
  section.innerHTML=`
    <div class="card tight">
      <div class="cal-filter-box">
        <div class="row between" style="margin-bottom:10px;align-items:center">
          <span class="filter-label">选择年份</span>
          <div class="cal-year-nav">
            <button type="button" class="cal-year-step" data-step="-5" title="向前 5 年">«</button>
            <button type="button" class="cal-year-step" data-step="-1" title="上一年">‹</button>
            <span class="cal-year-current" id="calYearLabel">${yNow}年</span>
            <button type="button" class="cal-year-step" data-step="1" title="下一年">›</button>
            <button type="button" class="cal-year-step" data-step="5" title="向后 5 年">»</button>
          </div>
        </div>
        <div class="row between" style="margin-bottom:4px">
          <span class="filter-label">选择月份</span>
          <button id="calTodayBtn" class="link-btn">返回本月</button>
        </div>
        <div class="cal-month-grid" id="calMonthTags"></div>
      </div>
      <div class="cal-grid" id="calGrid"></div>
    </div>
    <div id="calSelectedDayBox"></div>`;

  /* 3. 年份按钮翻页 */
  section.querySelectorAll('.cal-year-step').forEach(b=>{
    const step=Number(b.dataset.step)||0;
    b.disabled=(step<0&&yNow<=minY)||(step>0&&yNow>=maxY);
    b.onclick=()=>{
      let next=yNow+step;
      if(next<minY) next=minY;
      if(next>maxY) next=maxY;
      if(next===yNow) return;
      state.calYear=next;
      render();
    };
  });
  y=state.calYear;

  /* 4. 月份按钮 */
  let monthsHtml='';
  for(let i=1;i<=12;i++) monthsHtml+=`<button class="cal-month-btn ${i===m?'active':''}" data-month="${i}">${i}月</button>`;
  $('calMonthTags').innerHTML=monthsHtml;
  section.querySelectorAll('.cal-month-btn').forEach(b=>{
    b.onclick=()=>{ state.calMonth=Number(b.dataset.month); render(); };
  });

  /* 5. 日历格子 */
  const firstDayWeek=(new Date(y,m-1,1).getDay()+6)%7;
  const daysInMonth=new Date(y,m,0).getDate();
  const daysInPrevMonth=new Date(y,m-1,0).getDate();
  const dows=['一','二','三','四','五','六','日'];
  let gridHtml=dows.map(d=>`<div class="cal-dow">${d}</div>`).join('');

  for(let i=firstDayWeek-1;i>=0;i--){
    gridHtml+=`<div class="cal-day-cell other-month"><span class="cal-day-num">${daysInPrevMonth-i}</span></div>`;
  }
  for(let d=1;d<=daysInMonth;d++){
    const ds=`${y}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    const isToday=ds===state.today;
    const isSelected=ds===state.calSelectedDate;
    const daySessions=App.calSessionsFor(ds);
    const hasTrained=daySessions.length>0;

    let partsStackHtml='';
    if(hasTrained){
      const rawParts=[...new Set(daySessions.flatMap(s=>s.exercises.map(e=>e.part||'其他')))].filter(x=>x!=='其他');
      const simplify=p=>p.replace('部','').replace('肱','');
      const parts=rawParts.length ? rawParts.map(simplify) : [(daySessions[0].planName||'训练').slice(0,3)];
      partsStackHtml=`<div class="cal-parts-stack">${parts.map(p=>`<span class="cal-part-block">${esc(p)}</span>`).join('')}</div>`;
    }
    gridHtml+=`<div class="cal-day-cell ${isToday?'today':''} ${isSelected?'selected':''} ${hasTrained?'has-trained':''}" data-date="${ds}">
      <span class="cal-day-num">${d}</span>${partsStackHtml}
    </div>`;
  }
  const totalCells=firstDayWeek+daysInMonth;
  const remainingCells=(7-(totalCells%7))%7;
  for(let i=1;i<=remainingCells;i++){
    gridHtml+=`<div class="cal-day-cell other-month"><span class="cal-day-num">${i}</span></div>`;
  }
  $('calGrid').innerHTML=gridHtml;

  section.querySelectorAll('.cal-day-cell[data-date]').forEach(cell=>{
    cell.onclick=()=>{ state.calSelectedDate=cell.dataset.date; render(); };
  });

  $('calTodayBtn').onclick=()=>{
    state.calYear=new Date().getFullYear();
    state.calMonth=new Date().getMonth()+1;
    state.calSelectedDate=state.today;
    render();
  };

  renderDayDetail();
}

/* ─── 选中日期详情卡片 ───────────────────────────── */
function renderDayDetail(){
  const App=window.App, state=App.state, esc=App.esc;
  const ds=state.calSelectedDate;
  const box=$('calSelectedDayBox');
  if(!box) return;

  const daySessions=App.calSessionsFor(ds);
  const editTarget=daySessions.find(s=>s.planId===state.currentPlanId)||daySessions[daySessions.length-1];

  if(!daySessions.length){
    box.innerHTML=`<div class="card tight empty" style="margin-top:12px;padding:20px 12px;border:1px solid var(--line);border-radius:16px">
      <div style="font-size:15px;font-weight:900;color:var(--text)">📅 ${ds}</div>
      <div class="muted" style="margin-top:4px;font-size:12px">休息日 · 无训练记录 (肌肉正在充分超量恢复)</div>
    </div>`;
    return;
  }

  let html=`<div class="card" style="margin-top:12px;border:1px solid var(--line);border-radius:18px;padding:16px">
    <div class="row between" style="margin-bottom:10px;align-items:center;gap:8px">
      <div class="row" style="flex:none;min-width:0">
        <h2 style="margin:0;font-size:16px;font-weight:900;white-space:nowrap">📅 ${ds}</h2>
        <span class="badge-pill badge-blue">${daySessions.length} 次</span>
      </div>
      <div class="cal-detail-actions">
        <button id="calCloneSessionBtn" class="cal-act-btn cal-clone-btn" title="复制到当天开始训练" aria-label="复制到当天">复</button>
        <button id="calSaveAsPlanBtn" class="cal-act-btn cal-save-btn" title="存为新计划" aria-label="存为新计划">存</button>
        ${editTarget?`<button class="cal-act-btn cal-edit-session-btn" data-sid="${editTarget.id}" title="编辑 · ${esc(editTarget.planName||'训练')}" aria-label="编辑">改</button>`:''}
      </div>
    </div>`;

  daySessions.forEach(s=>{
    html+=`<div style="margin-top:10px;padding:12px 14px;background:var(--panel);border-radius:14px;border:1px solid var(--line)">
      <div style="margin-top:4px;display:grid;gap:9px">
        ${s.exercises.map((e,ei)=>`
          <div style="padding:11px 13px;background:var(--card);border-radius:12px;border:1px solid var(--line)">
            <div class="row between" style="align-items:center">
              <b style="font-size:14px;color:var(--text)">${ei+1}. ${esc(e.name)}</b>
              ${e.note?`<span class="muted" style="font-size:11px">📝 ${esc(e.note)}</span>`:''}
            </div>
            <div style="margin-top:8px;display:grid;gap:5px">
              ${e.sets.map(x=>`
                <div class="row between" style="font-size:12.5px;padding:4px 0;border-bottom:1px dashed color-mix(in srgb,var(--line) 40%,transparent);white-space:nowrap">
                  <span class="muted" style="font-size:11.5px">第 ${x.set} 组 (${x.type||'正式'})</span>
                  <b style="font-size:13px;color:var(--text)">${x.weight||'自重'} kg × ${x.reps||0} 次 ${x.rir!==''&&x.rir!=null?`[RIR${x.rir}]`:''}</b>
                  <span style="color:${x.done?'var(--green)':'var(--muted)'};font-weight:900;font-size:13.5px">${x.done?'✓':'○'}</span>
                </div>`).join('')}
            </div>
          </div>`).join('')}
      </div>
    </div>`;
  });
  html+=`</div>`;
  box.innerHTML=html;

  const cloneBtn=$('calCloneSessionBtn');
  if(cloneBtn) cloneBtn.onclick=()=>openCloneSessionModal(ds, daySessions);

  const saveBtn=$('calSaveAsPlanBtn');
  if(saveBtn) saveBtn.onclick=()=>saveDayAsPlanModal(ds, daySessions);

  box.querySelectorAll('.cal-edit-session-btn').forEach(btn=>{
    btn.onclick=()=>{
      const sid=btn.dataset.sid;
      App.state.calFocusDate=ds;
      openEditSessionModal(sid, {returnToCalendar:true, focusDate:ds});
    };
  });
}

/* ─── 复制到当天 ─────────────────────────────────── */
function openCloneSessionModal(ds, daySessions){
   const App=window.App, state=App.state;
   $('sheet').innerHTML=`
     <div class="row between" style="align-items:center;gap:10px">
       <div style="font-size:16px;font-weight:900">一键复制到今天？</div>
       <button id="cloneModalClose" class="link-btn">关闭</button>
     </div>
     <div style="display:flex;gap:10px;margin-top:18px">
       <button id="cloneCancelBtn" class="btn" style="flex:1;height:44px;border-radius:12px">取消</button>
       <button id="cloneToTodayDirectBtn" class="btn primary" style="flex:1;height:44px;border-radius:12px;font-weight:900">确认复制</button>
     </div>`;
   $('modal').classList.add('show');
   $('cloneModalClose').onclick=App.closeModal;
   $('cloneCancelBtn').onclick=App.closeModal;
   $('cloneToTodayDirectBtn').onclick=()=>executeCloneSessions(ds, daySessions, state.today, true, false);
 }

function executeCloneSessions(ds, daySessions, targetDate, keepData, markDone){
  const App=window.App, state=App.state, db=App.db;
  const todayStr=state.today;

  daySessions.forEach(src=>{
    const clonedExs=(src.exercises||[]).map(e=>({
      name:e.name,
      exerciseId:e.exerciseId||App.uid(),
      part:e.part||'其他',
      note:e.note||'',
      rirOn:!!e.rirOn,
      superset:e.superset||'',
      sets:(e.sets||[]).map(s=>({
        set:s.set,
        type:s.type||'正式',
        weight:keepData?(s.weight??''):'',
        reps:keepData?(s.reps??10):10,
        rir:s.rir??'',
        done:markDone?true:false
      }))
    }));

    if(targetDate===todayStr){
      let todayS=db.sessions.find(x=>x.date===todayStr);
      let pid;
      if(todayS && todayS.planId && (todayS.planId==='free' || db.plans.some(p=>p.id===todayS.planId))){
        pid=todayS.planId;
      }else if(state.currentPlanId && (state.currentPlanId==='free' || db.plans.some(p=>p.id===state.currentPlanId))){
        pid=state.currentPlanId;
      }else if(src.planId && db.plans.some(p=>p.id===src.planId)){
        pid=src.planId;
      }else{
        pid='free';
      }
      if(todayS){
        todayS.planId=pid;
        todayS.planName=src.planName||'复用训练';
        todayS.exercises=clonedExs;
        todayS.duration=0;
        todayS.completed=false;
      }else{
        todayS={
          id:App.uid(), date:todayStr, planId:pid,
          planName:src.planName||'复用训练', duration:0, completed:false,
          exercises:clonedExs
        };
        db.sessions.push(todayS);
      }
      state.currentPlanId=pid;
    }else{
      const targetSession={
        id:App.uid(), date:targetDate, planId:src.planId||App.uid(),
        planName:src.planName||'复用训练', duration:src.duration||60,
        completed:markDone?true:false, exercises:clonedExs
      };
      db.sessions.push(targetSession);
      db.sessions.sort((a,b)=>a.date.localeCompare(b.date));
    }
  });

  App.save(); App.closeModal();

  if(targetDate===todayStr){
    render();
    App.go('home');
    App.toast(`🎉 已将 ${ds} 的动作与数据全部复制到今天！`);
  }else{
    state.calSelectedDate=targetDate;
    state.calYear=Number(targetDate.slice(0,4));
    state.calMonth=Number(targetDate.slice(5,7));
    render();
    App.toast(`🎉 已将训练全部复制到 ${targetDate}！`);
  }
}

/* ─── 存为新计划 ─────────────────────────────────── */
function saveDayAsPlanModal(ds, daySessions){
  const App=window.App, esc=App.esc;
  const allDayExs=[];
  const seen=new Set();
  daySessions.forEach(s=>{
    (s.exercises||[]).forEach(e=>{
      if(!seen.has(e.name)){
        seen.add(e.name);
        const formalSets=(e.sets||[]).filter(x=>(x.type||'正式')!=='热身');
        allDayExs.push({
          exerciseId:e.exerciseId||App.uid(),
          name:e.name, part:e.part||'其他',
          sets:Math.max(1,formalSets.length||3),
          reps:'8-12',
          warmups:(e.sets||[]).filter(x=>x.type==='热身').length||0,
          rir:''
        });
      }
    });
  });

  if(!allDayExs.length){ App.toast('当天无动作数据可保存'); return; }
  const defaultPlanName=`${daySessions[0]?.planName||'自定义'} (${ds.slice(5)})`;

  $('sheet').innerHTML=`
    <div class="row between"><h2 style="margin:0;font-size:17.5px;font-weight:900">📋 将此日动作存为新计划</h2><button id="savePlanModalClose" class="link-btn">关闭</button></div>
    <div class="muted" style="margin-top:4px">自由勾选要加入新计划的动作，一键沉淀为专属计划</div>
    <div style="margin-top:12px">
      <label style="font-size:12px;font-weight:850;color:var(--muted)">新计划名称
        <input id="newPlanNameInp" class="field" style="margin-top:4px;height:38px;font-size:14px;text-align:left;padding:0 12px" value="${esc(defaultPlanName)}" placeholder="输入新计划名称">
      </label>
    </div>
    <div style="margin-top:12px">
      <div class="row between" style="margin-bottom:6px">
        <b style="font-size:13px">勾选动作 (${allDayExs.length})</b>
        <button id="calPlanSelectAll" class="link-btn" style="font-size:11.5px">全选/反选</button>
      </div>
      <div style="display:flex;flex-direction:column;gap:6px;max-height:45vh;overflow-y:auto">
        ${allDayExs.map((ex,idx)=>`
          <label style="display:flex;align-items:center;justify-content:space-between;padding:9px 12px;background:var(--panel);border:1px solid var(--line);border-radius:10px;cursor:pointer">
            <div style="display:flex;align-items:center;gap:8px">
              <input type="checkbox" class="cal-save-plan-check" data-idx="${idx}" checked>
              <b style="font-size:13.5px">${idx+1}. ${esc(ex.name)}</b>
              <span class="badge-part" style="font-size:10px;padding:1px 6px">${esc(ex.part)}</span>
            </div>
            <span style="font-size:11.5px;color:var(--muted)">${ex.sets} 组</span>
          </label>`).join('')}
      </div>
    </div>
    <button id="confirmSavePlanBtn" class="btn primary" style="width:100%;margin-top:16px;height:44px;font-size:15px;font-weight:900;border-radius:12px">✓ 确认保存为新训练计划</button>`;
  $('modal').classList.add('show');
  $('savePlanModalClose').onclick=App.closeModal;

  $('calPlanSelectAll').onclick=()=>{
    const cbs=document.querySelectorAll('.cal-save-plan-check');
    const allChecked=Array.from(cbs).every(c=>c.checked);
    cbs.forEach(c=>c.checked=!allChecked);
  };

  $('confirmSavePlanBtn').onclick=()=>{
    const pName=$('newPlanNameInp').value.trim()||defaultPlanName;
    const checkedIndices=Array.from(document.querySelectorAll('.cal-save-plan-check:checked')).map(c=>Number(c.dataset.idx));
    if(!checkedIndices.length){ App.toast('请至少勾选一个动作'); return; }
    const chosenExs=checkedIndices.map(i=>allDayExs[i]);
    const newPlanObj={id:App.uid(),name:pName,exercises:chosenExs};
    App.db.plans.push(newPlanObj);
    App.state.currentPlanId=newPlanObj.id;
    App.save(); App.closeModal(); render(); App.go('home');
    App.toast(`🎉 已将动作保存为新计划：【${pName}】并自动载入！`);
  };
}

/* ─── 编辑训练记录（含增补动作） ──────────────────── */
function openEditSessionModal(sessionId, opts={}){
  const App=window.App, esc=App.esc;
  const s=App.db.sessions.find(x=>x.id===sessionId);
  if(!s){ App.toast('未找到该记录'); return; }
  const returnToCalendar=!!(opts && opts.returnToCalendar);
  const focusDate=(opts && opts.focusDate)||s.date;

  function renderEditForm(){
    $('sheet').innerHTML=`
      <div class="row between">
        <h2 style="margin:0;font-size:17.5px;font-weight:900">✏️ 编辑训练记录</h2>
        <button id="editClose" class="link-btn">返回</button>
      </div>
      <div style="margin-top:10px;display:grid;gap:8px">
        <label style="font-size:12px;font-weight:800;color:var(--muted)">训练日期
          <input id="editDateInp" type="date" class="field" value="${s.date}" style="margin-top:3px">
        </label>
        <label style="font-size:12px;font-weight:800;color:var(--muted)">计划名称
          <input id="editPlanInp" class="field" value="${esc(s.planName||'')}" style="margin-top:3px">
        </label>
        <label style="font-size:12px;font-weight:800;color:var(--muted)">训练时长 (分钟)
          <input id="editDurInp" type="number" class="field" value="${s.duration||0}" style="margin-top:3px">
        </label>
      </div>
      <div style="margin-top:12px">
        <div class="row between">
          <b style="font-size:13px">动作列表 (${s.exercises.length})</b>
          <button id="editAddExBtn" class="link-btn" style="font-weight:850">＋ 增补动作</button>
        </div>
        <div style="margin-top:8px;max-height:45vh;overflow-y:auto;display:flex;flex-direction:column;gap:8px">
          ${s.exercises.map((e,ei)=>`
            <div style="padding:10px;background:var(--panel);border:1px solid var(--line);border-radius:10px">
              <div class="row between">
                <b>${ei+1}. ${esc(e.name)}</b>
                <button class="link-btn danger del-edit-ex" data-ei="${ei}">删除动作</button>
              </div>
              <div style="margin-top:6px;display:flex;flex-direction:column;gap:4px">
                ${e.sets.map((x,si)=>`
                  <div style="display:flex;gap:4px;align-items:center;font-size:11.5px">
                    <span style="width:20px;text-align:center">${x.set}</span>
                    <input class="field edit-w" data-ei="${ei}" data-si="${si}" style="width:65px;height:26px" value="${esc(x.weight)}" placeholder="kg">
                    <input class="field edit-r" data-ei="${ei}" data-si="${si}" style="width:65px;height:26px" value="${esc(x.reps)}" placeholder="次">
                    <button class="del-set del-edit-set" data-ei="${ei}" data-si="${si}" style="width:20px;height:20px;font-size:11px">×</button>
                  </div>`).join('')}
              </div>
              <button class="btn tiny add-edit-set" data-ei="${ei}" style="margin-top:6px">＋ 增加一组</button>
            </div>`).join('')}
        </div>
      </div>
      <button id="saveEditSessionBtn" class="btn primary" style="width:100%;margin-top:14px;padding:12px;font-weight:900">✓ 保存修改</button>`;
    $('modal').classList.add('show');
    $('editClose').onclick=()=>{
      if(returnToCalendar){ App.closeModal(); render(); }
      else App.closeModal();
    };

    document.querySelectorAll('.del-edit-ex').forEach(b=>{
      b.onclick=()=>{ s.exercises.splice(Number(b.dataset.ei),1); renderEditForm(); };
    });
    document.querySelectorAll('.del-edit-set').forEach(b=>{
      b.onclick=()=>{
        const ei=Number(b.dataset.ei), si=Number(b.dataset.si);
        s.exercises[ei].sets.splice(si,1);
        s.exercises[ei].sets.forEach((x,i)=>x.set=i+1);
        renderEditForm();
      };
    });
    document.querySelectorAll('.add-edit-set').forEach(b=>{
      b.onclick=()=>{
        const ei=Number(b.dataset.ei);
        const last=s.exercises[ei].sets[s.exercises[ei].sets.length-1];
        s.exercises[ei].sets.push({
          set:s.exercises[ei].sets.length+1,
          weight:last?.weight??'', reps:last?.reps??10,
          rir:'', type:'正式', done:true
        });
        renderEditForm();
      };
    });
    document.querySelectorAll('.edit-w').forEach(inp=>{
      inp.oninput=()=>{ const ei=Number(inp.dataset.ei), si=Number(inp.dataset.si); s.exercises[ei].sets[si].weight=inp.value; };
    });
    document.querySelectorAll('.edit-r').forEach(inp=>{
      inp.oninput=()=>{ const ei=Number(inp.dataset.ei), si=Number(inp.dataset.si); s.exercises[ei].sets[si].reps=inp.value; };
    });

    /* ★ 增补动作 */
    const addExBtn=$('editAddExBtn');
    if(addExBtn){
      addExBtn.onclick=()=>{
        App.openActionPicker({
          title:'增补动作',
          onSelect:(newEx)=>{
            s.exercises.push({
              name:newEx.name,
              exerciseId:newEx.id,
              part:newEx.part||'其他',
              sets:Array.from({length:1},(_,i)=>({set:i+1,weight:'',reps:'',rir:'',type:'正式',done:true})),
              note:'', rirOn:false, superset:''
            });
            renderEditForm();
          }
        });
      };
    }

    $('saveEditSessionBtn').onclick=()=>{
      s.date=$('editDateInp').value;
      s.planName=$('editPlanInp').value.trim()||'训练日';
      s.duration=Number($('editDurInp').value)||0;
      App.save(); render(); App.closeModal();
      App.toast('训练记录已更新保存！');
    };
  }

  renderEditForm();
}

/* ─── 注册 ──────────────────────────────────────── */
window.Pages.calendar = { render };
})();