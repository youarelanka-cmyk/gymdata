/* [MODULE: boot] 启动脚本 */
(function(){
'use strict';
const App=window.App;
const $=App.$;

/* ── 补齐 home 和 library section 的容器（自动检测，缺则创建） ── */
(function ensureContainers(){
  const home=$('home');
  if(home && !home.querySelector('#homeBox')){
    home.innerHTML='<div id="homeBox"></div>';
  }
  const lib=$('library');
  if(lib && !lib.querySelector('#libraryBox')){
    lib.innerHTML=`<div class="card">
      <div class="lib-sticky-header">
        <div class="lib-topbar" style="display:block;position:relative">
          <div class="lib-head-row">
            <input id="libFind" class="lib-search-function" placeholder="🔍 搜索动作…" aria-label="搜索动作">
            <button id="libMenuBtn" class="lib-function-btn lib-menu-btn" title="功能菜单" aria-label="功能菜单"><span class="lf-ic">☰</span></button>
          </div>
          <div id="libMenuPanel" class="lib-menu-panel" style="display:none">
            <button id="gifImportBtn" class="lib-function-btn lf-import"><span class="lf-ic">📦</span><span>导入资源包</span></button>
            <button id="alignBtn" class="lib-function-btn lf-align"><span class="lf-ic">🔄</span><span>对齐动作资料</span></button>
            <button id="clearPackBtn" class="lib-function-btn lf-clear"><span class="lf-ic">🧹</span><span>清空资源包</span></button>
          </div>
        </div>
        <input type="file" id="gifImportInput" accept=".zip,application/zip,application/x-zip-compressed,application/octet-stream" style="display:none">
        <div id="libMiniFilters" class="lib-mini-filters"></div>
        <div id="libEquipChips" class="lib-part-chips" style="margin-top:6px"></div>
      </div>
      <div id="libraryWrap" class="library-wrap">
        <aside id="libPartRail" class="lib-rail lib-part-rail"></aside>
        <div id="libraryBox" class="lib-actions"></div>
      </div>
    </div>`;
  }
})();

/* ── 启动流程 ── */
App.applyTheme(App.currentTheme());
App.load();
App.ensureExerciseProfiles();
App.initGlobalEvents();
App.loadMeta();
App.db.exercises.forEach(e=>{ e.part=App.packPart(e.part); });
App.alignExactAuto();
App.loadGifsFromIDB();

if(window.Pages.library && window.Pages.library.init){
  window.Pages.library.init();
}

App.go('home');
})();