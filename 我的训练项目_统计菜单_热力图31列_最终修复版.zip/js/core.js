/* ═════════════════════════════════════════════════════════════
   [MODULE: core] 核心层
   ─────────────────────────────────────────────────────────────
   职责：常量 · 工具 · 数据模型 · 持久化 · 动作库选择器 · 主题
   依赖：jszip.js（需先加载）
   暴露：window.App（所有页面模块通过 App.xxx 使用）
   ═════════════════════════════════════════════════════════════ */
(function(){
'use strict';

/* ─── 1. 常量 ─────────────────────────────────────── */
const PART_SIZE_ORDER=['腿','背','胸','臀','肩','腹','小腿','三头','二头','前臂','手臂','有氧','颈'];
const PARTS=['全部',...PART_SIZE_ORDER];
const EQUIP_SHORT={'BOSU球':'BOSU','波速球':'波速','EZ杠铃':'EZ杠','EZ曲杆':'EZ杆','上肢测功机':'测功机','史密斯机':'史密斯','动感单车':'动感','杠杆器械':'杠杆','泡沫滚轴':'泡沫轴','固定器械':'器械','有氧器械':'有氧','特种器械':'特种'};
const LEGACY_PART_MAP={'腰腹':'腹'};
const EQUIP_TYPES=['自由','器械'];
const COMMON_EQUIPS=['杠铃','哑铃','史密斯机','固定器械','绳索','自重','EZ曲杆','壶铃'];
const DEFAULTS=[
['杠铃深蹲','腿','自由重量'],['杠铃卧推','胸','自由重量'],['硬拉','腿','自由重量'],['罗马尼亚硬拉','腿','自由重量'],['站姿杠铃推举','肩','自由重量'],
['引体向上','背','自重'],['高位下拉','背','器械'],['坐姿划船','背','器械'],['大剪刀','背','器械'],['杠铃划船','背','自由重量'],
['上斜哑铃卧推','胸','自由重量'],['哑铃侧平举','肩','自由重量'],['反向飞鸟','肩','自由重量'],['腿举','腿','器械'],['腿屈伸','腿','器械'],['腿弯举','腿','器械'],
['哑铃弯举','二头','自由重量'],['杠铃弯举','二头','自由重量'],['绳索下压','三头','器械'],['双杠臂屈伸','胸','自重'],['卷腹','腹','自重']
].map((x,i)=>({id:'ex'+i,name:x[0],part:x[1],type:x[2]}));
const STATS_CARD_DEFAULTS=['card-overview','card-periodcompare','card-loadtrend','card-fatigue','card-consistency','card-musclecoverage','card-structure','card-performance','card-rmmap','card-longtermheatmap'];
const THEMES={
  sky:{name:'冰雾淡蓝',color:'#0ea5e9',bg:'#f4f9fd',desc:'空灵通透 (默认)'},
  mint:{name:'薄荷淡绿',color:'#10b981',bg:'#f4faf6',desc:'自然生机'},
  peach:{name:'奶油奶杏',color:'#f97316',bg:'#faf7f3',desc:'温暖柔和'},
  rose:{name:'清甜淡樱',color:'#f43f5e',bg:'#faf4f5',desc:'优雅时尚'},
  lilac:{name:'薰衣浅紫',color:'#8b5cf6',bg:'#f7f5fa',desc:'微淡轻奢'},
  sand:{name:'北欧浅米',color:'#64748b',bg:'#f8fafc',desc:'极简高级'}
};
const CORE_LIFTS_BIG=[
  {key:'深蹲',label:'深蹲',test:n=>/深蹲/.test(n)&&!/前蹲|泽奇|哈克|杰斐逊|保加利亚|分腿|箭步|弓步|单腿|壶铃|高脚杯|箱式|跳跃|跳深|深蹲架拉|划船|弯举|屈膝礼|拉伸|长凳|前侧胸/.test(n)},
  {key:'卧推',label:'卧推',test:n=>/卧推/.test(n)&&!/上斜|下斜|窄握|窄距|哑铃|地板|断头|JM|转体|中立|掌心|反向/.test(n)},
  {key:'硬拉',label:'硬拉',test:n=>/硬拉/.test(n)&&!/罗马尼亚|直腿|单腿|RDL|单臂|侧面|高脚/.test(n)}
];
const CORE_LIFTS_SMALL=[
  {key:'站姿杠铃推举',label:'站姿杠铃推举',test:n=>(/^推举$/.test(n)||n==='杠铃推举'||n==='站姿杠铃推举'||/站姿推举|军事推举|实力举|杠铃推肩/.test(n))||(/推举/.test(n)&&/杠铃|史密斯/.test(n)&&!/窄握|宽握|颈前|布拉德福德|高翻|后方|臂屈伸|哑铃|绳索|壶铃|杠杆|弹力带/.test(n))},
  {key:'杠铃划船',label:'杠铃划船',test:n=>(/^划船$/.test(n)||n==='俯身划船'||n==='杠铃划船')||(/划船/.test(n)&&/杠铃/.test(n)&&!/单臂|直立|宽握|变式|深蹲|绳索/.test(n))},
  {key:'罗马尼亚硬拉',label:'罗马尼亚硬拉',test:n=>/罗马尼亚硬拉|直腿硬拉|RDL|罗马尼亚/.test(n)},
  {key:'引体',label:'引体',test:n=>/引体/.test(n)}
];
const CORE_LIFTS_ALL=[...CORE_LIFTS_BIG,...CORE_LIFTS_SMALL];
const UPPER_MUSCLES=['胸大肌','背部','前三角','侧三角','后三角','肱二头','肱三头'];
const LOWER_MUSCLES=['股四头','腘绳肌','臀大肌','小腿','腹','下背'];
const FATIGUE_UPPER_PARTS=['胸','背','肩','二头','三头','手臂'];
const FATIGUE_LOWER_PARTS=['腿','臀','小腿','腹'];
const PACK_MODE_TO_PPL={'水平推':'推','垂直推':'推','水平拉':'拉','垂直拉':'拉','膝主导(蹲类)':'腿','髋主导(铰链)':'腿','单腿步态':'腿','核心抗屈/抗旋':'腿'};
const EQUIP_ALL_STATIC=['BOSU球','EZ杠铃','上肢测功机','健腹轮','六角杠','划船机','动感单车','史密斯机','哑铃','壶铃','奥杆','弹力带','杠杆器械','杠铃','椭圆机','泡沫滚轴','爬梯机','瑞士球','绳索','自重','药球','负重','轮胎','辅助','锤式','雪橇机'];

/* ─── 2. 全局命名空间 ─────────────────────────────── */
const App={
  db:{exercises:[],plans:[],sessions:[]},
  exerciseMeta:{},
  gifAssets:{},
  state:{
    page:'home',
    statsCardOrder:JSON.parse(localStorage.getItem('fit_stats_order')||'null')||[...STATS_CARD_DEFAULTS],
    part:'全部',libPart:'全部',libEquip:null,libHeat:null,libCat:null,libMove:null,
    editPlanId:null,selected:[],currentPlanId:null,
    today:new Date().toISOString().slice(0,10),
    historyRange:'all',actionStatQ:'',homeHistoryQ:'',
    actionRankSort:'sets',actionRankSortAsc:false,
    calYear:new Date().getFullYear(),calMonth:new Date().getMonth()+1,
    calSelectedDate:new Date().toISOString().slice(0,10),
    timerSeconds:0,timerRunning:false,timerInterval:null,
    weightTrendKey:null
  },
  constants:{PART_SIZE_ORDER,PARTS,EQUIP_SHORT,LEGACY_PART_MAP,EQUIP_TYPES,COMMON_EQUIPS,DEFAULTS,STATS_CARD_DEFAULTS,THEMES,CORE_LIFTS_ALL,FATIGUE_UPPER_PARTS,FATIGUE_LOWER_PARTS,PACK_MODE_TO_PPL,EQUIP_ALL_STATIC,UPPER_MUSCLES,LOWER_MUSCLES}
};
window.App=App;
window.Pages={};

/* ─── 3. 基础工具 ─────────────────────────────────── */
const $=id=>document.getElementById(id);
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,7);
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const fmtNum=n=>Number(n||0).toLocaleString('zh-CN',{maximumFractionDigits:1});
const fmtVolume=n=>{const num=Number(n||0);return num>=1000000?(num/1000000).toFixed(2)+'M':num>=1000?(num/1000).toFixed(1)+'k':fmtNum(num);};
const partSizeRank=p=>{const i=PART_SIZE_ORDER.indexOf(p);return i<0?99:i;};
const shortEquip=c=>EQUIP_SHORT[c]||(c.length>3?c.slice(0,3):c);
const packPart=p=>LEGACY_PART_MAP[p]||p||'胸';
const packPartOptions=()=>{const vals=[...new Set(Object.values(App.exerciseMeta||{}).map(r=>packPart(r&&r.部位)).filter(Boolean))];return ['全部',...PART_SIZE_ORDER.filter(p=>vals.includes(p)),...vals.filter(p=>!PART_SIZE_ORDER.includes(p)).sort((a,b)=>a.localeCompare(b,'zh-CN'))];};
const activePackParts=()=>packPartOptions().slice(1);

function toast(msg){
  const t=$('toast'); t.textContent=msg; t.classList.add('show');
  clearTimeout(toast.t); toast.t=setTimeout(()=>t.classList.remove('show'),1400);
}
function closeModal(){$('modal').classList.remove('show');$('sheet').className='sheet';}
function appConfirm(title,msg,okText,onOk){
  $('sheet').innerHTML=`
    <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
      <div style="font-size:15.5px;font-weight:900;color:var(--red);display:flex;align-items:center;gap:6px">${title}</div>
      <button id="cfX" class="btn small" style="background:transparent;color:var(--muted);font-size:15px;padding:4px 8px;border-radius:8px">✕</button>
    </div>
    <div style="margin-top:10px;font-size:13.5px;line-height:1.6;color:var(--text);white-space:pre-line">${msg}</div>
    <div style="display:flex;gap:10px;margin-top:16px">
      <button id="cfCancel" class="btn" style="flex:1;height:44px;border-radius:10px;font-size:14px;font-weight:850">取消</button>
      <button id="cfOk" class="btn danger" style="flex:1;height:44px;border-radius:10px;font-size:14px;font-weight:900">${okText||'确认'}</button>
    </div>`;
  $('modal').classList.add('show');
  const close=()=>closeModal();
  $('cfX').onclick=close;$('cfCancel').onclick=close;
  $('cfOk').onclick=()=>{close();onOk&&onOk();};
}

/* ─── 4. IndexedDB（动图持久化） ────────────────────── */
let _idb=null,_idbReady=null;
function idbOpen(){
  if(_idbReady) return _idbReady;
  _idbReady=new Promise((res,rej)=>{
    try{
      const rq=indexedDB.open('gym_v5_gifs',2);
      rq.onupgradeneeded=e=>{const db=e.target.result;if(!db.objectStoreNames.contains('gif'))db.createObjectStore('gif',{keyPath:'name'});if(!db.objectStoreNames.contains('meta'))db.createObjectStore('meta',{keyPath:'k'});};
      rq.onsuccess=e=>{_idb=e.target.result;res();};
      rq.onerror=()=>rej(rq.error||new Error('IndexedDB 不可用'));
    }catch(err){rej(err);}
  });
  return _idbReady;
}
function idbPutMeta(obj){return new Promise((res,rej)=>{if(!_idb){res();return;}const tx=_idb.transaction('meta','readwrite');tx.objectStore('meta').put({k:'all',data:obj});tx.oncomplete=res;tx.onerror=()=>rej(tx.error);});}
function idbGetMeta(){return new Promise((res,rej)=>{if(!_idb){res(null);return;}const tx=_idb.transaction('meta','readonly');const rq=tx.objectStore('meta').get('all');rq.onsuccess=()=>res(rq.result?rq.result.data:null);rq.onerror=()=>rej(rq.error);});}
function idbPutGif(name,b64){return new Promise((res,rej)=>{const tx=_idb.transaction('gif','readwrite');tx.objectStore('gif').put({name,b64});tx.oncomplete=res;tx.onerror=()=>rej(tx.error);});}
function idbDelGif(name){return new Promise((res,rej)=>{if(!_idb){res();return;}const tx=_idb.transaction('gif','readwrite');tx.objectStore('gif').delete(name);tx.oncomplete=res;tx.onerror=()=>rej(tx.error);});}
function idbClearGifs(){return new Promise((res,rej)=>{if(!_idb){res();return;}const tx=_idb.transaction('gif','readwrite');tx.objectStore('gif').clear();tx.oncomplete=res;tx.onerror=()=>rej(tx.error);});}
function idbGetAllGifs(){return new Promise((res,rej)=>{const tx=_idb.transaction('gif','readonly');const rq=tx.objectStore('gif').getAll();rq.onsuccess=()=>res(rq.result||[]);rq.onerror=()=>rej(rq.error);});}

/* ─── 5. 动作元数据（名称/部位/器械/肌群规范化） ───── */
function normalizeExerciseName(name){
  if(name==null) return '';
  let s=String(name).trim();
  if(!s) return '';
  s=s.replace(/\s+/g,'').replace(/？/g,'?').replace(/（/g,'(').replace(/）/g,')').replace(/[－—–]/g,'-');
  s=s.replace(/V[\?\-]?bar/gi,'V-bar').replace(/T[\-\s]?bar/gi,'T-bar');
  s=s.replace(/\(([^)]*)\)/g,(m,inner)=>{
    const t=String(inner).trim();
    if(/辅助|助力|assisted|负重|加重|开放|敞开|单边|单手|窄|宽|正向|反向|中难度/i.test(t)) return m;
    if(/^(v\s*\d+|ver\.?\s*\d+|version\s*\d+|版本\s*[一二三四五六七八九十\d]+)$/i.test(t)) return '';
    return m;
  });
  s=s.replace(/\(\s*\)/g,'').trim().replace(/\(([^)]+)\)/g,'（$1）').replace(/ez杆/gi,'EZ杆').replace(/版本\s*[一二三四五六七八九十\d]+$/,'');
  return s.trim();
}
function normalizeEquipType(type,name=''){
  const t=String(type||'').trim(),n=String(name||'');
  if(EQUIP_TYPES.includes(t)) return t;
  if(/器械|固定|史密斯|绳索|线缆|龙门|机械|selector|machine|cable/i.test(t)) return '器械';
  if(/自由|杠铃|哑铃|壶铃|free\s*weight|自重|徒手|体重|body\s*weight/i.test(t)) return '自由';
  if(/高位下拉|坐姿划船|腿举|腿屈伸|腿弯举|绳索|下压|史密斯|器械|悍马|蝴蝶机|夹胸机|推胸机|倒蹬|哈克|龙门|面拉机/.test(n)) return '器械';
  if(/杠铃|哑铃|壶铃|地雷杆|引体|俯卧撑|双杠臂屈伸|卷腹|平板支撑|悬垂|倒立撑|掌上压|俄挺|人旗/.test(n)) return '自由';
  if(/器械/.test(t)) return '器械';
  return '自由';
}
function normalizeMovementLabel(m){return {推:'推',拉:'拉',蹲:'蹲',髋:'髋铰链',核心:'',其他:''}[m]||'';}
function profileFor(name,part='其他'){
  const n=String(name||'');
  if(/卷腹|仰卧起坐|腹肌轮|龙旗|真空|腹|抬腿|悬垂举腿|登山跑|平板支撑|侧平板|死虫|鸟狗/.test(n))return{part:'腹',movement:'核心',isCompound:false,muscles:{'腹':1.0}};
  if(/提踵|小腿|站姿提踵|坐姿提踵/.test(n))return{part:'腿',movement:'蹲',isCompound:false,muscles:{'小腿':1.0}};
  if(/腿屈伸|腿伸展|踢腿/.test(n))return{part:'腿',movement:'蹲',isCompound:false,muscles:{'股四头':1.0}};
  if(/腿弯举|腿弯|俯身腿弯|坐姿腿弯/.test(n))return{part:'腿',movement:'蹲',isCompound:false,muscles:{'腘绳肌':1.0,'臀大肌':0.2}};
  if(/臀推|髋推|hip\s*thrust|驴踢|蚌式|侧躺抬腿|绳索后踢/.test(n))return{part:'臀',movement:'蹲',isCompound:false,muscles:{'臀大肌':1.0,'腘绳肌':0.25,'核心':0.15}};
  if(/深蹲|腿举|倒蹬|保加利亚|哈克|箭步|弓步|分腿蹲|壶铃深蹲|高脚杯|盒式深蹲|前蹲|后蹲|西氏深蹲/.test(n))return{part:'腿',movement:'蹲',isCompound:true,muscles:{'股四头':1.0,'臀大肌':0.75,'腘绳肌':0.25,'核心':0.25}};
  if(/罗马尼亚硬拉|直腿硬拉|单腿.*硬拉|地雷杆硬拉|RDL/.test(n))return{part:'腿',movement:'蹲',isCompound:true,muscles:{'腘绳肌':1.0,'臀大肌':0.85,'下背':0.45,'核心':0.2}};
  if(/硬拉|相扑|传统硬拉|六角杠/.test(n))return{part:'腿',movement:'蹲',isCompound:true,muscles:{'臀大肌':0.9,'腘绳肌':0.85,'下背':0.6,'背部':0.4,'核心':0.3}};
  if(/山羊挺身|挺身|反向挺身|背屈伸|GHD/.test(n))return{part:'背',movement:'蹲',isCompound:false,muscles:{'下背':1.0,'臀大肌':0.7,'腘绳肌':0.55}};
  if(/反向飞鸟|俯身.*飞鸟|俯身飞鸟|面拉|外旋|弹力带面拉/.test(n))return{part:'肩',movement:'拉',isCompound:false,muscles:{'后三角':1.0,'背部':0.35,'斜方肌':0.3}};
  if(/卧推|推胸|俯卧撑|双杠臂屈伸|凳上臂屈伸|器械推胸|史密斯卧推|地板卧推/.test(n))return{part:'胸',movement:'推',isCompound:true,muscles:{'胸大肌':1.0,'肱三头':0.5,'前三角':0.35}};
  if(/夹胸|飞鸟|十字夹|绳索夹胸|蝴蝶机| PEC /.test(n))return{part:'胸',movement:'推',isCompound:false,muscles:{'胸大肌':1.0,'前三角':0.2}};
  if(/碎颅|臂屈伸|三头|下压|窄距卧推|过头臂屈伸|踢腿.*三头|绳索三头/.test(n))return{part:'三头',movement:'推',isCompound:/窄距卧推/.test(n),muscles:{'肱三头':1.0,'胸大肌':0.25,'前三角':0.2}};
  if(/弯举|牧师|蜘蛛弯|集中弯|锤式|哑铃弯|杠铃弯|绳索弯举/.test(n))return{part:'二头',movement:'拉',isCompound:false,muscles:{'肱二头':1.0,'前臂':0.25}};
  if(/引体|下拉|高位下拉|单手下拉|器械下拉|背阔下拉/.test(n))return{part:'背',movement:'拉',isCompound:true,muscles:{'背部':1.0,'肱二头':0.5,'后三角':0.25,'斜方肌':0.25}};
  if(/划船|大剪刀|T-?bar|坐姿划船|V-?bar|俯身划|单臂划|绳索划船|垫腹划船/.test(n))return{part:'背',movement:'拉',isCompound:true,muscles:{'背部':0.9,'斜方肌':0.75,'肱二头':0.45,'后三角':0.35,'下背':0.2}};
  if(/侧平举|侧抬|侧举|Y字举|悍马.*侧/.test(n))return{part:'肩',movement:'推',isCompound:false,muscles:{'侧三角':1.0,'前三角':0.25,'斜方肌':0.2}};
  if(/推肩|推举|肩上推|军事推|哑铃推肩|坐姿推肩|斯科特|阿诺德推/.test(n))return{part:'肩',movement:'推',isCompound:true,muscles:{'前三角':0.85,'侧三角':0.75,'肱三头':0.45,'胸大肌':0.2,'核心':0.2}};
  if(/前平举|前抬/.test(n))return{part:'肩',movement:'推',isCompound:false,muscles:{'前三角':1.0,'胸大肌':0.2}};
  if(/高翻|借力推|抓举|挺举/.test(n))return{part:'腿',movement:'蹲',isCompound:true,muscles:{'臀大肌':0.6,'股四头':0.5,'背部':0.45,'前三角':0.35,'核心':0.3}};
  if(/直立划船|提拉/.test(n))return{part:'肩',movement:'拉',isCompound:true,muscles:{'侧三角':0.75,'斜方肌':0.6,'肱二头':0.35,'后三角':0.3}};
  const partMap={
    '胸':{'胸大肌':1.0,'前三角':0.25,'肱三头':0.2},'背':{'背部':1.0,'肱二头':0.35,'后三角':0.2},
    '肩':{'侧三角':0.7,'前三角':0.5,'后三角':0.3},'手臂':{'肱二头':0.6,'肱三头':0.6,'前臂':0.3},
    '前臂':{'前臂':1.0},'腿':{'股四头':0.7,'臀大肌':0.5,'腘绳肌':0.4},'小腿':{'小腿':1.0},
    '腰腹':{'腹':0.9,'腹斜肌':0.4,'下背':0.3},'有氧':{'心肺':1.0},'颈':{'颈部':1.0},
    '臀':{'臀大肌':1.0,'腘绳肌':0.3},'二头':{'肱二头':1.0},'三头':{'肱三头':1.0},'腹':{'腹':1.0}
  };
  const p=part&&partMap[part]?part:((partMap[part]&&part)||'背');
  const muscles=partMap[part]||partMap['背'];
  const mov=part==='腿'||part==='臀'||part==='小腿'?'蹲':(part==='背'||part==='二头'||part==='手臂'||part==='前臂'?'拉':(part==='腹'||part==='腰腹'?'核心':'推'));
  return{part:part&&part!=='其他'?part:p,movement:mov,isCompound:false,muscles};
}
function metaFor(name){return App.exerciseMeta[normalizeExerciseName(name)]||null;}
function gifFor(name){const n=normalizeExerciseName(name);return App.gifAssets[n]||'';}
function hasGif(name){return !!App.gifAssets[normalizeExerciseName(name)];}
function metaOfEx(ex){if(!ex) return null;return metaFor(ex.name)||(ex.mkey&&App.exerciseMeta[ex.mkey])||null;}
function gifOfEx(ex){if(!ex) return '';return gifFor(ex.name)||(ex.mkey?App.gifAssets[ex.mkey]||'':'');}
function hasGifEx(ex){return !!(ex&&(hasGif(ex.name)||(ex.mkey&&App.gifAssets[ex.mkey])));}

/* ─── 6. 持久化 ───────────────────────────────────── */
function save(){
  localStorage.setItem('gym_v5',JSON.stringify(App.db));
  if(App.state.currentPlanId)localStorage.setItem('gym_v5_current',App.state.currentPlanId);
  localStorage.setItem('fit_stats_order',JSON.stringify(App.state.statsCardOrder||STATS_CARD_DEFAULTS));
}
function saveMeta(){
  try{localStorage.setItem('gym_v5_exercise_meta',JSON.stringify(App.exerciseMeta));}catch(e){}
  idbOpen().then(()=>idbPutMeta(App.exerciseMeta)).catch(()=>{});
}
function loadMeta(){
  try{const s=localStorage.getItem('gym_v5_exercise_meta');App.exerciseMeta=s?JSON.parse(s):{};}catch(e){App.exerciseMeta={};}
  if(!Object.keys(App.exerciseMeta).length){
    idbOpen().then(()=>idbGetMeta()).then(m=>{
      if(m&&Object.keys(m).length){
        App.exerciseMeta=m;
        App.db.exercises.forEach(e=>{e.part=packPart(e.part);});
        alignExactAuto();
        if(window.Pages.library&&window.Pages.library.render) window.Pages.library.render();
      }
    }).catch(()=>{});
  }
}
function loadGifsFromIDB(){
  idbOpen().then(()=>idbGetAllGifs()).then(rows=>{
    const m={};
    rows.forEach(r=>{if(r&&r.name&&r.b64) m[r.name]=r.b64;});
    if(Object.keys(m).length){
      App.gifAssets=m;
      if(window.Pages.library&&window.Pages.library.render) window.Pages.library.render();
      if(App.state.page==='home'&&window.Pages.home&&window.Pages.home.render) window.Pages.home.render();
    }
  }).catch(()=>{});
}
function normalizeDB(x){
  if(!x||!Array.isArray(x.exercises)||!Array.isArray(x.plans)||!Array.isArray(x.sessions))return null;
  x.sessions.forEach(s=>s.exercises?.forEach(e=>e.sets?.forEach(z=>{
    z.type=z.type||'正式';z.weight=z.weight??'';z.reps=z.reps??'';z.rir=z.rir??'';z.done=!!z.done;
  })));
  x.plans.forEach(p=>p.exercises?.forEach(e=>{e.warmups=Number(e.warmups||0);e.rir=e.rir??'';}));
  return x;
}
function ensureExerciseProfiles(){
  const db=App.db;
  db.exercises.forEach(e=>{e.name=normalizeExerciseName(e.name);});
  db.sessions.forEach(s=>s.exercises?.forEach(e=>{e.name=normalizeExerciseName(e.name);}));
  const seen=new Map(),idMap=new Map(),kept=[];
  db.exercises.forEach(e=>{
    if(!e.name) return;
    if(seen.has(e.name)){idMap.set(e.id,seen.get(e.name).id);}
    else{seen.set(e.name,e);kept.push(e);}
  });
  db.exercises=kept;
  (db.plans||[]).forEach(p=>{(p.exercises||[]).forEach(x=>{
    if(x.exerciseId&&idMap.has(x.exerciseId)) x.exerciseId=idMap.get(x.exerciseId);
    if(x.name) x.name=normalizeExerciseName(x.name);
  });});
  db.sessions.forEach(s=>s.exercises?.forEach(e=>{
    if(e.exerciseId&&idMap.has(e.exerciseId)) e.exerciseId=idMap.get(e.exerciseId);
  }));
  const byName=new Map(db.exercises.map(e=>[e.name,e]));
  db.sessions.forEach(s=>{
    (s.exercises||[]).forEach(e=>{
      if(!e.name) return;
      if(!byName.has(e.name)){
        const p=profileFor(e.name,e.part||'其他');
        const neu={id:uid(),name:e.name,part:p.part,type:normalizeEquipType(e.type||'',e.name),movement:p.movement,muscles:p.muscles,isCompound:p.isCompound};
        db.exercises.push(neu);byName.set(e.name,neu);
      }
      e.exerciseId=byName.get(e.name).id;
    });
  });
  db.exercises.forEach(e=>{
    const p=profileFor(e.name,e.part);
    e.part=p.part;e.movement=p.movement;e.isCompound=p.isCompound;e.muscles=p.muscles;
    e.type=normalizeEquipType(e.type,e.name);
  });
  db.sessions.forEach(s=>s.exercises?.forEach(e=>{
    const p=profileFor(e.name,e.part);
    e.part=p.part;e.movement=p.movement;e.isCompound=p.isCompound;e.muscles=e.muscles||p.muscles;
    e.rirOn=!!e.rirOn;e.note=e.note||'';
  }));
  return db;
}
function load(){
  App.state.today=new Date().toISOString().slice(0,10);
  try{
    const v=normalizeDB(JSON.parse(localStorage.getItem('gym_v5')));
    if(v){App.db=v;App.state.currentPlanId=localStorage.getItem('gym_v5_current')||null;ensureExerciseProfiles();return;}
  }catch(e){}
  App.db={exercises:DEFAULTS.map(x=>({...x})),plans:[],sessions:[]};
  ensureExerciseProfiles();
  save();
}

/* ─── 7. 会话工具（首页/日历共用） ─────────────────── */
function lastData(name,date){
  const arr=App.db.sessions.filter(s=>s.date<date).sort((a,b)=>b.date.localeCompare(a.date));
  for(const s of arr){
    const e=s.exercises.find(x=>x.name===name);
    if(e&&e.sets?.length) return {date:s.date,ex:e};
  }
  return null;
}
function makeSession(plan){
  const s={
    id:uid(),date:App.state.today,planId:plan.id,planName:plan.name,duration:0,
    exercises:plan.exercises.map(e=>{
      const lib=App.db.exercises.find(z=>z.id===e.exerciseId);
      const pmeta=(!lib&&String(e.exerciseId||'').startsWith('pack:'))?App.exerciseMeta[String(e.exerciseId).slice(5)]:null;
      const isBlankSet=!!e.blankSet;
      const last=isBlankSet?null:lastData(e.name,App.state.today);
      const savedSets=Number(e.sets);
      const n=isBlankSet?1:Math.max(1,Number.isFinite(savedSets)&&savedSets>0?savedSets:1);
      const w=Number(e.warmups||0);
      const sets=Array.from({length:n},(_,i)=>{
        const old=last?.ex?.sets?.[i];
        return{set:isBlankSet?'':i+1,weight:isBlankSet?'':(old?.weight??''),reps:isBlankSet?'':(old?.reps??''),rir:'',type:i<w?'热身':'正式',done:false};
      });
      return{name:lib?.name||pmeta?.中文名||e.name,exerciseId:e.exerciseId,part:lib?.part||(pmeta?packPart(pmeta.部位):e.part)||'其他',sets,note:'',rirOn:false};
    })
  };
  App.db.sessions.push(s);
  save();
  return s;
}
function getTodaySession(){
  if(!App.state.currentPlanId) App.state.currentPlanId='free';
  if(App.state.currentPlanId!=='free'&&!App.db.plans.some(p=>p.id===App.state.currentPlanId)){
    App.state.currentPlanId=App.db.plans[0]?.id||'free';
  }
  const plan=App.state.currentPlanId==='free'
    ? {id:'free',name:'训练',exercises:[]}
    : (App.db.plans.find(p=>p.id===App.state.currentPlanId)||{id:'free',name:'训练',exercises:[]});
  let s=App.db.sessions.find(x=>x.date===App.state.today&&x.planId===plan.id);
  if(!s) s=makeSession(plan);
  return s;
}
function dropEmptySessionFor(planId){
  const today=App.state.today;
  const i=App.db.sessions.findIndex(x=>x.date===today&&x.planId===planId&&!(x.exercises||[]).length);
  if(i>=0) App.db.sessions.splice(i,1);
}
function sessionStats(s){
  const all=s.exercises.flatMap(e=>e.sets||[]);
  const formal=all.filter(x=>(x.type||'正式')!=='热身');
  return{
    sets:formal.length,
    done:formal.filter(x=>x.done).length,
    reps:formal.reduce((a,x)=>a+(Number(x.reps)||0),0),
    volume:formal.reduce((a,e)=>a+(isFinite(Number(e.weight))?Number(e.weight)*(Number(e.reps)||0):0),0)
  };
}
function isSessionCompleted(s){
  if(!s) return false;
  if(s.completed) return true;
  const allSets=(s.exercises||[]).flatMap(e=>e.sets||[]);
  if(allSets.filter(x=>(x.type||'正式')!=='热身'&&x.done).length>0) return true;
  if(s.date<App.state.today){
    return allSets.some(x=>(Number(x.weight)>0||Number(x.reps)>0));
  }
  return false;
}
function calSessionsFor(ds){
  return App.db.sessions.filter(s=>s.date===ds&&isSessionCompleted(s)&&(ds!==App.state.today||s.completed===true));
}

/* ─── 8. 计时器 ───────────────────────────────────── */
function formatTimer(sec){const m=Math.floor(sec/60),s=sec%60;return m<60?`${m}:${String(s).padStart(2,'0')}`:`${m}`;}
function formatTimerUnit(sec){const m=Math.floor(sec/60);if(m<60) return '分钟';const s=sec%60;return s>0?`分 ${String(s).padStart(2,'0')}秒`:'分钟';}
function startTimer(){
  if(App.state.timerRunning) return;
  App.state.timerRunning=true;
  App.state.timerInterval=setInterval(()=>{
    App.state.timerSeconds++;
    const el=$('timerText');if(el) el.textContent=formatTimer(App.state.timerSeconds);
    const unit=$('timerUnit');if(unit) unit.textContent=formatTimerUnit(App.state.timerSeconds);
    const circle=$('timerCircle');if(circle) circle.classList.add('running');
  },1000);
  const btn=$('timerToggleBtn');if(btn){btn.textContent='暂停';btn.classList.add('active');}
  const circle=$('timerCircle');if(circle) circle.classList.add('running');
}
function pauseTimer(){
  App.state.timerRunning=false;clearInterval(App.state.timerInterval);App.state.timerInterval=null;
  const btn=$('timerToggleBtn');if(btn){btn.textContent='继续';btn.classList.remove('active');}
  const circle=$('timerCircle');if(circle) circle.classList.remove('running');
}
function resetTimer(){
  pauseTimer();App.state.timerSeconds=0;
  const el=$('timerText');if(el) el.textContent=formatTimer(0);
  const unit=$('timerUnit');if(unit) unit.textContent=formatTimerUnit(0);
  const btn=$('timerToggleBtn');if(btn){btn.textContent='开始';btn.classList.remove('active');}
  const circle=$('timerCircle');if(circle) circle.classList.remove('running');
}

/* ─── 9. 器材分类（动作库筛选） ───────────────────── */
function equipGroup(cat){
  const c=String(cat||'').trim();
  if(!c) return '其他';
  if(/EZ/i.test(c)) return 'EZ曲杆';
  if(/史密斯/.test(c)) return '史密斯机';
  return COMMON_EQUIPS.includes(c)?c:'其他';
}
function packEquipData(partScope){
  const ec={};
  Object.keys(App.exerciseMeta).forEach(k=>{
    const r=App.exerciseMeta[k];
    if(partScope&&partScope!=='全部'&&packPart(r.部位)!==partScope) return;
    const cat=equipGroup(r.器械);ec[cat]=(ec[cat]||0)+1;
  });
  const order=[...COMMON_EQUIPS,'其他'];
  const chips=Object.entries(ec).sort((a,b)=>order.indexOf(a[0])-order.indexOf(b[0]));
  return{chips,match(eq,cat){if(!eq) return true;return equipGroup(cat)===equipGroup(eq);}};
}

/* ─── 10. 训练频次统计（动作库排序用） ─────────────── */
function packFreqMap(){
  const freq={},keyBy={};
  App.db.exercises.forEach(e=>{
    if(e.mkey&&App.exerciseMeta[e.mkey]){
      if(e.name) keyBy[e.name]=e.mkey;
      if(e.orig) keyBy[e.orig]=e.mkey;
    }
  });
  App.db.sessions.forEach(s=>(s.exercises||[]).forEach(e=>{
    const formal=(e.sets||[]).filter(x=>(x.type||'正式')!=='热身'&&(x.done||x.reps>0));
    if(!formal.length) return;
    const k=keyBy[e.name]||normalizeExerciseName(e.name);
    if(!App.exerciseMeta[k]) return;
    if(!freq[k]) freq[k]={sets:0,reps:0};
    freq[k].sets+=formal.length;
    freq[k].reps+=formal.reduce((a,b)=>a+(Number(b.reps)||0),0);
  }));
  return freq;
}

/* ─── 11. 动作卡片渲染 ───────────────────────────── */
function renderPackCard(k,rec,o){
  o=o||{};
  const gif=(o.noGif?'':App.gifAssets[k])||'';
  return `<div class="lib-card ${o.cardClass||''}${o.sel?' picked':''}" data-packkey="${esc(k)}" ${o.attr||''}>
    ${gif?`<img class="lib-gif" src="${gif}" alt="" loading="lazy" onerror="this.style.display='none'">`:''}
    ${o.check?`<span class="${o.checkClass||'lib-check'}">✓</span>`:''}
    <div class="lib-name" title="${esc(rec.中文名||k)}">${esc(rec.中文名||k)}</div>
    <div class="lib-meta">${esc([rec.器械,rec.肌群||rec.主要肌群].filter(Boolean).join(' · '))}</div>
  </div>`;
}
function noPackPromptHTML(){
  return `<div class="empty" style="grid-column:1/-1;text-align:center;padding:30px 16px">
    <div style="font-size:42px;margin-bottom:8px">📦</div>
    <div style="font-size:14.5px;font-weight:900;color:var(--text)">尚未导入动作资源包</div>
    <div class="muted" style="font-size:12px;margin:6px 0 16px;line-height:1.6;max-width:280px">导入后即可查看 1300+ 个规范动作：GIF 动图、部位/器材/肌群筛选、按训练频次排序</div>
    <button id="noPackImportBtn" class="btn primary" style="padding:10px 22px;font-weight:900;border-radius:12px">📥 导入资源包 (ZIP)</button>
  </div>`;
}
function bindNoPackImport(){
  const b=$('noPackImportBtn');
  if(b) b.onclick=()=>{const i=$('gifImportInput');if(i) i.click();};
}
function renderExCard(x,o){
  o=o||{};
  const p=profileFor(x.name,x.part);
  const meta=[normalizeEquipType(x.type,x.name),normalizeMovementLabel(p.movement||x.movement),metaOfEx(x)?.肌群||''].filter(Boolean);
  return `<div class="lib-card ${o.cardClass||''}${o.sel?' picked':''}" ${o.attr||''}>
    ${hasGifEx(x)?`<img class="lib-gif" src="${gifOfEx(x)}" alt="" loading="lazy" onerror="this.style.display='none'">`:''}
    ${o.check?`<span class="${o.checkClass||'lib-check'}">✓</span>`:''}
    <div class="lib-name" title="${esc(x.name)}">${esc(x.name)}</div>
    <div class="lib-meta">${meta.map(t=>esc(t)).join(' · ')}</div>
  </div>`;
}

/* ─── 12. ★ 通用动作库浏览器（所有页面共用） ─────────
   这是整个 App 的核心组件：动作库页面、添加动作、替换动作、
   新建计划、对齐资料……全部调这一个函数。
   以后改动作库 UI/逻辑，只改这一处，全局生效。
   ═══════════════════════════════════════════════════ */
function libFilterKeys(opt){
  opt=opt||{};
  if(!Object.keys(App.exerciseMeta).length) return [];
  const part=opt.part||'全部';
  const equip=opt.equip||null;
  const heat=opt.heat||null;
  const cat=opt.cat||null;
  const q=(opt.q||'').toLowerCase();
  const ed=packEquipData(part);
  const freq=packFreqMap();
  const keys=Object.keys(App.exerciseMeta).filter(k=>{
    const r=App.exerciseMeta[k];
    if(part!=='全部'&&packPart(r.部位)!==part) return false;
    if(!ed.match(equip,(r.器械||'').trim()||'其他')) return false;
    if(heat&&(r.热度等级||'')!==heat) return false;
    if(cat&&(r.分类||'')!==cat) return false;
    if(q&&!(r.中文名||'').toLowerCase().includes(q)&&!(r.英文名||'').toLowerCase().includes(q)) return false;
    return true;
  });
  keys.sort((a,b)=>{
    const fa=freq[a],fb=freq[b];
    const ra=fa?fa.reps:0,rb=fb?fb.reps:0;
    if(rb!==ra) return rb-ra;
    const sa=fa?fa.sets:0,sb=fb?fb.sets:0;
    if(sb!==sa) return sb-sa;
    return 0;
  });
  return keys;
}
function mountLibraryBrowser(host,cfg){
  if(!host) return null;
  cfg=cfg||{};
  const multi=!!cfg.multi;
  const selected=new Set(cfg.selected||[]);
  const st={part:cfg.part||'全部',equip:null,heat:null,cat:null,q:'',page:0};
  host.innerHTML=`
    <div class="libb-toolbar"><input class="libb-search" placeholder="搜索动作…" aria-label="搜索动作" hidden><button type="button" class="libb-search-toggle" aria-label="打开动作搜索" title="搜索动作"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"></circle><path d="m20 20-4-4"></path></svg></button></div>
    <div class="libb-equip lib-part-chips" style="margin-top:6px"></div>
    <div class="libb-mini lib-mini-filters"></div>
    <div class="library-wrap picker-library-wrap libb-wrap">
      <aside class="libb-rail lib-rail picker-lib-rail lib-part-rail"></aside>
      <div class="libb-list lib-actions picker-lib-actions"></div>
    </div>`;
  const searchEl=host.querySelector('.libb-search');
  const toolbar=host.querySelector('.libb-toolbar');
  const searchToggle=host.querySelector('.libb-search-toggle');
  // All entry points share this browser. Move its search control into the modal's first header row.
  const header=host.closest('#sheet')?.querySelector(':scope > .row');
  const closeControl=header?.querySelector('button');
  if(header&&toolbar){ header.insertBefore(toolbar,closeControl||null); }
  if(searchToggle&&searchEl){
    searchToggle.addEventListener('click',()=>{
      const opening=searchEl.hidden;
      searchEl.hidden=!opening;
      searchToggle.classList.toggle('active',opening);
      if(opening) searchEl.focus(); else { searchEl.value=''; st.q=''; st.page=0; renderList(); }
    });
  }
  const equipEl=host.querySelector('.libb-equip');
  const miniEl=host.querySelector('.libb-mini');
  const railEl=host.querySelector('.libb-rail');
  const listEl=host.querySelector('.libb-list');
  const packOn=()=>!!Object.keys(App.exerciseMeta).length;
  function renderRail(){
    if(!packOn()){railEl.style.display='none';railEl.innerHTML='';return;}
    railEl.style.display='';
    const partOptions=packPartOptions();if(!partOptions.includes(st.part))st.part='全部';railEl.innerHTML=partOptions.map(p=>`<button type="button" class="lib-mpart ${st.part===p?'active':''}" data-part="${esc(p)}">${esc(p)}</button>`).join('');
    railEl.querySelectorAll('[data-part]').forEach(b=>b.onclick=()=>{st.part=b.dataset.part;st.page=0;renderRail();renderEquip();renderList();});
  }
  function renderEquip(){
    if(!packOn()){equipEl.style.display='none';equipEl.innerHTML='';return;}
    equipEl.style.display='';
    const ed=packEquipData(st.part);
    equipEl.innerHTML=`<button type="button" class="lib-part-chip ${!st.equip?'active':''}" data-eq="">全部</button>`+
      ed.chips.map(([c,n])=>`<button type="button" class="lib-part-chip ${st.equip===c?'active':''}" data-eq="${esc(c)}">${esc(shortEquip(c))}</button>`).join('');
    equipEl.querySelectorAll('[data-eq]').forEach(b=>b.onclick=()=>{const v=b.dataset.eq;st.equip=(st.equip===v?null:v);st.page=0;renderEquip();renderList();});
  }
  function renderMini(){
    if(!packOn()){miniEl.style.display='none';miniEl.innerHTML='';return;}
    miniEl.style.display='';
    const heats=[['高热度','高'],['中热度','中'],['低热度','低']];
    const cats=[['力量训练','力量'],['拉伸放松','拉伸'],['有氧体能','有氧']];
    miniEl.innerHTML=`<span class="lmf-label">热度</span>`+
      heats.map(([v,t])=>`<button type="button" class="lib-part-chip lmf-chip ${st.heat===v?'active':''}" data-h="${esc(v)}">${esc(t)}</button>`).join('')+
      `<span class="lmf-divider"></span><span class="lmf-label">分类</span>`+
      cats.map(([v,t])=>`<button type="button" class="lib-part-chip lmf-chip ${st.cat===v?'active':''}" data-c="${esc(v)}">${esc(t)}</button>`).join('');
    miniEl.querySelectorAll('[data-h]').forEach(b=>b.onclick=()=>{st.heat=(st.heat===b.dataset.h?null:b.dataset.h);st.page=0;renderMini();renderList();});
    miniEl.querySelectorAll('[data-c]').forEach(b=>b.onclick=()=>{st.cat=(st.cat===b.dataset.c?null:b.dataset.c);st.page=0;renderMini();renderList();});
  }
  function renderList(){
    if(!packOn()){listEl.innerHTML=noPackPromptHTML();bindNoPackImport();return;}
    const keys=libFilterKeys({part:st.part,equip:st.equip,heat:st.heat,cat:st.cat,q:st.q});
    if(!keys.length){listEl.innerHTML='<div class="empty" style="grid-column:1/-1">没有匹配动作</div>';return;}
    const PAGE=60;
    const view=keys.slice(0,(st.page+1)*PAGE);
    listEl.innerHTML=view.map(k=>{
      const yes=selected.has(k);
      return renderPackCard(k,App.exerciseMeta[k],{cardClass:'picker-lib-card',sel:multi&&yes,check:multi&&yes,checkClass:'lib-check'});
    }).join('');
    if(keys.length>view.length){
      listEl.insertAdjacentHTML('beforeend',`<button type="button" class="btn small libb-more" style="grid-column:1/-1;justify-self:center;margin-top:6px">显示更多（${keys.length-view.length}）</button>`);
    }
    listEl.querySelectorAll('.picker-lib-card').forEach(card=>{
      card.onclick=()=>{
        const k=card.dataset.packkey;
        const rec=k&&App.exerciseMeta[k];
        if(!rec) return;
        const pseudo={name:rec.中文名||k,id:'pack:'+k,part:packPart(rec.部位),type:normalizeEquipType(rec.器械||''),mkey:k};
        if(multi){
          if(selected.has(k)) selected.delete(k);else selected.add(k);
          renderList();
          if(typeof cfg.onChange==='function') cfg.onChange(selected.size);
        }else{
          if(typeof cfg.onPick==='function') cfg.onPick(pseudo);
        }
      };
    });
    const more=listEl.querySelector('.libb-more');
    if(more) more.onclick=()=>{st.page++;renderList();};
  }
  searchEl.addEventListener('input',()=>{st.q=(searchEl.value||'').trim().toLowerCase();st.page=0;renderList();});
  renderRail();renderEquip();renderMini();renderList();
  return{
    getSelected:()=>[...selected],
    setSelected:(arr)=>{selected.clear();(arr||[]).forEach(x=>selected.add(x));renderList();},
    refresh:()=>{renderRail();renderEquip();renderMini();renderList();}
  };
}
function openActionPicker({title,onSelect,multi=false,selected=[]}){
  $('sheet').innerHTML=`
    <div class="row between">
      <h2 style="margin:0;font-size:17px;font-weight:900">${esc(title||'选择动作')}</h2>
      <button id="pickerCloseBtn" class="link-btn">关闭</button>
    </div>
    <div id="pickerHost"></div>
    ${multi?`<div class="picker-foot"><button id="pickerAddBtn" class="btn primary" disabled>至少选择一个动作</button></div>`:''}`;
  $('modal').classList.add('show');
  $('pickerCloseBtn').onclick=closeModal;
  let browser=null;
  function updateMultiBtn(){
    const b=$('pickerAddBtn');if(!b) return;
    const n=browser?browser.getSelected().length:0;
    b.textContent=n?`添加已选 ${n} 个动作`:'至少选择一个动作';
    b.disabled=n===0;
  }
  browser=mountLibraryBrowser($('pickerHost'),{multi,selected,onChange:updateMultiBtn,onPick:(pseudo)=>{closeModal();onSelect(pseudo);}});
  if(multi&&$('pickerAddBtn')){
    updateMultiBtn();
    $('pickerAddBtn').onclick=()=>{
      const keys=browser?browser.getSelected():[];
      if(!keys.length){toast('请先选择动作');return;}
      const arr=keys.map(k=>{const r=App.exerciseMeta[k];return{name:r.中文名||k,id:'pack:'+k,part:packPart(r.部位),type:normalizeEquipType(r.器械||''),mkey:k};});
      closeModal();onSelect(arr);
    };
  }
}

/* ─── 13. 动作详情弹窗 ───────────────────────────── */
function showExerciseDetail(name){
  name=normalizeExerciseName(name||'');
  if(!name){toast('未找到该动作');return;}
  const ex=App.db.exercises.find(x=>x.name===name);
  const m=metaOfEx(ex)||metaFor(name);
  const g=gifOfEx(ex)||gifFor(name);
  const panel=$('detailPanel');
  if(!panel) return;
  let html=`<div class="row between"><h2 style="margin:0">${esc(m?.中文名||name)}</h2><button id="exInfoClose" class="link-btn">关闭</button></div>`;
  if(g) html+=`<div style="display:flex;justify-content:center;margin:12px 0 2px"><img class="lib-gif-detail" src="${g}" alt="" onerror="this.style.display='none'"></div>`;
  if(m){
    html+=`<div class="muted" style="margin:8px 0 2px">${esc(m.英文名||'')}</div>`;
    html+=`<div class="exinfo-grid">${[['部位','部位'],['器械','器械'],['主要肌群','主要肌群'],['协同肌群','协同肌群']].map(([label,key])=>{const v=key==='主要肌群'?(m.主要肌群??m.肌群??m.辅助肌群): (key==='协同肌群'?(m.协同肌群??m.辅助肌群):m[key]); const text=Array.isArray(v)?v.join('、'):(v==null?'':String(v)); return `<div class="exinfo-cell"><div class="exinfo-k">${label}</div><div class="exinfo-v">${esc(text||'—')}</div></div>`}).join('')}</div>`;
    if(Array.isArray(m.次要用力)&&m.次要用力.length) html+=`<div class="muted" style="margin:12px 0 4px">次要用力</div><div class="detail-tags">${m.次要用力.map(t=>`<span class="detail-tag">${esc(t)}</span>`).join('')}</div>`;
    if(Array.isArray(m.步骤)&&m.步骤.length) html+=`<div class="muted" style="margin:12px 0 2px">动作步骤</div><ol class="exinfo-steps">${m.步骤.map(s=>`<li>${esc(s)}</li>`).join('')}</ol>`;
  }else{
    html+=`<div class="hint-note" style="margin-top:10px">尚未导入动作资源包（动作数据.json）。</div>`;
  }
  panel.innerHTML=html;
  $('detailOverlay').classList.add('show');
  $('exInfoClose').onclick=()=>$('detailOverlay').classList.remove('show');
  panel.scrollTop=0;
}

/* ─── 14. 名称对齐 ─────────────────────────────── */
function lcsLen(a,b){const m=a.length,n=b.length,dp=Array.from({length:m+1},()=>new Array(n+1).fill(0));for(let i=1;i<=m;i++)for(let j=1;j<=n;j++)dp[i][j]=a[i-1]===b[j-1]?dp[i-1][j-1]+1:Math.max(dp[i-1][j],dp[i][j-1]);return dp[m][n];}
function alignScore(a,b){
  if(a===b) return 1;
  let s;
  if(b.includes(a)) s=0.8+0.18*(a.length/b.length);
  else if(a.includes(b)) s=0.8+0.1*(b.length/a.length)-Math.max(0,(a.length-b.length))*0.10;
  else s=2*lcsLen(a,b)/(a.length+b.length);
  const tail=a.slice(-2);if(tail&&!b.endsWith(tail)) s-=0.45;
  const head=a.slice(0,2);if(head&&b.includes(head)) s+=0.18;
  return s;
}
function alignCandidates(name,topN){
  topN=topN||8;
  const k=normalizeExerciseName(name);
  const ex=App.db.exercises.find(x=>normalizeExerciseName(x.name)===k);
  const EQUIP_WORDS=['杠铃','哑铃','绳索','壶铃','弹力带','史密斯','杠杆','雪橇','自重','龙门','器械'];
  const VAR_MARK=/单腿|单手|单臂|跳|宽|窄|过顶|交叉|交替|变式|版本|跪姿|俯身|仰卧|（|蹲架|高翻|直立|前侧|奥杠|奥杆|坐姿|上斜/;
  const scored=[];
  Object.keys(App.exerciseMeta).forEach(pk=>{
    const rec=App.exerciseMeta[pk];
    let s=alignScore(k,pk);
    const localEq=EQUIP_WORDS.find(w=>k.includes(w)),packEq=EQUIP_WORDS.find(w=>pk.includes(w));
    if(localEq&&localEq===packEq) s+=0.08;
    else if(ex&&ex.type&&normalizeEquipType(rec.器械||'')===ex.type) s+=0.03;
    if(VAR_MARK.test(pk)) s-=0.015;
    if(/奥杠|奥杆/.test(pk)) s-=0.05;
    if(/全程|高杠|低杠/.test(pk)) s+=0.10;
    if(s>=0.5) scored.push([s,pk]);
  });
  scored.sort((x,y)=>y[0]-x[0]||(x[1].length-y[1].length)||x[1].localeCompare(y[1],'zh'));
  const out=[];
  scored.slice(0,topN).forEach(([s,pk])=>out.push({k:pk,s,rec:App.exerciseMeta[pk]}));
  return out;
}
function alignExactAuto(){
  if(!Object.keys(App.exerciseMeta).length) return 0;
  let n=0;
  App.db.exercises.forEach(ex=>{
    const rec=App.exerciseMeta[normalizeExerciseName(ex.name)];
    if(rec){
      ex.mkey=normalizeExerciseName(rec.中文名);
      if(rec.部位) ex.part=packPart(rec.部位);
      if(rec.器械) ex.type=normalizeEquipType(rec.器械,ex.name);
      n++;
    }else ex.part=packPart(ex.part);
  });
  if(n) save();
  return n;
}
function applyAlignRow(exId,packKey){
  const ex=App.db.exercises.find(x=>x.id===exId);
  if(!ex||!App.exerciseMeta[packKey]) return false;
  const rec=App.exerciseMeta[packKey];
  const oldName=ex.name;
  if(!ex.orig&&oldName&&normalizeExerciseName(oldName)!==packKey) ex.orig=oldName;
  ex.mkey=packKey;
  if(rec.部位) ex.part=packPart(rec.部位);
  if(rec.器械) ex.type=normalizeEquipType(rec.器械,ex.name);
  const newName=rec.中文名||ex.name;
  if(newName!==oldName){
    App.db.sessions.forEach(s=>(s.exercises||[]).forEach(e=>{if(e.name===oldName) e.name=newName;}));
    ex.name=newName;
  }
  save();return true;
}
function dedupeExercises(){
  const seen=new Map(),remap=new Map(),kept=[];
  App.db.exercises.forEach(e=>{
    const k=normalizeExerciseName(e.name);
    if(seen.has(k)){const t=seen.get(k);if(!t.orig&&e.orig) t.orig=e.orig;remap.set(e.id,t.id);}
    else{seen.set(k,e);kept.push(e);}
  });
  if(remap.size){
    (App.db.plans||[]).forEach(p=>(p.exercises||[]).forEach(x=>{if(x.exerciseId&&remap.has(x.exerciseId)) x.exerciseId=remap.get(x.exerciseId);}));
    App.db.exercises=kept;save();
  }
}
function needReviewCount(){
  if(!Object.keys(App.exerciseMeta).length) return 0;
  return App.db.exercises.filter(ex=>!App.exerciseMeta[normalizeExerciseName(ex.name)]&&alignCandidates(ex.name,1).length>0).length;
}
function openAlignReview(){
  if(!Object.keys(App.exerciseMeta).length){toast('请先导入动作资源包');return;}
  const autoN=alignExactAuto();
  const rows=[];
  App.db.exercises.forEach(ex=>{
    const ek=normalizeExerciseName(ex.name);
    const curKey=(ex.mkey&&App.exerciseMeta[ex.mkey])?ex.mkey:(App.exerciseMeta[ek]?ek:null);
    const cur=curKey?App.exerciseMeta[curKey]:null;
    rows.push({id:ex.id,local:ex.name,orig:ex.orig||'',curKey,cur});
  });
  if(!rows.length){
    closeModal();
    if(window.Pages.library&&window.Pages.library.render) window.Pages.library.render();
    toast(autoN?`已按资源包自动对齐 ${autoN} 个动作`:'本地暂无动作需要校对');
    return;
  }
  const alignedN=rows.filter(r=>r.cur).length;
  $('sheet').innerHTML=`<div class="row between"><h2 style="margin:0;font-size:17px;font-weight:900">动作对齐（以资源包为准）</h2><button id="alignClose" class="link-btn">完成</button></div>
    <div class="align-note">本地共 <b>${rows.length}</b> 个动作：<b>${alignedN}</b> 个已关联（<b>${autoN}</b> 个自动匹配），其余待校对。点每行<b>「选择动作」</b>打开资源包动作库，找到对应动作选中即完成对齐。</div>
    <input id="alignFind" class="search" placeholder="搜索本地动作名称…" style="width:100%;box-sizing:border-box;margin:0 0 6px">
    <div style="display:flex;gap:8px;margin-bottom:4px">
      <button id="alignAll" class="btn primary" style="flex:1">✓ 全部应用建议</button>
      <button id="alignSkipAll" class="btn" style="flex:1">跳过全部</button>
    </div>
    ${rows.map(r=>{
      const origName=r.orig||r.local;
      const curName=r.cur?r.cur.中文名:'未关联';
      const gif=r.curKey?App.gifAssets[r.curKey]:'';
      return `<div class="align-row" data-local="${esc(r.local)}">
        ${gif?`<img class="align-gif" data-detail="${esc(r.cur.中文名)}" src="${esc(gif)}" onerror="this.style.display='none'">`:`<div class="align-gif" style="background:var(--panel);border:1px dashed var(--line);display:inline-flex;align-items:center;justify-content:center;color:var(--muted)">?</div>`}
        <div class="align-main">
          <div style="display:flex;align-items:center;gap:6px;min-width:0"><span class="align-k">原名称（CSV）</span><span class="align-orig" data-detail="${esc(curName)}">${esc(origName)}</span></div>
          <div style="display:flex;align-items:center;gap:6px;min-width:0"><span class="align-k">对齐为</span><span class="align-cur">${esc(curName)}</span></div>
          <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;margin-top:2px">
            <span class="muted" style="font-size:11px">${r.cur?'已关联':'待校对'}</span>
            <span style="display:flex;gap:6px">
              <button class="align-pick" data-aid="${r.id}">${r.cur?'更换':'选择动作'}</button>
              <button class="align-skip" data-aid="${r.id}">${r.cur?'保持':'跳过'}</button>
            </span>
          </div>
        </div>
      </div>`;
    }).join('')}`;
  $('modal').classList.add('show');
  const close=()=>{closeModal();dedupeExercises();if(window.Pages.library&&window.Pages.library.render) window.Pages.library.render();};
  $('alignClose').onclick=close;
  $('alignFind').addEventListener('input',e=>{
    const q=(e.target.value||'').trim().toLowerCase();
    document.querySelectorAll('.align-row').forEach(row=>{row.style.display=(!q||(row.dataset.local||'').toLowerCase().includes(q))?'':'none';});
  });
  $('alignAll').onclick=()=>{
    let n=0;
    App.db.exercises.forEach(ex=>{
      const ek=normalizeExerciseName(ex.name);
      if(App.exerciseMeta[ek]) return;
      const c=alignCandidates(ex.name,1)[0];
      if(c&&applyAlignRow(ex.id,c.k)) n++;
    });
    close();toast(`已按资源包对齐 ${n} 个动作`);
  };
  $('alignSkipAll').onclick=close;
  document.querySelectorAll('.align-pick').forEach(b=>{
    b.onclick=()=>{
      const aid=b.dataset.aid;
      const ex=App.db.exercises.find(x=>x.id===aid);
      const localName=ex?ex.name:'';
      closeModal();
      openActionPicker({
        title:`选择「${localName}」对齐到…`,
        onSelect:(pseudo)=>{
          if(pseudo&&pseudo.mkey&&applyAlignRow(aid,pseudo.mkey)) toast(`「${localName}」→「${pseudo.name}」`);
          openAlignReview();
        }
      });
    };
  });
  document.querySelectorAll('.align-skip').forEach(b=>{
    b.onclick=()=>{const row=b.closest('.align-row');if(row) row.style.opacity=.45;};
  });
  document.querySelectorAll('.align-gif[data-detail],.align-orig[data-detail]').forEach(el=>{
    el.addEventListener('click',()=>{const d=el.dataset.detail;if(d&&d!=='未关联') showExerciseDetail(d);});
  });
}

/* ─── 15. 主题 ─────────────────────────────────── */
function applyTheme(themeKey){
  if(!THEMES[themeKey]) themeKey='sky';
  document.body.dataset.theme=themeKey;
  localStorage.setItem('gym_pastel_theme',themeKey);
  const metaEl=$('themeMeta');if(metaEl) metaEl.setAttribute('content',THEMES[themeKey].bg);
  if(window.AndroidBridge&&typeof window.AndroidBridge.setStatusBarColor==='function'){
    try{window.AndroidBridge.setStatusBarColor(THEMES[themeKey].bg);}catch(e){}
  }
}
function currentTheme(){return localStorage.getItem('gym_pastel_theme')||'sky';}

/* ─── 15.5 文件读取与资源包解析（CSV / ZIP 统一入口） ───
   ★ 这是 ZIP 导入 bug 的根治方案：
     - 用 FileReader 读成 base64 dataURL，再交给 JSZip base64 模式
     - base64 是所有 Android WebView 都支持的最兼容写法
     - 万一失败自动回退到 ArrayBuffer 方式
     - CSV 也走同一个 readFileAs，架构完全统一
   ═══════════════════════════════════════════════════════ */

/* 通用文件读取：CSV 用 'text'，ZIP 用 'dataURL'（都从这一个入口走） */
function readFileAs(file, type) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error || new Error('读取文件失败'));
    if (type === 'text') reader.readAsText(file);
    else if (type === 'arrayBuffer') reader.readAsArrayBuffer(file);
    else if (type === 'dataURL') reader.readAsDataURL(file);
    else reject(new Error('不支持的类型：' + type));
  });
}

/* 解析动作资源包 ZIP：接受 File 对象
   返回 { meta, gifs, jsonCount, gifCount }
     meta = { 规范名: 动作记录 }      （动作数据.json 里的元数据）
     gifs = [{ name, data }]          （动图：name 是规范名，data 是 base64 dataURL）
*/
async function parseResourcePack(file) {
  if (!window.JSZip) throw new Error('ZIP 解析组件缺失');

  // 步骤 1：先读成 base64 dataURL（所有 WebView 都兼容）
  const dataURL = await readFileAs(file, 'dataURL');
  const b64 = String(dataURL || '').split(',')[1];
  if (!b64) throw new Error('无法读取 ZIP 内容');

  // 步骤 2：交给 JSZip，base64 模式优先
  let zip;
  try {
    zip = await JSZip.loadAsync(b64, { base64: true });
  } catch (e1) {
    // 回退：ArrayBuffer 方式再试一次
    try {
      const buf = await readFileAs(file, 'arrayBuffer');
      zip = await JSZip.loadAsync(buf);
    } catch (e2) {
      throw new Error('无法解析 ZIP：' + (e1 && e1.message ? e1.message : e1));
    }
  }

  // 步骤 3：读 动作数据.json
  const jsonEntry = Object.values(zip.files).find(e => !e.dir && /动作数据\.json$/i.test(e.name));
  if (!jsonEntry) throw new Error('资源包内未找到 动作数据.json');
  const txt = await jsonEntry.async('text');
  let arr;
  try { arr = JSON.parse(txt); } catch (e) { throw new Error('动作数据.json 不是合法的 JSON'); }
  if (!Array.isArray(arr) || !arr.length) throw new Error('动作数据.json 内容为空');

  // 步骤 4：规范化元数据
  const meta = {};
  const gifNameIndex = {};
  arr.forEach(rec => {
    if (rec && rec.中文名) {
      const k = normalizeExerciseName(rec.中文名);
      meta[k] = rec;
      if (rec.GIF) {
        const gk = normalizeExerciseName(String(rec.GIF).replace(/\.[a-zA-Z0-9]+$/, ''));
        if (gk && !gifNameIndex[gk]) gifNameIndex[gk] = k;
      }
    }
  });

  // 步骤 5：提取 GIF / 图片
  const imgEntries = Object.values(zip.files).filter(e => !e.dir && /\.(gif|png|jpe?g|webp)$/i.test(e.name));
  const gifs = [];
  for (const e of imgEntries) {
    try {
      const b64Img = await e.async('base64');
      const raw = e.name.split('/').pop().replace(/\.[a-zA-Z0-9]+$/, '').trim();
      let nm = normalizeExerciseName(raw);
      if (nm && !meta[nm] && gifNameIndex[nm]) nm = gifNameIndex[nm];
      if (nm) {
        const MIME = /\.png$/i.test(e.name) ? 'image/png'
                   : /\.jpe?g$/i.test(e.name) ? 'image/jpeg'
                   : /\.webp$/i.test(e.name) ? 'image/webp'
                   : 'image/gif';
        gifs.push({ name: nm, data: 'data:' + MIME + ';base64,' + b64Img });
      }
    } catch (err) { /* 单张失败跳过 */ }
  }

  return { meta, gifs, jsonCount: Object.keys(meta).length, gifCount: gifs.length };
}

/* ─── 16. 导航 ─────────────────────────────────── */
function go(page){
  App.state.page=page;
  document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===page));
  document.querySelectorAll('.nav button').forEach(b=>b.classList.toggle('active',b.dataset.page===page));
  if(window.Pages.home&&page==='home') window.Pages.home.render();
  if(window.Pages.calendar&&page==='calendar') window.Pages.calendar.render();
  if(window.Pages.history&&page==='history') window.Pages.history.render();
  if(window.Pages.library&&page==='library') window.Pages.library.render();
  window.scrollTo(0,0);
}

/* ─── 17. 全局事件 ────────────────────────────── */
function initGlobalEvents(){
  const modal=$('modal');
  if(modal) modal.addEventListener('click',e=>{if(e.target===modal) closeModal();});
  document.querySelectorAll('.nav button').forEach(b=>{
    b.addEventListener('click',()=>go(b.dataset.page));
  });
}

/* ─── 18. 暴露 API ───────────────────────────── */
Object.assign(App,{
  // 工具
  $,esc,uid,toast,closeModal,appConfirm,fmtNum,fmtVolume,partSizeRank,shortEquip,packPart,packPartOptions,activePackParts,
  // IndexedDB
  idbOpen,idbPutMeta,idbGetMeta,idbPutGif,idbDelGif,idbClearGifs,idbGetAllGifs,
  // 元数据
  normalizeExerciseName,normalizeEquipType,normalizeMovementLabel,profileFor,
  metaFor,gifFor,hasGif,metaOfEx,gifOfEx,hasGifEx,
  // 持久化
  save,saveMeta,loadMeta,loadGifsFromIDB,normalizeDB,ensureExerciseProfiles,load,
  // 会话
  lastData,makeSession,getTodaySession,dropEmptySessionFor,sessionStats,isSessionCompleted,calSessionsFor,
  // 计时器
  formatTimer,formatTimerUnit,startTimer,pauseTimer,resetTimer,
  // 器材
  equipGroup,packEquipData,
  // 频次
  packFreqMap,
  // 卡片
  renderPackCard,noPackPromptHTML,bindNoPackImport,renderExCard,
  // 动作库选择器
  libFilterKeys,mountLibraryBrowser,openActionPicker,
  // 详情
  showExerciseDetail,
  // 对齐
  lcsLen,alignScore,alignCandidates,alignExactAuto,applyAlignRow,dedupeExercises,needReviewCount,openAlignReview,
  // 主题
  applyTheme,currentTheme,
  // 文件与资源包（★ 新增）
  readFileAs,parseResourcePack,
  // 导航
  go,
  // 事件
  initGlobalEvents
});
})();