/* ═════════════════════════════════════════════════════════════
   [MODULE: page/home] 训练首页
   ─────────────────────────────────────────────────────────────
   职责：计划切换 · 今日训练计时器 · 动作卡片 · 组数据录入 ·
         拖动排序 · 备注 · 递减组 · 超级组 · 完成打卡
   依赖：App.*（core.js 暴露）
   注册：window.Pages.home
   ═════════════════════════════════════════════════════════════ */
(function(){
'use strict';
const $=id=>document.getElementById(id);

/* 统一线性图标（Feather/Lucide 风格） */
function uiIcon(name){
  const paths={
    note:'<path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/>',
    rir:'<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>',
    swap:'<polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>',
    del:'<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/>',
    fill:'<line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/>',
    plus:'<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>'
  };
  return `<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name]||''}</svg>`;
}

/* ─── 主渲染 ─────────────────────────────────────── */
function render(){
  const box=$('homeBox'); if(!box) return;
  const App=window.App, state=App.state, db=App.db, esc=App.esc;

  if(!db.plans) db.plans = [];
  if(!state.currentPlanId) state.currentPlanId='free';
  if(state.currentPlanId !== 'free' && !db.plans.some(p=>p.id===state.currentPlanId)){
    state.currentPlanId=db.plans[0]?.id||'free';
  }
  App.save();

  const plan = state.currentPlanId === 'free'
    ? { id:'free', name:'训练', exercises:[] }
    : (db.plans.find(p=>p.id===state.currentPlanId) || { id:'free', name:'训练', exercises:[] });
  const s = App.getTodaySession();
  const stt = App.sessionStats(s);
  const pct = stt.sets ? Math.round(stt.done/stt.sets*100) : 0;

  /* 1. 计划栏 */
  let html=`<div class="plan-compact-bar">
    <div class="plan-pill-scroll">
      <button class="plan-pill-btn new-plan-btn" id="homeNewPlanBtn" title="新建训练计划">＋ 新建计划</button>
      ${db.plans.map(p => `<button class="plan-pill-btn ${p.id===state.currentPlanId?'active':''}" data-plan="${p.id}">${esc(p.name)}</button>`).join('')}
    </div>
    <button class="plan-pill-btn manage-btn" id="homeManagePlanBtn" title="管理训练计划">管理</button>
  </div>`;

  /* 2. 今日训练摘要 + 计时器 */
  html += `<div class="card tight today-summary-sticky">
    <div class="row between" style="align-items:center;margin-bottom:6px;flex-wrap:wrap;gap:6px">
      <div style="display:flex;align-items:center;gap:6px;min-width:0">
        <span style="font-size:13.5px;font-weight:900">📅 ${state.today}</span>
        <button id="planNameBadge" class="badge-pill badge-blue" style="border:0;cursor:pointer;display:inline-flex;align-items:center;gap:3px;line-height:1.3" title="点击修改计划名称">${esc(plan.name)} ✎</button>
        <input id="planNameInput" class="small-input" value="${esc(plan.name)}" maxlength="30" placeholder="计划名称" style="display:none;min-width:130px">
      </div>
      <button id="supersetBatchBtn" class="btn small" style="background:#f5f3ff;color:#7c3aed;border:1px solid #ddd6fe;font-weight:850;border-radius:8px;padding:3px 8px;font-size:11.5px">🔗 超级组</button>
    </div>
    <div class="timer-hero">
      <div id="timerCircle" class="timer-circle ${state.timerRunning?'running':''}">
        <div class="timer-circle-main" id="timerText">${App.formatTimer(state.timerSeconds)}</div>
        <div class="timer-circle-unit" id="timerUnit">${App.formatTimerUnit(state.timerSeconds)}</div>
      </div>
      <div class="timer-circle-btns">
        <button id="timerToggleBtn" class="timer-btn ${state.timerRunning ? 'active' : ''}">${state.timerRunning ? '暂停' : '开始'}</button>
        <button id="timerResetBtn" class="timer-btn">重置</button>
      </div>
      <div class="timer-hero-stats">
        <div class="statbar">
          <div class="stat"><b>${stt.done}</b><span>完成组</span></div>
          <div class="stat"><b>${stt.sets}</b><span>正式组</span></div>
          <div class="stat"><b>${stt.reps}</b><span>总次数</span></div>
          <div class="stat"><b>${App.fmtVolume(stt.volume)}</b><span>吨位(kg)</span></div>
        </div>
        <div class="progress" style="margin-top:8px;height:5px"><i style="width:${pct}%"></i></div>
      </div>
    </div>
  </div>`;

  /* 3. 动作卡片 */
  s.exercises.forEach((e,ei)=>{
    const complete=e.sets.length>0&&e.sets.every(x=>x.type==='热身'||x.done);
    const rirOn=!!e.rirOn;
    const hasSuperset=!!e.superset;
    const nameLen=String(e.name||'').length;
    const nameFs=nameLen<=6?16:nameLen<=10?15:nameLen<=14?13.5:nameLen<=18?12.5:nameLen<=24?11.5:10.5;
    const hasNote=!!(e.note&&String(e.note).trim());

    html+=`<div class="exercise ${complete?'done-card':''} ${hasSuperset?'superset-active':''}">
      <div class="ex-head-streamlined">
        <div class="ex-head-row-top">
          <div style="display:flex;align-items:center;gap:5px;min-width:0;flex:1;overflow:hidden">
            ${App.hasGif(e.name)?`<img class="ex-gif" src="${App.gifFor(e.name)}" alt="" loading="lazy" onerror="this.style.display='none'">`:''}
            <span class="ex-name" style="font-size:${nameFs}px" title="${esc(e.name)}">${ei+1}. ${esc(e.name)}</span>
          </div>
          ${hasSuperset?`<span class="superset-badge" style="margin-right:36px">🔗 ${esc(e.superset)}</span>`:''}
          <button type="button" class="ex-drag-handle" data-drag-ei="${ei}" title="按住并拖动调整动作顺序" aria-label="拖动调整动作顺序">⋮⋮</button>
        </div>
      </div>
      <div class="set-head ${rirOn?'rir-on':''}" style="margin-top:8px">
        <span class="set-label" title="删除组">×</span>
        <span class="set-label">组</span>
        <span class="set-label">类型</span>
        <span class="set-label">重量</span>
        <span class="set-label">次数</span>
        ${rirOn?'<span class="set-label">RIR</span>':''}
        <span class="set-label" title="完成状态">✓</span>
      </div>`;

    e.sets.forEach((x,si)=>{
      html+=`<div class="set-table ${rirOn?'rir-on':''}">
        <button class="del-set" data-action="del" data-ei="${ei}" data-si="${si}" title="删除此组">×</button>
        <span class="set-label">${x.set}</span>
        <button class="type-pill ${x.type==='热身'?'warm':(x.type==='递减'?'drop':'formal')}" data-action="type" data-ei="${ei}" data-si="${si}">${x.type||'正式'}</button>
        <input class="field ${x.weight!==''?'prefilled':''}" data-ei="${ei}" data-si="${si}" data-k="weight" inputmode="decimal" placeholder="kg" value="${esc(x.weight)}">
        <input class="field ${x.reps!==''?'prefilled':''}" data-ei="${ei}" data-si="${si}" data-k="reps" inputmode="numeric" placeholder="次数" value="${esc(x.reps)}">
        ${rirOn?`<input class="field" data-ei="${ei}" data-si="${si}" data-k="rir" list="rirList" inputmode="numeric" placeholder="-" value="${esc(x.rir)}">`:''}
        <button class="done ${x.done?'yes':''}" data-action="done" data-ei="${ei}" data-si="${si}">${x.done?'✓':'○'}</button>
      </div>`;
    });
    html+=`<div class="set-actions">
      <button class="act-tool-btn t-clear" data-action="clear-ex-data" data-ei="${ei}" title="清空当前动作的所有数据，但保留空白组" aria-label="清空">空</button>
      <button class="act-tool-btn" data-action="fill" data-ei="${ei}" title="向下填充空白组" aria-label="向下填充">${uiIcon('fill')}</button>
      <button class="act-tool-btn" data-action="add" data-ei="${ei}" title="加一组" aria-label="加一组">${uiIcon('plus')}</button>
      <button class="act-tool-btn t-copy use-last-btn" data-action="use-last" data-ei="${ei}" title="套用上次记录（清空后填入上一次的重量/次数）" aria-label="套用上次">复</button>
      <button class="act-tool-btn t-note note-action-btn ${hasNote?'has-note':''}" data-ei="${ei}" title="${hasNote?esc(e.note):'添加备注'}" aria-label="备注">${uiIcon('note')}</button>
      <button class="act-tool-btn t-rir rir-action-btn ${rirOn?'active':''}" data-action="rir" data-ei="${ei}" title="开关 RIR（离力竭还有几下）" aria-label="RIR">R</button>
      <button class="act-tool-btn replace-action-btn" data-ei="${ei}" title="替换动作" aria-label="替换动作">${uiIcon('swap')}</button>
      <span class="act-tool-sep" aria-hidden="true"></span>
      <button class="act-tool-btn act-tool-del delete-action-btn" data-ei="${ei}" title="删除动作" aria-label="删除动作">${uiIcon('del')}</button>
    </div>
  </div>`;
  });

  /* 4. 底部按钮 */
  html+=`<div style="display:flex;gap:8px;margin-top:14px;width:100%">
    <button id="addWorkoutExBtn" class="btn primary" style="flex:1;padding:12px 14px;font-size:14.5px;font-weight:900;border-radius:14px;display:flex;align-items:center;justify-content:center;gap:6px;box-shadow:0 3px 12px color-mix(in srgb,var(--primary) 20%,transparent)"><span>➕ 添加动作</span></button>
    <button id="clearAllExBtn" class="btn" style="flex:none;padding:12px 14px;font-size:13.5px;font-weight:900;border-radius:14px;background:#fff1f1;color:var(--red);border:1px solid #fecaca;display:flex;align-items:center;justify-content:center;gap:4px"><span>🗑️ 清空全部</span></button>
  </div>`;
  html+=`<div class="workout-finish-footer" style="margin-top:24px;margin-bottom:24px;width:100%">
    <button id="finishBtn" class="btn primary" style="width:100%;height:48px;font-size:16px;font-weight:900;border-radius:14px;box-shadow:0 4px 16px color-mix(in srgb,var(--primary) 28%,transparent);display:flex;align-items:center;justify-content:center;gap:6px"><span>✓ 完成并保存今日训练</span></button>
  </div>`;

  box.innerHTML=html;
  bindEvents(s);
  bindDrag(s);
  fitNames();
}

/* ─── 名称自适应缩放 ─────────────────────────────── */
function fitNames(){
  document.querySelectorAll('.ex-name').forEach(el=>{
    let fs=parseFloat(el.style.fontSize)||16; const min=9;
    while(el.scrollWidth>el.clientWidth+1 && fs>min){ fs=Math.max(min,fs-0.5); el.style.fontSize=fs+'px'; }
  });
}

/* ─── 递减组弹窗 ─────────────────────────────────── */
function openDropSetModal(ex,si){
  const App=window.App, esc=App.esc;
  const sets=ex.sets||[], cur=sets[si];
  let baseW=cur?.weight, baseR=cur?.reps;
  if((baseW===''||baseW==null)&&(baseR===''||baseR==null)){
    for(let i=si-1;i>=0;i--){
      const p=sets[i];
      if((p.weight!==''&&p.weight!=null)||(p.reps!==''&&p.reps!=null)){
        if(baseW===''||baseW==null) baseW=p.weight;
        if(baseR===''||baseR==null) baseR=p.reps;
        if((baseW!==''&&baseW!=null)&&(baseR!==''&&baseR!=null)) break;
      }
    }
  }
  const w=(baseW!==''&&baseW!=null)?baseW:'', r=(baseR!==''&&baseR!=null)?baseR:'';
  const lab='font-size:11.5px;font-weight:850;color:var(--muted);margin:10px 0 5px';
  $('sheet').innerHTML=`
    <div class="row between"><h2 style="margin:0;font-size:17.5px;font-weight:900">⚙️ 递减组设置</h2><button id="dropClose" class="link-btn">取消</button></div>
    <div class="muted" style="margin-top:4px;font-size:12px;line-height:1.55">以当前组为基准，按设置的幅度自动生成后续递减组。</div>
    <div style="margin-top:14px">
      <div style="${lab}">基准重量（kg）</div><input id="dropW" class="field" type="number" inputmode="decimal" value="${esc(w)}">
      <div style="${lab}">基准次数</div><input id="dropR" class="field" type="number" inputmode="numeric" value="${esc(r)}">
      <div style="${lab}">每组递减重量（kg）</div><input id="dropStepW" class="field" type="number" inputmode="decimal" value="2.5">
      <div style="${lab}">每组递减次数</div><input id="dropStepR" class="field" type="number" inputmode="numeric" value="0">
      <div style="${lab}">后面追加的递减组数</div><input id="dropN" class="field" type="number" inputmode="numeric" value="2">
    </div>
    <button id="dropOk" class="btn primary" style="width:100%;height:44px;font-size:14px;font-weight:900;border-radius:10px;margin-top:14px">生成递减组</button>`;
  $('modal').classList.add('show');
  $('dropClose').onclick=App.closeModal;
  $('dropOk').onclick=()=>{
    const bW=parseFloat($('dropW').value)||0, bR=parseFloat($('dropR').value)||0;
    const sW=parseFloat($('dropStepW').value)||0, sR=parseFloat($('dropStepR').value)||0;
    const N=Math.max(0,parseInt($('dropN').value)||0);
    ex.sets[si].type='递减'; ex.sets[si].weight=String(bW); ex.sets[si].reps=String(bR);
    const tail=ex.sets.slice(si+1).filter(x=>{
      if(x.type==='递减') return false;
      const empty=(x.weight===''||x.weight==null)&&(x.reps===''||x.reps==null)&&!x.done;
      return !empty;
    });
    const news=[];
    for(let i=1;i<=N;i++) news.push({set:0,weight:String(Math.max(0,bW-sW*i)),reps:String(Math.max(0,bR-sR*i)),rir:'',type:'递减',done:false});
    ex.sets=ex.sets.slice(0,si+1).concat(news,tail);
    ex.sets.forEach((x,i)=>x.set=i+1);
    App.save();App.closeModal();render();
    App.toast(N>0?`已生成 ${N} 个递减组`:'当前组已设为递减组');
  };
}

/* ─── 拖动排序 ───────────────────────────────────── */
function bindDrag(s){
  const box=$('homeBox'); if(!box||!s||!Array.isArray(s.exercises)) return;
  const cards=()=>[...box.querySelectorAll('.exercise')];
  cards().forEach((c,i)=>{c.dataset.ei=String(i);});
  let drag=null;

  function onMove(ev){
    if(!drag||ev.pointerId!==drag.pointerId) return;
    if(!drag.active){
      if(Math.abs(ev.clientY-drag.y0)<8) return;
      drag.active=true; drag.card.classList.add('dragging'); document.body.classList.add('is-dragging');
    }
    ev.preventDefault();
    const others=cards().filter(c=>c!==drag.card);
    let ref=null;
    for(const c of others){ const r=c.getBoundingClientRect(); if(ev.clientY<r.top+r.height/2){ref=c;break;} }
    if(ref){ if(drag.card.nextElementSibling!==ref) box.insertBefore(drag.card,ref); }
    else{ const last=others[others.length-1]; if(last&&last.nextElementSibling!==drag.card) box.insertBefore(drag.card,last.nextSibling); }
  }
  function onUp(ev){
    if(!drag||ev.pointerId!==drag.pointerId) return;
    document.removeEventListener('pointermove',onMove,true);
    document.removeEventListener('pointerup',onUp,true);
    document.removeEventListener('pointercancel',onUp,true);
    const d=drag; drag=null;
    d.card.classList.remove('dragging'); document.body.classList.remove('is-dragging');
    if(!d.active) return;
    const order=cards().map(c=>Number(c.dataset.ei));
    if(order.length!==s.exercises.length||order.some(n=>!Number.isInteger(n))){render();return;}
    const next=order.map(i=>s.exercises[i]);
    if(next.some(x=>!x)){render();return;}
    s.exercises=next; window.App.save(); render(); window.App.toast('动作顺序已调整');
  }
  box.querySelectorAll('.ex-drag-handle').forEach(handle=>{
    handle.addEventListener('pointerdown',ev=>{
      if(drag) return;
      const ei=Number(handle.dataset.dragEi);
      const card=handle.closest('.exercise');
      if(!card||!s.exercises[ei]) return;
      ev.preventDefault(); ev.stopPropagation();
      drag={pointerId:ev.pointerId,card,y0:ev.clientY,active:false};
      document.addEventListener('pointermove',onMove,{capture:true,passive:false});
      document.addEventListener('pointerup',onUp,true);
      document.addEventListener('pointercancel',onUp,true);
    });
  });
}

/* ─── 计划编辑器（新建/编辑计划） ──────────────────── */
function openPlanEditorModal(){
  const App=window.App, state=App.state, db=App.db, esc=App.esc;
  const p=db.plans.find(x=>x.id===state.editPlanId);
  state.selected = p ? p.exercises.map(x=>x.exerciseId) : [];
  $('sheet').innerHTML=`
    <div class="row between" style="gap:10px;align-items:center">
      <input id="planName" class="search" aria-label="训练计划名称" placeholder="输入训练计划名称" value="${esc(p?.name||'')}" style="margin:0;flex:1;min-width:0">
      <button id="planEditorClose" class="link-btn" style="flex-shrink:0">关闭</button>
    </div>
    <div class="muted" style="margin:9px 0 6px">① 选择动作（点击加入 / 取消）</div>
    <div id="planBrowserHost"></div>
    <div class="muted" style="margin:12px 0 6px">② 已选动作（每个 1 组 · 重量/次数/组数训练时填写）</div>
    <div id="editor"></div>
    <div class="picker-foot" style="margin-top:10px"><button id="savePlanBtn" class="btn primary" style="width:100%">保存训练计划</button></div>`;
  $('modal').classList.add('show');
  $('planEditorClose').onclick=App.closeModal;

  const browser=App.mountLibraryBrowser($('planBrowserHost'),{
    multi:true, selected:state.selected,
    onChange:()=>{ state.selected=browser.getSelected(); renderEditor(browser); }
  });
  renderEditor(browser);
  $('savePlanBtn').onclick=()=>savePlan(browser);
}
function renderEditor(browser){
  const App=window.App, state=App.state, db=App.db, esc=App.esc;
  const box=$('editor'); if(!box) return;
  if(!state.selected.length){ box.innerHTML='<div class="empty">请先在上方勾选动作</div>'; return; }
  box.innerHTML=state.selected.map((id,i)=>{
    const key=String(id);
    const ex=db.exercises.find(x=>x.id===key);
    const pmeta=(!ex&&key.startsWith('pack:'))?App.exerciseMeta[key.slice(5)]:null;
    const label=ex?ex.name:(pmeta?pmeta.中文名:key);
    return `<div class="editor-item">
      <div class="row between"><b>${i+1}. ${esc(label)}</b><button class="btn danger tiny remove-ex" data-id="${esc(key)}">移除</button></div>
      <div class="muted" style="margin-top:6px;font-size:12px">1 组 · 重量 / 次数 / 组数在训练时填写</div>
    </div>`;
  }).join('');
  box.querySelectorAll('.remove-ex').forEach(b=>b.onclick=()=>{
    state.selected=state.selected.filter(x=>x!==b.dataset.id);
    if(browser) browser.setSelected(state.selected);
    renderEditor(browser);
  });
}
function savePlan(browser){
  const App=window.App, state=App.state, db=App.db;
  if(!state.selected.length) return App.toast('请至少选择一个动作');
  const name=$('planName').value.trim()||'未命名训练日';
  const old=db.plans.find(x=>x.id===state.editPlanId);
  const ex=state.selected.map(id=>{
    const key=String(id);
    const oldEx=old?.exercises?.find(x=>x.exerciseId===key);
    const exerciseName=(db.exercises.find(x=>x.id===key)?.name)||(key.startsWith('pack:')?(App.exerciseMeta[key.slice(5)]?.中文名||key):key);
    if(old){ return {exerciseId:key,name:exerciseName,sets:oldEx?.sets??1,reps:oldEx?.reps??'',warmups:oldEx?.warmups??0,rir:oldEx?.rir??'',blankSet:!!oldEx?.blankSet}; }
    return {exerciseId:key,name:exerciseName,sets:1,reps:'',warmups:0,rir:'',blankSet:true};
  });
  if(old){ old.name=name; old.exercises=ex; }
  else{ const np={id:App.uid(),name,exercises:ex}; db.plans.push(np); state.currentPlanId=np.id; }
  App.save(); state.editPlanId=null; App.closeModal(); render(); App.toast('计划已保存');
}

/* ─── 计划管理弹窗 ───────────────────────────────── */
function openPlanManager(){
  const App=window.App;
  $('sheet').innerHTML=`<div class="row between"><h2 style="margin:0">训练计划库</h2><button id="planClose" class="link-btn">关闭</button></div>
    <div class="muted" style="margin-top:4px">建立多个训练日，直接在主页顶端无缝切换。</div>
    <button id="newPlanModal" class="btn primary" style="width:100%;margin-top:10px">＋ 新建训练计划</button>
    <div id="planModalList" class="plan-modal-list"></div>`;
  $('modal').classList.add('show');
  $('planClose').onclick=App.closeModal;
  $('newPlanModal').onclick=()=>{ App.closeModal(); newPlan(); };
  renderPlanModalList();
}
function renderPlanModalList(){
  const App=window.App, state=App.state, db=App.db, esc=App.esc;
  const box=$('planModalList'); if(!box) return;
  box.innerHTML=db.plans.length?db.plans.map(p=>`<div class="plan-modal-row">
    <div>
      <div class="plan-modal-name">${esc(p.name)}${p.id===state.currentPlanId?' <span class="badge-pill badge-blue">当前</span>':''}</div>
      <div class="plan-modal-meta">${p.exercises.length} 个动作 · ${p.exercises.reduce((a,e)=>a+(Number(e.sets)||0),0)} 组</div>
    </div>
    <div class="plan-modal-actions">
      <button class="link-btn use-plan" data-id="${p.id}">使用</button>
      <button class="link-btn edit-plan" data-id="${p.id}">编辑</button>
      <button class="link-btn danger del-plan" data-id="${p.id}">删除</button>
    </div>
  </div>`).join(''):'<div class="empty">还没有训练计划。</div>';
  document.querySelectorAll('.use-plan').forEach(b=>b.onclick=()=>{
    const pid=b.dataset.id;
    App.dropEmptySessionFor(pid);
    state.currentPlanId=pid; App.save(); App.closeModal(); render();
  });
  document.querySelectorAll('.edit-plan').forEach(b=>b.onclick=()=>{ App.closeModal(); editPlan(b.dataset.id); });
  document.querySelectorAll('.del-plan').forEach(b=>b.onclick=()=>deletePlan(b.dataset.id));
}
function newPlan(){ const App=window.App; App.state.editPlanId=null; App.state.selected=[]; openPlanEditorModal(); }
function editPlan(id){
  const App=window.App;
  const p=App.db.plans.find(x=>x.id===id); if(!p) return;
  App.state.editPlanId=id; App.state.selected=p.exercises.map(x=>x.exerciseId);
  openPlanEditorModal();
}
function deletePlan(id){
  const App=window.App;
  const p=App.db.plans.find(x=>x.id===id); if(!p) return;
  App.appConfirm('🗑️ 删除训练计划', `确认删除计划“${p.name}”？删除后不可恢复。`, '删除', ()=>{
    App.db.plans=App.db.plans.filter(x=>x.id!==id);
    if(App.state.currentPlanId===id) App.state.currentPlanId = App.db.plans[0]?.id || 'free';
    App.save(); render(); App.toast('计划已删除');
    openPlanManager();
  });
}

/* ─── 主事件绑定 ─────────────────────────────────── */
function bindEvents(s){
  const App=window.App, state=App.state, db=App.db, esc=App.esc;

  /* 计划胶囊切换 */
  document.querySelectorAll('.plan-pill-btn[data-plan]').forEach(el=>{
    el.onclick=()=>{
      const pid=el.dataset.plan;
      const same=state.currentPlanId===pid;
      state.currentPlanId=pid;
      App.dropEmptySessionFor(pid);
      App.save();
      App.toast(same?('已重新载入计划：'+(db.plans.find(p=>p.id===pid)?.name||'')):('已切换为计划：'+(db.plans.find(p=>p.id===pid)?.name||'')));
      render();
    };
  });

  /* 新建/管理计划 */
  const newPBtn=$('homeNewPlanBtn'); if(newPBtn) newPBtn.onclick=newPlan;
  const manageBtn=$('homeManagePlanBtn'); if(manageBtn) manageBtn.onclick=openPlanManager;

  /* 计划名内联编辑 */
  const nameBadge=$('planNameBadge'), nameInput=$('planNameInput');
  if(nameBadge&&nameInput){
    const beginEdit=()=>{ nameBadge.style.display='none'; nameInput.style.display='inline-block'; nameInput.focus(); nameInput.select(); };
    const commitEdit=()=>{
      nameBadge.style.display='inline-flex'; nameInput.style.display='none';
      const v=(nameInput.value||'').trim();
      if(!v){ render(); return; }
      const p=db.plans.find(x=>x.id===state.currentPlanId);
      if(p){ p.name=v; App.save(); render(); App.toast('计划名称已更新'); }
      else render();
    };
    nameBadge.onclick=beginEdit;
    nameInput.addEventListener('keydown',e=>{ if(e.key==='Enter'){e.preventDefault();commitEdit();} else if(e.key==='Escape') render(); });
    nameInput.addEventListener('blur',commitEdit);
  }

  /* 超级组批量管理 */
  const batchBtn=$('supersetBatchBtn');
  if(batchBtn){
    batchBtn.onclick=()=>{
      $('sheet').innerHTML=`
        <div class="row between"><h2 style="margin:0;font-size:17px;font-weight:900">🔗 超级组批量合并管理</h2><button id="batchSuperClose" class="link-btn">关闭</button></div>
        <div class="muted" style="margin-top:4px">勾选需要连续无歇训练的动作，一键并入同一超级组</div>
        <div style="margin-top:10px;display:flex;flex-direction:column;gap:6px;max-height:45vh;overflow-y:auto">
          ${s.exercises.map((e,idx)=>`
            <label style="display:flex;align-items:center;justify-content:space-between;padding:8px 10px;background:var(--panel);border-radius:8px;border:1px solid var(--line);cursor:pointer">
              <div style="display:flex;align-items:center;gap:8px"><input type="checkbox" class="batch-super-check" data-idx="${idx}" ${e.superset?'checked':''}><b>${idx+1}. ${esc(e.name)}</b></div>
              <span style="font-size:11.5px;color:#7c3aed;font-weight:800">${e.superset?'超级组 '+esc(e.superset):'未设置'}</span>
            </label>`).join('')}
        </div>
        <div style="margin-top:14px">
          <div class="muted" style="font-size:12px;margin-bottom:6px">选择要赋予勾选动作的超级组标签：</div>
          <div style="display:flex;gap:6px;flex-wrap:wrap">
            <button class="btn small primary apply-batch-super" data-tag="A">设为超级组 A</button>
            <button class="btn small primary apply-batch-super" data-tag="B">设为超级组 B</button>
            <button class="btn small primary apply-batch-super" data-tag="C">设为超级组 C</button>
            <button class="btn small apply-batch-super" data-tag="" style="color:#ef4444;border-color:#fca5a5">解除所选超级组</button>
          </div>
        </div>`;
      $('modal').classList.add('show');
      $('batchSuperClose').onclick=App.closeModal;
      document.querySelectorAll('.apply-batch-super').forEach(b=>{
        b.onclick=()=>{
          const tag=b.dataset.tag;
          const checkedIndices=Array.from(document.querySelectorAll('.batch-super-check:checked')).map(cb=>Number(cb.dataset.idx));
          if(!checkedIndices.length){ App.toast('请先勾选要设置的动作'); return; }
          checkedIndices.forEach(i=>{ s.exercises[i].superset=tag; });
          App.save(); App.closeModal(); render();
          App.toast(tag?`已成功将 ${checkedIndices.length} 个动作并入超级组 ${tag}！`:`已解除选中动作的超级组！`);
        };
      });
    };
  }

  /* 替换动作 */
  document.querySelectorAll('.replace-action-btn').forEach(btn=>{
    btn.onclick=(ev)=>{
      ev.stopPropagation();
      const ei=Number(btn.dataset.ei);
      const targetEx=s.exercises[ei];
      App.openActionPicker({
        title:`🔄 替换动作：${targetEx.name}`,
        onSelect:(newEx)=>{
          targetEx.name=newEx.name; targetEx.exerciseId=newEx.id; targetEx.part=newEx.part||'其他';
          const last=App.lastData(newEx.name,s.date);
          if(last?.ex?.sets?.length){
            targetEx.sets.forEach((setObj,idx)=>{
              const oldSet=last.ex.sets[idx]||last.ex.sets[last.ex.sets.length-1];
              if(!setObj.weight&&oldSet?.weight) setObj.weight=oldSet.weight;
              if(!setObj.reps&&oldSet?.reps) setObj.reps=oldSet.reps;
            });
          }
          App.save(); render(); App.toast(`已将动作替换为：${newEx.name}`);
        }
      });
    };
  });

  /* 删除动作 */
  document.querySelectorAll('.delete-action-btn').forEach(btn=>{
    btn.onclick=(ev)=>{
      ev.stopPropagation();
      const ei=Number(btn.dataset.ei);
      const exName=s.exercises[ei].name;
      s.exercises.splice(ei,1);
      App.save(); render(); App.toast(`已删除动作【${exName}】`);
    };
  });

  /* 添加动作 */
  const addExBtn=$('addWorkoutExBtn');
  if(addExBtn){
    addExBtn.onclick=()=>{
      App.openActionPicker({
        title:'➕ 添加训练动作 (可多选)', multi:true,
        onSelect:(selectedExs)=>{
          let count=0;
          selectedExs.forEach(newEx=>{
            s.exercises.push({
              name:newEx.name, exerciseId:newEx.id, part:newEx.part||'其他',
              sets:[{set:1,weight:'',reps:'',rir:'',type:'正式',done:false}],
              note:'', rirOn:false, superset:''
            });
            count++;
          });
          App.save(); render(); App.toast(`已添加 ${count} 个动作`);
        }
      });
    };
  }

  /* 清空全部动作 */
  const clearAllBtn=$('clearAllExBtn');
  if(clearAllBtn){
    clearAllBtn.onclick=()=>{
      if(!s.exercises.length){ App.toast('当前没有可清空的动作'); return; }
      App.appConfirm('🗑️ 清空今日全部动作', `确定清空今日全部 ${s.exercises.length} 个训练动作吗？此操作不可撤销。`, '清空', ()=>{
        s.exercises=[];
        App.save(); App.resetTimer(); render();
        App.toast('已清空今日全部训练动作，计时已重置');
      });
    };
  }

  /* 计时器按钮 */
  if($('timerToggleBtn')) $('timerToggleBtn').onclick=()=>{ if(state.timerRunning) App.pauseTimer(); else App.startTimer(); };
  if($('timerResetBtn')) $('timerResetBtn').onclick=App.resetTimer;

  /* 备注弹窗 */
  document.querySelectorAll('.note-action-btn').forEach(btn=>{
    btn.onclick=(ev)=>{
      ev.stopPropagation();
      const ei=Number(btn.dataset.ei);
      const targetEx=s.exercises[ei];
      $('sheet').innerHTML=`
        <div class="row between"><h2 style="margin:0;font-size:17px;font-weight:900">📝 动作备注</h2><button id="noteClose" class="link-btn">关闭</button></div>
        <div class="muted" style="margin-top:4px">动作：<b>${esc(targetEx.name)}</b></div>
        <textarea id="noteInput" class="search" style="margin-top:12px;min-height:90px;resize:vertical;font-size:14px;line-height:1.5" placeholder="输入备注，如：手肘内收、顶峰收缩...">${esc(targetEx.note||'')}</textarea>
        <div style="display:flex;gap:8px;margin-top:14px">
          <button id="noteClearBtn" class="btn small" style="flex:1;background:#fff1f1;color:var(--red)">清除备注</button>
          <button id="noteSaveBtn" class="btn small primary" style="flex:2">保存备注</button>
        </div>`;
      $('modal').classList.add('show');
      $('noteClose').onclick=App.closeModal;
      $('noteClearBtn').onclick=()=>{ targetEx.note=''; App.save(); App.closeModal(); render(); App.toast('备注已清除'); };
      $('noteSaveBtn').onclick=()=>{
        targetEx.note=($('noteInput').value||'').trim();
        App.save(); App.closeModal(); render();
        App.toast(targetEx.note?'备注已保存':'备注已清空');
      };
      setTimeout(()=>$('noteInput')?.focus(),80);
    };
  });

  /* 组数据操作（data-action） */
  document.querySelectorAll('[data-action]').forEach(b=>{
    b.onclick=()=>{
      const a=b.dataset.action, ei=Number(b.dataset.ei), si=Number(b.dataset.si);
      const ex=s.exercises[ei];
      if(a==='rir'){ ex.rirOn=!ex.rirOn; App.save(); render(); return; }
      if(a==='type'){
        const cur=ex.sets[si].type||'正式';
        const next=cur==='正式'?'热身':(cur==='热身'?'递减':'正式');
        ex.sets[si].type=next;
        if(next==='递减'){ App.save(); openDropSetModal(ex,si); return; }
        App.save(); render(); return;
      }
      if(a==='done'){ ex.sets[si].done=!ex.sets[si].done; App.save(); render(); return; }
      if(a==='del'){ ex.sets.splice(si,1); ex.sets.forEach((x,i)=>x.set=i+1); App.save(); render(); return; }
      if(a==='add'){
        ex.sets.push({set:ex.sets.length+1,weight:'',reps:'',rir:'',type:'正式',done:false});
        if(ex.sets.some(x=>x.set==='')) ex.sets.forEach((x,i)=>x.set=i+1);
        App.save(); render(); return;
      }
      if(a==='fill'){
        let lastW=null,lastR=null,filledW=0,filledR=0;
        ex.sets.forEach(x=>{
          const hasW=(x.weight!==''&&x.weight!=null), hasR=(x.reps!==''&&x.reps!=null);
          if(hasW) lastW=x.weight; if(hasR) lastR=x.reps;
          if(!hasW&&lastW!==null){ x.weight=lastW; filledW++; }
          if(!hasR&&lastR!==null){ x.reps=lastR; filledR++; }
        });
        if(filledW===0&&filledR===0){ App.toast(lastW===null&&lastR===null?'请先在上方任意一组填写重量或次数':'下方没有需要填充的空白格'); return; }
        App.save(); render(); App.toast(`已填充 ${filledW} 个重量、${filledR} 个次数`); return;
      }
      if(a==='clear-ex-data'){
        ex.sets.forEach(x=>{ x.weight=''; x.reps=''; x.rir=''; x.done=false; x.type='正式'; });
        App.save(); render(); App.toast('已清空该动作所有数据，保留空白组'); return;
      }
      if(a==='use-last'){
        const last=App.lastData(ex.name,s.date);
        if(!last||!last.ex.sets.length){ App.toast('暂无历史记录可套用'); return; }
        ex.sets=last.ex.sets.map((x,i)=>({set:i+1,weight:x.weight,reps:x.reps,rir:'',type:x.type||'正式',done:false}));
        App.save(); render(); App.toast(`已清空当前组，成功套用上次记录（共 ${ex.sets.length} 组）`);
        return;
      }
    };
  });

  /* 输入框实时保存 + 顶部统计刷新 */
  document.querySelectorAll('.field[data-k]').forEach(inp=>{
    inp.oninput=()=>{
      const ei=Number(inp.dataset.ei), si=Number(inp.dataset.si), k=inp.dataset.k;
      s.exercises[ei].sets[si][k]=inp.value;
      App.save();
      const stt=App.sessionStats(s), pct=stt.sets?Math.round(stt.done/stt.sets*100):0;
      const statEls=document.querySelectorAll('.statbar .stat b');
      if(statEls.length>=4){
        statEls[0].textContent=stt.done; statEls[1].textContent=stt.sets;
        statEls[2].textContent=stt.reps; statEls[3].textContent=App.fmtVolume(stt.volume);
      }
      const p=document.querySelector('.progress i'); if(p) p.style.width=`${pct}%`;
    };
  });

  /* 完成并保存 */
  const finishBtn=$('finishBtn');
  if(finishBtn){
    finishBtn.onclick=()=>{
      s.completed = true;
      s.finishedAt = new Date().toISOString();
      s.duration = Math.round(state.timerSeconds/60) || s.duration || 1;
      const formalCount=s.exercises.flatMap(e=>e.sets||[]).filter(x=>(x.type||'正式')!=='热身').length;
      s.exercises.forEach(e=>{ (e.sets||[]).forEach(x=>{ if((x.type||'正式')!=='热身') x.done=true; }); });
      App.save(); render();
      App.toast(`🎉 训练完成！正式组 ${formalCount} 组，耗时 ${s.duration} 分钟，已正式归档至日历！`);
    };
  }
}

/* ─── 注册到 Pages ───────────────────────────────── */
window.Pages.home = { render };
})();