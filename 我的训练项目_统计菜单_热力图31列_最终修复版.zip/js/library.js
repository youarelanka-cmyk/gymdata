/* ═════════════════════════════════════════════════════════════
   [MODULE: page/library] 动作库
   资源包管理：仅支持 ZIP 导入、动作资料对齐和清空资源包
   ═════════════════════════════════════════════════════════════ */
(function(){
'use strict';
const $=id=>document.getElementById(id);

/* ─── appConfirm 的 Promise 化封装 ─────────────────────── */
function confirmAsync(title, msg, okText){
  return new Promise(resolve=>{
    const App=window.App;
    let done=false;
    const fin=v=>{ if(done) return; done=true; try{ App.closeModal(); }catch(e){} resolve(v); };
    App.appConfirm(title, msg, okText, ()=>fin(true));
    setTimeout(()=>{
      const x=document.getElementById('cfX');
      const c=document.getElementById('cfCancel');
      const m=document.getElementById('modal');
      if(x) x.onclick=()=>fin(false);
      if(c) c.onclick=()=>fin(false);
      if(m){
        const h=ev=>{ if(ev.target===m){ m.removeEventListener('click',h); fin(false); } };
        m.addEventListener('click',h);
      }
    },0);
  });
}

function fmtPackTime(){
  const d=new Date(), p=n=>String(n).padStart(2,'0');
  return d.getFullYear()+'-'+p(d.getMonth()+1)+'-'+p(d.getDate())+' '+p(d.getHours())+':'+p(d.getMinutes());
}
function getPackRecords(){
  try{
    const a=JSON.parse(localStorage.getItem('gym_v5_imported_packs')||'[]');
    return Array.isArray(a)?a.filter(x=>x&&x.file):[];
  }catch(e){ return []; }
}
function savePackRecords(list){
  try{ localStorage.setItem('gym_v5_imported_packs',JSON.stringify(list)); }catch(e){}
}

/* ─── 文件读取辅助 ─────────────────────────────── */
function readFileAsText(file){
  return new Promise((res,rej)=>{
    const r=new FileReader();
    r.onload=()=>res(String(r.result||''));
    r.onerror=()=>rej(r.error||new Error('读取文件失败'));
    r.readAsText(file,'utf-8');
  });
}
function readFileAsBase64(file){
  return new Promise((res,rej)=>{
    const r=new FileReader();
    r.onload=()=>{
      const s=String(r.result||'');
      const i=s.indexOf(',');
      res(i>=0?s.slice(i+1):s);
    };
    r.onerror=()=>rej(r.error||new Error('读取文件失败'));
    r.readAsDataURL(file);
  });
}

/* ─── 从 File 对象导入 ZIP 资源包（备用入口，需要 JSZip） ─── */
async function importResourcePackFromFile(file){
  const App=window.App;
  if(!file) throw new Error('未选择文件');
  if(!/\.zip$/i.test(file.name)) throw new Error('请选择 .zip 格式的动作资源包');
  if(!window.JSZip) throw new Error('ZIP 解析组件缺失：请确认 jszip.min.js 已正确加载');

  const zipName=file.name;
  App.toast('正在读取 ZIP：'+zipName);

  const imported=getPackRecords();
  if(imported.some(r=>r&&r.file===zipName)){
    const go=await confirmAsync(
      '已导入过该资源包',
      '「'+zipName+'」此前已导入过。继续导入会合并进当前动作库（同名动作将被覆盖），是否继续？',
      '继续导入'
    );
    if(!go) return;
  }

  App.toast('正在解析 ZIP 结构…');
  let zip;
  try{ zip=await JSZip.loadAsync(file); }
  catch(e){ throw new Error('无法打开 ZIP：'+(e&&e.message||'')); }

  const allJson=Object.values(zip.files).filter(e=>!e.dir&&/\.json$/i.test(e.name));
  let jsonEntry=allJson.find(e=>/动作数据\.json$/i.test(e.name));
  if(!jsonEntry){
    for(const e of allJson){
      if(/(package|manifest|readme|说明|package-lock)/i.test(e.name)) continue;
      try{
        const probe=await e.async('text');
        if(/"中文名"\s*:/.test(probe)){ jsonEntry=e; break; }
      }catch(_){}
    }
  }
  if(!jsonEntry) throw new Error('未找到 动作数据.json（ZIP 里的 json：'+(allJson.map(e=>e.name).join(', ')||'无')+'）');

  App.toast('正在解析动作资料…');
  let txt=await jsonEntry.async('text');
  txt=String(txt||'').replace(/^\uFEFF/,'');
  let arr;
  try{ arr=JSON.parse(txt); }
  catch(e){ throw new Error('JSON 格式错误：'+e.message); }
  if(!Array.isArray(arr)||!arr.length) throw new Error('JSON 内容为空');

  // 建立映射（与文件夹导入保持一致的匹配策略）
  const meta={}, idToKey={}, nameToKey={};
  arr.forEach(rec=>{
    if(rec&&rec.中文名){
      const k=App.normalizeExerciseName(rec.中文名);
      meta[k]=rec;
      const idVal = rec.id != null ? rec.id : (rec.ID != null ? rec.ID : (rec.Id != null ? rec.Id : null));
      if(idVal != null && String(idVal).trim() !== '') idToKey[String(idVal).trim()] = k;
      if(rec.GIF){
        const gk=App.normalizeExerciseName(String(rec.GIF).replace(/\.[a-zA-Z0-9]+$/,''));
        if(gk&&!nameToKey[gk]) nameToKey[gk]=k;
      }
    }
  });

  const imgEntries=Object.values(zip.files).filter(e=>!e.dir&&/\.(gif|png|jpe?g|webp)$/i.test(e.name));
  const gifs=[]; const matched=new Set();
  let idx=0;
  for(const e of imgEntries){
    idx++;
    if(idx%30===0||idx===1){
      App.toast('正在读取动图 '+idx+'/'+imgEntries.length+'…');
      await new Promise(r=>setTimeout(r,0));
    }
    try{
      const raw=e.name.split('/').pop().replace(/\.[a-zA-Z0-9]+$/,'').trim();
      let k=null;
      if(idToKey[raw]) k=idToKey[raw];
      if(!k&&nameToKey[raw]) k=nameToKey[raw];
      if(!k){ const nm=App.normalizeExerciseName(raw); if(meta[nm]) k=nm; }
      if(!k){ const stripped=raw.replace(/[_\-\s]*\d+$/,'').trim(); const nm=App.normalizeExerciseName(stripped); if(meta[nm]) k=nm; }
      if(!k||matched.has(k)) continue;
      matched.add(k);
      const b64=await e.async('base64');
      const MIME=/\.png$/i.test(e.name)?'image/png'
                :/\.jpe?g$/i.test(e.name)?'image/jpeg'
                :/\.webp$/i.test(e.name)?'image/webp':'image/gif';
      gifs.push({name:k,data:'data:'+MIME+';base64,'+b64});
    }catch(_){}
  }

  App.toast('正在写入动作库…');
  Object.assign(App.exerciseMeta,meta);
  App.saveMeta();
  try{ await App.idbOpen(); }catch(e){}
  let wrote=0;
  for(const g of gifs){
    App.gifAssets[g.name]=g.data;
    try{ await App.idbPutGif(g.name,g.data); }catch(e){}
    wrote++;
    if(wrote%30===0){
      App.toast('正在写入动图 '+wrote+'/'+gifs.length+'…');
      await new Promise(r=>setTimeout(r,0));
    }
  }

  const rec={file:zipName,time:fmtPackTime(),count:Object.keys(meta).length,gifCount:gifs.length,keys:Object.keys(meta)};
  const pi=imported.findIndex(x=>x.file===zipName);
  if(pi>=0) imported[pi]=rec; else imported.push(rec);
  savePackRecords(imported);

  App.toast('✅ 导入成功：'+Object.keys(meta).length+' 条动作资料 + '+gifs.length+' 个动作GIF');
  if(window.Pages.library&&window.Pages.library.render) window.Pages.library.render();
  if(App.state.page==='home'&&window.Pages.home) window.Pages.home.render();

  const autoN=App.alignExactAuto();
  setTimeout(()=>{
    if(App.needReviewCount()>0) App.openAlignReview();
    else if(autoN) App.toast('已按资源包自动对齐 '+autoN+' 个动作');
  },400);
}

/* ─── 主渲染 ─────────────────────────────────────── */
function render(){
  const App=window.App, state=App.state;
  const packMode=!!Object.keys(App.exerciseMeta).length;
  const q=(($('libFind')?.value)||'').trim().toLowerCase();
  const part=state.libPart;
  const packEquip=packMode?App.packEquipData(part):null;

  const partEl=$('libPartRail');
  if(partEl){
    partEl.style.display=packMode?'':'none';
    if(packMode){
      const partOptions=App.packPartOptions();if(!partOptions.includes(state.libPart))state.libPart='全部';partEl.innerHTML=partOptions.map(p=>`<button type="button" class="lib-mpart ${state.libPart===p?'active':''}" data-libpart="${App.esc(p)}">${App.esc(p)}</button>`).join('');
      partEl.querySelectorAll('[data-libpart]').forEach(b=>b.onclick=()=>{ state.libPart=b.dataset.libpart; render(); });
    }else partEl.innerHTML='';
  }

  const equipEl=$('libEquipChips');
  if(equipEl){
    equipEl.style.display=packMode?'':'none';
    if(packMode){
      equipEl.innerHTML=`<button type="button" class="lib-part-chip ${!state.libEquip?'active':''}" data-libequip="">全部</button>`+
        packEquip.chips.map(([c,n])=>`<button type="button" class="lib-part-chip ${state.libEquip===c?'active':''}" data-libequip="${App.esc(c)}">${App.esc(App.shortEquip(c))}</button>`).join('');
      equipEl.querySelectorAll('[data-libequip]').forEach(b=>{
        b.onclick=()=>{ const v=b.dataset.libequip; state.libEquip=(state.libEquip===v?null:v); render(); };
      });
    }else equipEl.innerHTML='';
  }

  const mfEl=$('libMiniFilters');
  if(mfEl){
    mfEl.style.display=packMode?'':'none';
    if(packMode){
      const heats=[['高热度','高'],['中热度','中'],['低热度','低']];
      const cats=[['力量训练','力量'],['拉伸放松','拉伸'],['有氧体能','有氧']];
      mfEl.innerHTML=`<span class="lmf-label">热度</span>`+
        heats.map(([v,t])=>`<button type="button" class="lib-part-chip lmf-chip ${state.libHeat===v?'active':''}" data-lmfheat="${App.esc(v)}">${App.esc(t)}</button>`).join('')+
        `<span class="lmf-divider"></span><span class="lmf-label">分类</span>`+
        cats.map(([v,t])=>`<button type="button" class="lib-part-chip lmf-chip ${state.libCat===v?'active':''}" data-lmfcat="${App.esc(v)}">${App.esc(t)}</button>`).join('');
      mfEl.querySelectorAll('[data-lmfheat]').forEach(b=>b.onclick=()=>{ state.libHeat=(state.libHeat===b.dataset.lmfheat?null:b.dataset.lmfheat); render(); });
      mfEl.querySelectorAll('[data-lmfcat]').forEach(b=>b.onclick=()=>{ state.libCat=(state.libCat===b.dataset.lmfcat?null:b.dataset.lmfcat); render(); });
    }else mfEl.innerHTML='';
  }

  const box=$('libraryBox');
  if(!box) return;
  if(packMode){
    const keys=App.libFilterKeys({part,equip:state.libEquip,heat:state.libHeat,cat:state.libCat,q});
    if(state._libPart!==part||state._libQ!==q||state._libEquip!==state.libEquip||state._libHeat!==state.libHeat||state._libCat!==state.libCat) state._libPage=0;
    state._libPart=part; state._libQ=q; state._libEquip=state.libEquip; state._libHeat=state.libHeat; state._libCat=state.libCat;
    const PAGE=60, start=(state._libPage||0)*PAGE, page=keys.slice(start,start+PAGE);
    box.innerHTML=page.map(k=>App.renderPackCard(k,App.exerciseMeta[k])).join('')||'<div class="empty" style="grid-column:1/-1">没有匹配动作</div>';
    if(keys.length>start+PAGE){
      box.insertAdjacentHTML('beforeend',`<button id="libMore" class="btn small" style="grid-column:1/-1;justify-self:center;margin-top:6px">显示更多（${keys.length-start-PAGE}）</button>`);
      const more=$('libMore'); if(more) more.onclick=()=>{ state._libPage=(state._libPage||0)+1; render(); };
    }
    box.querySelectorAll('.lib-card').forEach(card=>{
      card.onclick=()=>{ const k=card.dataset.packkey; if(k) App.showExerciseDetail(k); };
    });
    syncLibSticky();
    return;
  }

  box.innerHTML=App.noPackPromptHTML();
  bindNoPackImport();
  syncLibSticky();
}

function syncLibSticky(){
  const head=document.querySelector('.lib-sticky-header'); if(!head) return;
  const top=(head.offsetHeight+6)+'px';
  document.querySelectorAll('#libPartRail').forEach(rail=>{ rail.style.top=top; });
}
if(typeof window!=='undefined') window.addEventListener('resize',()=>{ if(window.App.state.page==='library') syncLibSticky(); });

/* 无资源包引导按钮：触发 ZIP 导入 */
function bindNoPackImport(){
  const b=$('noPackImportBtn');
  if(b&&!b.dataset.bound){
    b.dataset.bound='1';
    b.onclick=()=>{
      const inp=$('gifImportInput');
      if(inp){ inp.value=''; inp.click(); } else window.App.toast('导入控件缺失');
    };
  }
}

/* ─── 资源包管理弹窗 ─────────────────────────────── */
function openPackManager(){
  const App=window.App;
  const recs=getPackRecords();
  const total=Object.keys(App.exerciseMeta).length;
  if(!recs.length&&!total){ App.toast('暂无导入记录，先导入资源包后再管理'); return; }
  if(!recs.length&&total){
    App.appConfirm('🧹 清空资源包','当前已导入 '+total+' 条动作资料（早期导入，无分包记录）。\n\n确定全部清空吗？将删除所有动作资料与动图（含官方包与自定义动作），历史训练记录不受影响。','全部清空',()=>{ clearPackData(true); });
    return;
  }
  $('sheet').innerHTML=`
    <div class="row between"><h2 style="margin:0">🧹 资源包管理</h2><button id="pmClose" class="link-btn">关闭</button></div>
    <div class="muted" style="margin-top:4px;font-size:11.5px">共 ${recs.length} 次导入记录。勾选要移除的包后点「删除选中」：只清空选中包独有的动作与动图（与其他包共有的动作会保留）。</div>
    <div class="pm-list">${recs.map((r,i)=>{
      const custom=String(r.file).startsWith('我的自定义动作包_');
      const noKeys=!r.keys||!r.keys.length;
      return `<label class="pm-item">
        <input type="checkbox" value="${i}">
        <div class="pm-info"><div class="pm-name">${App.esc(r.file)}</div><div class="pm-meta">${custom?'自定义包':'资源包'} · ${r.time||'较早导入'} · ${r.count||'?'} 动作${r.gifCount?' · '+r.gifCount+' GIF':''}${noKeys?' · ⚠️ 无动作清单，需用全部清空':' · 覆盖 '+r.keys.length+' 键'}</div></div>
        <span class="pm-badge ${custom?'custom':'official'}">${custom?'自定义':'资源包'}</span>
      </label>`;
    }).join('')}</div>
    <div class="pm-foot"><button class="pm-cancel" id="pmCancel">取消</button><button class="pm-del" id="pmDel" disabled>删除选中(0)</button><button class="pm-clearall" id="pmClearAll">全部清空</button></div>`;
  $('modal').classList.add('show');
  const delBtn=$('pmDel');
  const refreshDel=()=>{
    const n=document.querySelectorAll('.pm-item input:checked').length;
    delBtn.disabled=!n; delBtn.textContent=n?'删除选中('+n+')':'删除选中(0)';
  };
  document.querySelectorAll('.pm-item input').forEach(c=>c.onchange=refreshDel);
  $('pmClose').onclick=App.closeModal;
  $('pmCancel').onclick=App.closeModal;
  $('pmClearAll').onclick=()=>{
    App.appConfirm('🧹 全部清空','确定清空全部 '+total+' 条动作资料与全部动图吗？\n\n包括：所有资源包、自定义动作、全部分包记录。历史训练记录不受影响，清空后可重新导入。','全部清空',()=>{ clearPackData(true); });
  };
  delBtn.onclick=()=>{
    const picked=[...document.querySelectorAll('.pm-item input:checked')].map(c=>Number(c.value));
    if(!picked.length) return;
    const noKeyPicked=picked.filter(i=>!recs[i].keys||!recs[i].keys.length);
    if(noKeyPicked.length){
      App.appConfirm('⚠️ 无法按包删除','选中的 '+noKeyPicked.length+' 个包没有动作清单（早期导入），无法精确删除其动作。\n\n请改用「全部清空」。','知道了',()=>{});
      return;
    }
    App.appConfirm('🗑️ 删除资源包','确定移除选中的 '+picked.length+' 个资源包吗？将删除这些包独有的动作资料与动图（共有的动作保留）。此操作不可撤销。','删除',()=>{ deletePacks(recs,picked); });
  };
}
function deletePacks(recs,picked){
  const App=window.App;
  const keep=recs.filter((_,i)=>!picked.includes(i));
  const keepKeys=new Set();
  keep.forEach(r=>(r.keys||[]).forEach(k=>keepKeys.add(k)));
  const removeKeys=new Set();
  picked.forEach(i=>{
    const r=recs[i];
    if(r&&Array.isArray(r.keys)) r.keys.forEach(k=>{ if(!keepKeys.has(k)) removeKeys.add(k); });
  });
  const custom=customPackList();
  const customSet=new Set(custom);
  const nextCustom=custom.filter(k=>!removeKeys.has(k));
  removeKeys.forEach(k=>{
    delete App.exerciseMeta[k];
    if(App.gifAssets[k]){ delete App.gifAssets[k]; App.idbOpen().then(()=>App.idbDelGif(k)).catch(()=>{}); }
    if(customSet.has(k)) try{ localStorage.setItem('gym_v5_custom_actions',JSON.stringify(nextCustom)); }catch(e){}
  });
  App.saveMeta(); savePackRecords(keep); render();
  if(App.state.page==='home'&&window.Pages.home) window.Pages.home.render();
  if(window.Pages.calendar) window.Pages.calendar.render();
  App.closeModal();
  if(removeKeys.size) App.toast('已删除 '+picked.length+' 个资源包 · 移除 '+removeKeys.size+' 个独有动作');
  else App.toast('已删除 '+picked.length+' 个资源包记录（动作与其他包共享，全部保留）');
}
function clearPackData(skipConfirm){
  const App=window.App;
  const n=Object.keys(App.exerciseMeta).length;
  if(!n){ App.toast('当前未导入资源包'); return; }
  const doClear=()=>{
    App.exerciseMeta={}; App.gifAssets={};
    try{
      localStorage.removeItem('gym_v5_exercise_meta');
      localStorage.removeItem('gym_v5_custom_actions');
      localStorage.removeItem('gym_v5_imported_packs');
    }catch(e){}
    App.idbOpen().then(()=>App.idbClearGifs()).then(()=>App.idbPutMeta({})).catch(()=>{});
    App.db.exercises.forEach(e=>{ delete e.mkey; e.orig=undefined; });
    App.save(); render();
    if(window.Pages.home) window.Pages.home.render();
    if(window.Pages.calendar) window.Pages.calendar.render();
    App.closeModal();
    App.toast('资源包已全部清空（含资源包与自定义动作），可重新导入');
  };
  if(skipConfirm){ doClear(); return; }
  App.appConfirm('🧹 清空资源包','确定清空已导入的 '+n+' 条动作资料与全部动图吗？此操作会释放手机内存；历史训练记录不受影响。','清空',doClear);
}

/* ─── 自定义动作 ─────────────────────────────────── */
let _ccGifData='';
let _ccGifReplace=false;
let _ccEditingKey=null;

function customPackList(){
  const App=window.App;
  try{
    const a=JSON.parse(localStorage.getItem('gym_v5_custom_actions')||'[]');
    return Array.isArray(a)?a.filter(k=>App.exerciseMeta[k]):[];
  }catch(e){ return []; }
}
function customPackList(){
  try{ const a=JSON.parse(localStorage.getItem('gym_v5_custom_actions')||'[]'); return Array.isArray(a)?a.filter(k=>window.App.exerciseMeta[k]):[]; }catch(e){ return []; }
}

/* ─── 顶栏菜单 + 按钮绑定 ────────────────────────── */
function bindTopMenu(){
  const App=window.App;

  const libMenuBtn=$('libMenuBtn'), libMenuPanel=$('libMenuPanel');
  if(libMenuBtn&&libMenuPanel&&!libMenuBtn.dataset.bound){
    libMenuBtn.dataset.bound='1';
    libMenuBtn.onclick=e=>{
      e.stopPropagation();
      libMenuPanel.style.display=(libMenuPanel.style.display==='none')?'flex':'none';
    };
    document.addEventListener('click',e=>{
      if(libMenuPanel.style.display!=='none'&&!e.target.closest('#libMenuPanel')&&!e.target.closest('#libMenuBtn'))
        libMenuPanel.style.display='none';
    });
    // 统一：菜单里点任何按钮都自动关闭面板（包含新注入的"导入文件夹"）
    libMenuPanel.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{ libMenuPanel.style.display='none'; }));
  }

  const clearPackBtn=$('clearPackBtn'); if(clearPackBtn&&!clearPackBtn.dataset.bound){ clearPackBtn.dataset.bound='1'; clearPackBtn.onclick=openPackManager; }
  const alignBtn=$('alignBtn'); if(alignBtn&&!alignBtn.dataset.bound){ alignBtn.dataset.bound='1'; alignBtn.onclick=()=>App.openAlignReview(); }

  /* 备用：ZIP 导入入口（如果 HTML 里的 gifImportBtn / gifImportInput 存在，则保留；不存在也不影响） */
  const gifBtn=$('gifImportBtn');
  const gifInput=$('gifImportInput');
  if(gifBtn&&gifInput&&!gifBtn.dataset.bound){
    gifBtn.dataset.bound='1';
    gifBtn.onclick=()=>{ gifInput.value=''; gifInput.click(); };
  }
  if(gifInput&&!gifInput.dataset.bound){
    gifInput.dataset.bound='1';
    gifInput.onchange=async ()=>{
      const file=gifInput.files[0];
      if(!file) return;
      const old=gifBtn?gifBtn.textContent:'';
      try{
        if(gifBtn){ gifBtn.disabled=true; gifBtn.textContent='正在导入…'; }
        await importResourcePackFromFile(file);
      }catch(err){
        console.error('[library] ZIP 导入失败：',err);
        App.toast('导入失败：'+((err&&err.message)||'未知错误'));
      }finally{
        if(gifBtn){ gifBtn.disabled=false; gifBtn.textContent=old; }
        gifInput.value='';
      }
    };
  }

  const libFind=$('libFind');
  if(libFind&&!libFind.dataset.bound){ libFind.dataset.bound='1'; libFind.addEventListener('input',render); }
}

/* ─── 注册 ──────────────────────────────────────── */
function init(){ bindTopMenu(); }
window.Pages.library = { render, init };
})();